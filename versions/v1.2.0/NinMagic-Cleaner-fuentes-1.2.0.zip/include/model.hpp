#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "app_update.hpp"

namespace nm {
struct Content {
    uint64_t id=0;
    uint32_t version=0;
    uint8_t storage=0, type=0;
};
struct Game {
    uint64_t id=0;
    std::string name, author;
    bool sd=false, nand=false, card=false, metadataOk=false;
    unsigned updates=0, dlc=0;
    std::vector<Content> contents;
    std::string portKey;
    bool externalOnly=false;
    std::vector<std::string> manualPaths;
    std::string version, nroVersion, nroPath;
};
struct Save {
    uint64_t id=0, applicationId=0, size=0, uid0=0, uid1=0;
    uint8_t space=0, type=0;
    std::string user;
};
struct Plan {
    Game game;
    std::vector<Save> saves;
    std::vector<std::string> extraPaths;
    bool savesOk=false, extrasOk=false, valid=false;
    uint32_t error=0;
    std::string detail;
    struct PortEntry {
        std::string path;
        uint64_t size=0;
        int64_t modified=0;
        bool directory=false, savedata=false;
    };
    std::vector<std::string> portPaths, externalSavePaths;
    std::vector<PortEntry> portEntries;
    uint64_t portBytes=0, externalSaveBytes=0;
    unsigned externalSaveFiles=0;
    bool portVerified=false;
    bool portSavePolicyKnown=false;
    std::string portFingerprint;
};
struct Environment {
    std::string firmware="Detectando...", atmosphere="Detectando...", nand="Entorno sin verificar";
    bool applet=false, atmosphereDetected=false;
    uint64_t sdTotal=0, sdFree=0, nandTotal=0, nandFree=0;
    uint32_t initError=0;
};
struct Outcome {
    bool gameRemoved=false, complete=false;
    unsigned savesRemoved=0, extrasRemoved=0;
    uint32_t error=0;
    std::vector<std::string> messages;
    unsigned portFilesRemoved=0, externalSavesRemoved=0;
    uint64_t portBytesRemoved=0;
};
struct BrowserEntry {
    std::string name, path;
    bool directory=false, selectable=false;
    uint64_t bytes=0;
};
enum class Screen { Loading, Library, SaveChoice, Confirm, Busy, Result, Help, Files, AppUpdate, AppUpdateRecord, AppUpdateResult };
struct View {
    Screen screen=Screen::Loading;
    Environment env;
    std::vector<Game> games;
    Plan plan;
    Outcome outcome;
    int selected=0, filter=0, choice=0;
    bool eraseSaves=false, eraseExtras=true;
    float hold=0;
    uint64_t frame=0;
    std::string status="Leyendo los juegos instalados...";
    std::string browserPath="sdmc:/", browserError;
    std::vector<BrowserEntry> browserEntries;
    std::vector<std::string> selectedPaths;
    int browserSelected=0;
    AppUpdateInfo appUpdate;
    CompletedUpdateInfo completedUpdate;
    std::string appUpdateDetail, appUpdateResultMessage;
    bool appUpdateArchiveResult=false, appUpdateResultOk=false;
};
inline std::string titleId(uint64_t id) {
    char out[17];
    const char *hex="0123456789ABCDEF";
    for(int i=15;i>=0;--i) {out[i]=hex[id&15];id>>=4;} out[16]=0;
    return out;
}
}
