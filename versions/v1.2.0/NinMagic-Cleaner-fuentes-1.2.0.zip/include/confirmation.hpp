#pragma once
#include <algorithm>

namespace nm {
// A fresh release is required after opening the confirmation dialog. Holding
// buttons while navigating into it cannot authorize a destructive operation.
class DeleteConfirmation {
    bool armed_=false, fired_=false;
    double started_=-1;
    float progress_=0;
public:
    void reset() {armed_=false;fired_=false;started_=-1;progress_=0;}
    bool update(bool allHeld, double seconds, bool anyHeld=false) {
        if(fired_) return false;
        if(!armed_) {if(!allHeld && !anyHeld) armed_=true;return false;}
        if(!allHeld) {started_=-1;progress_=0;return false;}
        if(started_<0) started_=seconds;
        progress_=std::clamp(float((seconds-started_)/2.0),0.0f,1.0f);
        if(progress_>=1) {fired_=true;return true;}
        return false;
    }
    float progress() const {return progress_;}
};
// Save intent is deliberately a distinct action from game deletion.
enum class SaveDecision { Keep, Erase, Cancel, Unavailable };
inline SaveDecision decideSaves(int choice, bool inventoryComplete) {
    if(choice==0) return SaveDecision::Keep;
    if(choice==1) return inventoryComplete ? SaveDecision::Erase : SaveDecision::Unavailable;
    return SaveDecision::Cancel;
}
}
