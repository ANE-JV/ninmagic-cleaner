#pragma once
#include "model.hpp"
namespace nm {
bool backendInit(Environment &env);
void backendExit();
bool loadGames(std::vector<Game> &games, std::string &error);
Plan preparePlan(const Game &game);
Outcome executePlan(const Plan &plan, bool eraseSaves, bool eraseExtras);
void refreshStorage(Environment &env);
}
