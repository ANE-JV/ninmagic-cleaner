#pragma once
#include "model.hpp"

namespace nm {
// Canonical SD paths use sdmc:/, preserve filename case, and omit a trailing
// slash except at the root. Dot components, repeated separators, backslashes,
// alternate devices and control characters are rejected rather than resolved.
bool normalizeSdPath(const std::string &path,std::string &normalized,std::string &error);

// Shared lexical boundary for the browser and the manual-removal backend.
// This does not grant filesystem access or delete anything. Callers must also
// inspect each existing ancestor/subtree and reject links before removal.
bool isSafeSdSelection(const std::string &path,std::string &error);

// Validates inventory nodes under an already selectable root. This retains the
// global critical-filename protections while allowing the contents of an exact
// approved Atmosphere Title ID directory to be inventoried and removed.
bool isSafeSdDescendant(const std::string &path,const std::string &approvedRoot,std::string &error);

// Lists a single directory without recursion. Protected containers remain
// browsable; their entries indicate whether an explicit selection is allowed.
// Links and special nodes cannot be selected. Files report their current size;
// directories report zero until the deletion plan inventories their contents.
bool browseSd(const std::string &path,std::vector<BrowserEntry> &entries,std::string &error);
}
