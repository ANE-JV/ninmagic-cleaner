#pragma once
#include "model.hpp"

namespace nm {
// Reattach previously confirmed SD roots after their launcher or NSP disappears.
// An automatic profile keeps its own classification; receipt-only remnants use
// the conservative manual-path policy and require a fresh deletion confirmation.
bool addRememberedPaths(std::vector<Game> &games,std::string &error);

// Persist the complete validated root list before any installed content is
// removed. A failed write must abort that removal. The file is bounded, parsed
// strictly, and stored only inside this app's protected SD configuration folder.
bool rememberPaths(const Plan &plan,std::string &error);

// Remove receipt roots which no longer exist after an operation. Persistence
// errors preserve the older receipt; a later scan still filters missing roots.
void pruneRememberedPaths(const Plan &plan);

#ifdef NM_BINDINGS_TEST
void bindingsSetTestRoot(const std::string &root);
#endif
}
