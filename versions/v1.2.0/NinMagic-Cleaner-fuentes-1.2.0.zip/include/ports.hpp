#pragma once
#include "model.hpp"
namespace nm {
// Returns entries for verified external port installations whose NSP is absent;
// annotates an installed application when the same exact registered TitleID exists.
bool discoverPortRemnants(std::vector<Game> &games,std::string &error);
bool inspectPort(const Game &game,Plan &plan,uint32_t &error,std::string &detail);
bool samePortPlan(const Plan &before,const Plan &after);
bool removePortData(const Plan &plan,bool eraseFiles,bool eraseSaves,Outcome &outcome);
}
