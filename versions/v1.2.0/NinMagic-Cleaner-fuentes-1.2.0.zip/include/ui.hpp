#pragma once
#include "model.hpp"
namespace nm {
// Pixel format: RGBA8888 in memory. Stride is measured in pixels.
bool uiInit(const std::string &assetRoot);
void uiDraw(uint32_t *pixels, int stride, const View &view);
void uiExit();
}
