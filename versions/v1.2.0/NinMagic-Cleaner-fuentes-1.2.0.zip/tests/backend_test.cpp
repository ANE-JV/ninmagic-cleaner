#include "switch.h"
#include "backend.hpp"
#include "ports.hpp"
#include "bindings.hpp"
#include <algorithm>
#include <cassert>
#include <cstring>
#include <iostream>
#include <vector>
#include <zlib.h>

// No console connection, IPC, NAND access or real deletion is used here.
namespace {
constexpr u64 Forwarder=0x054E4DC8B31AA000ULL;
constexpr u64 OtherApp=0x0100000000020000ULL;
struct Mock {
    AppletType mode=AppletType_Application;
    u64 running=OtherApp, app=Forwarder;
    bool installed=true,keepInstalled=false,identityError=false;
    Result gameError=0,saveError=0,readError=0,verifyError=0;
    unsigned gameDeletes=0,saveDeletes=0;
    unsigned portDeletes=0;
    bool port=false,portEraseSaves=false;
    bool bindingError=false;
    bool languageError=false;
    int language=SetLanguage_ENUS;
    Result controlError=0;
    u64 controlSize=0x4000;
    std::vector<uint8_t> control;
    std::string version="1.0.0";
    std::string portFingerprint="same";
    std::vector<NsApplicationContentMetaStatus> contents;
    std::vector<FsSaveDataInfo> saves;
} mock;
void reset() {
    nm::backendExit();mock=Mock{};
    mock.contents.push_back({NcmContentMetaType_Application,NcmStorageId_SdCard,0,Forwarder});
    FsSaveDataInfo save;save.save_data_id=42;save.save_data_space_id=FsSaveDataSpaceId_User;
    save.save_data_type=FsSaveDataType_Account;save.uid.uid[0]=1;save.application_id=Forwarder;save.size=4096;
    mock.saves.push_back(save);
    nm::Environment env;assert(nm::backendInit(env));
}
nm::Game game() {
    std::vector<nm::Game> games;std::string error;
    assert(nm::loadGames(games,error));assert(games.size()==1);assert(games[0].metadataOk);return games[0];
}
std::vector<uint8_t> compressedControl(const std::vector<uint8_t> &entries) {
    z_stream stream{};assert(deflateInit2(&stream,Z_BEST_COMPRESSION,Z_DEFLATED,-MAX_WBITS,8,Z_DEFAULT_STRATEGY)==Z_OK);
    std::vector<uint8_t> zipped(0x4000);stream.next_in=const_cast<Bytef*>(entries.data());stream.avail_in=entries.size();stream.next_out=zipped.data();stream.avail_out=zipped.size();assert(deflate(&stream,Z_FINISH)==Z_STREAM_END);const auto length=stream.total_out;deflateEnd(&stream);assert(length<=0x2FFE);
    std::vector<uint8_t> control(0x4000);control[0x3215]=1;control[0]=length&255;control[1]=(length>>8)&255;std::copy_n(zipped.begin(),length,control.begin()+2);std::memcpy(control.data()+0x3060,"1.2.1",5);return control;
}
}
AppletType appletGetAppletType(){return mock.mode;}
Result svcGetInfo(u64 *out,int,u64,u64){*out=mock.running;return mock.identityError?77:0;}
Result setsysInitialize(){return 0;}void setsysExit(){}
Result setsysGetFirmwareVersion(SetSysFirmwareVersion *out){std::strcpy(out->display_version,"23.0.1");return 0;}
Result setInitialize(){return 0;}void setExit(){}
Result setGetSystemLanguage(u64 *out){*out=mock.language;return mock.languageError?88:0;}
Result setMakeLanguage(u64 code,SetLanguage *out){*out=static_cast<SetLanguage>(code);return 0;}
bool hosversionIsAtmosphere(){return true;}bool hosversionBefore(u8,u8,u8){return false;}
Result splInitialize(){return 0;}void splExit(){}
Result splGetConfig(SplConfigItem item,u64 *out){*out=int(item)==65000?((1ULL<<56)|(12ULL<<48)|(1ULL<<40)):1;return 0;}
Result nsInitialize(){return 0;}void nsExit(){}
Result accountInitialize(AccountServiceType){return 0;}void accountExit(){}
Result accountGetProfile(AccountProfile*,AccountUid){return 0;}
Result accountProfileGet(AccountProfile*,void*,AccountProfileBase *out){std::strcpy(out->nickname,"Test");return 0;}
void accountProfileClose(AccountProfile*){}
Result nsGetStorageSize(NcmStorageId,s64 *total,s64 *free){*total=100000;*free=50000;return 0;}
Result nsListApplicationRecord(NsApplicationRecord *out,s32,s32 offset,s32 *count){*count=offset==0&&mock.installed?1:0;if(*count)out[0].application_id=mock.app;return 0;}
Result nsListApplicationContentMetaStatus(u64,s32 offset,NsApplicationContentMetaStatus *out,s32 max,s32 *count){
    if(!mock.installed)return 123; // removed record's metadata is unavailable
    *count=0;for(size_t i=offset;i<mock.contents.size()&&*count<max;++i)out[(*count)++]=mock.contents[i];return 0;
}
Result nsGetApplicationControlData(NsApplicationControlSource,u64,NsApplicationControlData *out,size_t,u64 *size){*size=mock.controlSize;std::strcpy(out->nacp.languages[0].name,"Forwarder");std::memcpy(out->nacp.display_version,mock.version.data(),std::min(mock.version.size(),sizeof(out->nacp.display_version)));if(!mock.control.empty()){assert(mock.control.size()==sizeof(out->nacp));std::memcpy(&out->nacp,mock.control.data(),mock.control.size());}return mock.controlError;}
Result nsGetApplicationDesiredLanguage(NacpStruct *nacp,NacpLanguageEntry **out){*out=&nacp->languages[0];return mock.languageError?88:0;}
Result fsOpenSaveDataInfoReader(FsSaveDataInfoReader *reader,FsSaveDataSpaceId space){reader->space=space;reader->cursor=0;return mock.readError;}
Result fsSaveDataInfoReaderRead(FsSaveDataInfoReader *reader,FsSaveDataInfo *out,size_t max,s64 *count){
    *count=0;while(reader->cursor<mock.saves.size()&&size_t(*count)<max){auto save=mock.saves[reader->cursor++];if(save.save_data_space_id==reader->space)out[(*count)++]=save;}return mock.readError;
}
void fsSaveDataInfoReaderClose(FsSaveDataInfoReader*){}
Result nsDeleteApplicationCompletely(u64 id){assert(id==mock.app);++mock.gameDeletes;if(!mock.gameError&&!mock.keepInstalled)mock.installed=false;return mock.gameError;}
Result nsIsAnyApplicationEntityInstalled(u64,bool *out){*out=mock.installed;return mock.verifyError;}
Result nsDeleteSaveData(FsSaveDataSpaceId space,u64 id){++mock.saveDeletes;if(mock.saveError)return mock.saveError;mock.saves.erase(std::remove_if(mock.saves.begin(),mock.saves.end(),[&](const auto &save){return save.save_data_space_id==space&&save.save_data_id==id;}),mock.saves.end());return 0;}

// Backend orchestration uses a port-service spy here. The separate ports_test
// suite exercises the real filesystem discovery and removal implementation.
namespace nm {
bool discoverPortRemnants(std::vector<Game>&,std::string&){return true;}
bool inspectPort(const Game&,Plan &plan,uint32_t&,std::string&){
    if(mock.port){plan.portVerified=true;plan.portFingerprint=mock.portFingerprint;plan.portPaths={"sdmc:/switch/test-port"};plan.portEntries.push_back({"sdmc:/switch/test-port/file",1,0,false,false});}
    return true;
}
bool samePortPlan(const Plan&a,const Plan&b){return a.portVerified==b.portVerified&&a.portFingerprint==b.portFingerprint&&a.portPaths==b.portPaths;}
bool removePortData(const Plan&,bool eraseFiles,bool eraseSaves,Outcome&out){++mock.portDeletes;mock.portEraseSaves=eraseSaves;if(eraseFiles)++out.portFilesRemoved;return true;}
bool addRememberedPaths(std::vector<Game>&,std::string&){return true;}
bool rememberPaths(const Plan&,std::string&){return !mock.bindingError;}
void pruneRememberedPaths(const Plan&){}
}

int main(){
    reset();auto forwarder=game();assert(forwarder.id==Forwarder&&forwarder.sd);
    assert(forwarder.version=="1.0.0"&&forwarder.nroVersion.empty()&&forwarder.nroPath.empty());
    auto plan=nm::preparePlan(forwarder);assert(plan.valid&&plan.savesOk&&plan.saves.size()==1);
    auto result=nm::executePlan(plan,false,false);assert(result.complete&&result.gameRemoved&&mock.gameDeletes==1&&mock.saveDeletes==0&&mock.saves.size()==1);

    reset();plan=nm::preparePlan(game());mock.gameError=91;
    result=nm::executePlan(plan,true,false);assert(!result.gameRemoved&&!result.complete&&mock.gameDeletes==1&&mock.saveDeletes==0&&mock.saves.size()==1);

    reset();plan=nm::preparePlan(game());mock.saves[0].save_data_id=43;
    result=nm::executePlan(plan,true,false);assert(!result.gameRemoved&&mock.gameDeletes==0&&mock.saveDeletes==0);

    reset();plan=nm::preparePlan(game());mock.contents[0].version=1;
    result=nm::executePlan(plan,false,false);assert(!result.gameRemoved&&mock.gameDeletes==0&&mock.saveDeletes==0);

    reset();mock.saves.clear();plan=nm::preparePlan(game());assert(plan.valid&&plan.savesOk&&plan.saves.empty());
    result=nm::executePlan(plan,false,false);assert(result.complete&&mock.saveDeletes==0);

    reset();plan=nm::preparePlan(game());result=nm::executePlan(plan,true,false);
    assert(result.complete&&result.savesRemoved==1&&mock.saveDeletes==1&&mock.saves.empty());

    reset();plan=nm::preparePlan(game());mock.saveError=92;result=nm::executePlan(plan,true,false);
    assert(result.gameRemoved&&!result.complete&&result.savesRemoved==0&&mock.saves.size()==1);

    reset();plan=nm::preparePlan(game());mock.keepInstalled=true;result=nm::executePlan(plan,true,false);
    assert(!result.gameRemoved&&!result.complete&&mock.saveDeletes==0);

    reset();plan=nm::preparePlan(game());mock.verifyError=93;result=nm::executePlan(plan,true,false);
    assert(!result.gameRemoved&&!result.complete&&mock.saveDeletes==0);

    reset();auto candidate=game();mock.readError=94;plan=nm::preparePlan(candidate);
    assert(plan.valid&&!plan.savesOk);result=nm::executePlan(plan,true,false);assert(mock.gameDeletes==0&&mock.saveDeletes==0);
    result=nm::executePlan(plan,false,false);assert(result.gameRemoved&&mock.saveDeletes==0);

    reset();candidate=game();nm::backendExit();mock.mode=AppletType_LibraryApplet;
    nm::Environment env;nm::backendInit(env);assert(env.applet&&!nm::preparePlan(candidate).valid);

    reset();candidate=game();nm::backendExit();mock.running=Forwarder;
    nm::backendInit(env);assert(!nm::preparePlan(candidate).valid);

    reset();candidate=game();candidate.id=0x0100000000001000ULL;assert(!nm::preparePlan(candidate).valid);

    reset();candidate=game();nm::backendExit();mock.identityError=true;
    nm::backendInit(env);assert(env.initError!=0&&!nm::preparePlan(candidate).valid);

    reset();mock.contents.push_back({NcmContentMetaType_Patch,NcmStorageId_BuiltInUser,10,Forwarder^0x800ULL});
    mock.contents.push_back({NcmContentMetaType_AddOnContent,NcmStorageId_SdCard,1,Forwarder+0x1001ULL});
    candidate=game();assert(candidate.sd&&candidate.nand&&candidate.updates==1&&candidate.dlc==1);

    reset();mock.app=0x05FEED3C1FEC3000ULL;
    mock.contents={{NcmContentMetaType_Application,NcmStorageId_SdCard,0,mock.app},
                   {NcmContentMetaType_AddOnContent,NcmStorageId_SdCard,1,mock.app+0x1001ULL}};
    candidate=game();assert(candidate.id==mock.app&&candidate.dlc==1&&nm::preparePlan(candidate).valid);

    reset();mock.app=0x054E4D1C32BFD000ULL;
    mock.contents={{NcmContentMetaType_Application,NcmStorageId_SdCard,0,mock.app},
                   {NcmContentMetaType_AddOnContent,NcmStorageId_SdCard,1,mock.app+0x1FFFULL}};
    candidate=game();assert(candidate.id==mock.app&&candidate.dlc==1&&nm::preparePlan(candidate).valid);

    reset();mock.app=0xFFFFFFFFFFFFF000ULL;
    mock.contents={{NcmContentMetaType_Application,NcmStorageId_SdCard,0,mock.app},
                   {NcmContentMetaType_AddOnContent,NcmStorageId_SdCard,1,1ULL}};
    std::vector<nm::Game> overflowGames;std::string overflowError;
    assert(nm::loadGames(overflowGames,overflowError)&&overflowGames.empty()&&!overflowError.empty());

    reset();mock.contents[0].storageID=NcmStorageId_BuiltInSystem;
    std::vector<nm::Game> games;std::string error;assert(nm::loadGames(games,error)&&games.empty()&&!error.empty());

    reset();mock.saves[0].save_data_type=FsSaveDataType_System;plan=nm::preparePlan(game());
    assert(plan.savesOk&&plan.saves.empty());result=nm::executePlan(plan,true,false);assert(mock.saveDeletes==0);

    reset();mock.port=true;plan=nm::preparePlan(game());mock.gameError=91;
    result=nm::executePlan(plan,true,true);assert(mock.portDeletes==0&&mock.saveDeletes==0);

    reset();mock.port=true;plan=nm::preparePlan(game());
    result=nm::executePlan(plan,false,true);assert(result.complete&&mock.portDeletes==1&&!mock.portEraseSaves&&mock.saveDeletes==0);

    reset();mock.port=true;plan=nm::preparePlan(game());mock.portFingerprint="changed";
    result=nm::executePlan(plan,true,true);assert(!result.complete&&mock.gameDeletes==0&&mock.portDeletes==0&&mock.saveDeletes==0);

    reset();mock.port=true;nm::Game external;external.id=0;external.externalOnly=true;external.portKey="manual";external.manualPaths={"sdmc:/switch/test-port"};
    plan=nm::preparePlan(external);assert(plan.valid&&plan.savesOk&&plan.saves.empty());
    result=nm::executePlan(plan,true,true);assert(result.complete&&mock.gameDeletes==0&&mock.saveDeletes==0&&mock.portDeletes==1&&mock.portEraseSaves);

    reset();mock.installed=false;mock.port=true;external.id=Forwarder;external.portKey="ds2-nx";
    plan=nm::preparePlan(external);assert(plan.valid);
    result=nm::executePlan(plan,true,true);assert(result.complete&&mock.gameDeletes==0&&mock.portDeletes==1&&mock.saveDeletes==1);

    reset();mock.port=true;plan=nm::preparePlan(game());mock.bindingError=true;
    result=nm::executePlan(plan,true,true);assert(!result.complete&&mock.gameDeletes==0&&mock.portDeletes==0&&mock.saveDeletes==0);

    reset();mock.port=true;external.id=0;external.portKey="manual";plan=nm::preparePlan(external);
    result=nm::executePlan(plan,false,false);assert(!result.complete&&mock.gameDeletes==0&&mock.portDeletes==0);

    reset();mock.languageError=true;candidate=game();assert(candidate.version=="1.0.0");
    reset();mock.version="12345678901234567890";candidate=game();assert(candidate.version.empty());
    reset();mock.version.clear();candidate=game();assert(candidate.version.empty());

    std::vector<uint8_t> languages(18*0x300);const std::string wonder=u8"Super Mario Bros.™ Wonder";
    std::memcpy(languages.data(),wonder.data(),wonder.size());std::memcpy(languages.data()+0x200,"Nintendo",8);std::memcpy(languages.data()+6*0x300,"Wonder ES",9);std::memcpy(languages.data()+6*0x300+0x200,"Nintendo ES",11);
    reset();mock.control=compressedControl(languages);candidate=game();assert(candidate.name==wonder&&candidate.author=="Nintendo"&&candidate.version=="1.2.1");
    reset();mock.language=SetLanguage_ES;mock.control=compressedControl(languages);candidate=game();assert(candidate.name=="Wonder ES"&&candidate.author=="Nintendo ES"&&candidate.version=="1.2.1");
    reset();mock.language=500;mock.control=compressedControl(languages);candidate=game();assert(candidate.name==wonder);
    reset();mock.control=compressedControl(languages);mock.control[0x3215]=2;candidate=game();assert(candidate.name==nm::titleId(Forwarder)&&candidate.author.empty()&&candidate.version=="1.2.1");
    reset();mock.control=compressedControl(languages);std::fill(mock.control.begin()+2,mock.control.begin()+0x100,255);candidate=game();assert(candidate.name==nm::titleId(Forwarder)&&candidate.author.empty()&&candidate.version=="1.2.1");
    reset();mock.controlSize=0x3FFF;candidate=game();assert(candidate.name==nm::titleId(Forwarder)&&candidate.version.empty());
    reset();mock.controlError=90;candidate=game();assert(candidate.name==nm::titleId(Forwarder)&&candidate.version.empty());
    std::fill(languages.begin(),languages.end(),0);const std::string japanese=u8"日本語";std::memcpy(languages.data()+2*0x300,japanese.data(),japanese.size());
    reset();mock.language=0;mock.control=compressedControl(languages);candidate=game();assert(candidate.name==nm::titleId(Forwarder));
    std::memcpy(languages.data(),"English fallback",16);reset();mock.language=0;mock.control=compressedControl(languages);candidate=game();assert(candidate.name=="English fallback");

    nm::backendExit();std::cout<<"backend: 40 safety and metadata scenarios passed\n";
}
