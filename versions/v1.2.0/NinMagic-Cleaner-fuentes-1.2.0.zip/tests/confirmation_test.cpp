#include "confirmation.hpp"
#include <cassert>
int main() {
    using namespace nm;
    assert(decideSaves(0,false)==SaveDecision::Keep);
    assert(decideSaves(1,false)==SaveDecision::Unavailable);
    assert(decideSaves(1,true)==SaveDecision::Erase);
    assert(decideSaves(2,true)==SaveDecision::Cancel);
    assert(decideSaves(-1,true)==SaveDecision::Cancel);
    DeleteConfirmation c;
    // Entering with buttons held never counts, even after a long interval.
    assert(!c.update(true,0,true));assert(!c.update(true,99,true));
    assert(!c.update(false,100,true));assert(!c.update(true,103,true));
    assert(!c.update(false,104,false));
    assert(!c.update(true,105,true));assert(!c.update(true,106.99,true));
    // Releasing any one button restarts the hold.
    assert(!c.update(false,107,true));assert(c.progress()==0);
    assert(!c.update(true,108,true));assert(c.update(true,110,true));
    // A held chord fires once and reset requires another release.
    assert(!c.update(true,120,true));c.reset();assert(!c.update(true,140,true));
    assert(!c.update(false,141));assert(!c.update(true,142,true));assert(c.update(true,144,true));
}
