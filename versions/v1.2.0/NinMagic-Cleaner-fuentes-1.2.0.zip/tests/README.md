# Host checks

Run from the repository root with devkitPro's MSYS2 `g++` available on `PATH`:

```powershell
$testOutput = Join-Path $env:TEMP 'ninmagic-backend-test.exe'
g++ -std=c++17 -O2 -Wall -Wextra -Itests/mocks -Iinclude tests/backend_test.cpp source/backend.cpp -o $testOutput
& $testOutput
```

The host-only `tests/mocks/switch.h` supplies fake libnx services. These tests
never connect to the console, access NAND, or execute real content/save deletion.
They check forwarder IDs beginning with `05`, storage metadata, the explicit
save-deletion choice, unchanged confirmation inventories, partial service errors,
post-uninstall verification, system-title protection, applet protection and the
currently running title override. They also model the removed application record
returning an error if its metadata is queried after successful removal.

Expected result: `backend: 31 safety and metadata scenarios passed`.

The NRO build uses the real libnx headers. This suite verifies control flow, not
runtime compatibility with a particular console firmware. A successful build and
these tests do not replace a console test with a disposable game and save.

External port filesystem checks use a dedicated temporary sandbox and the
production SD selection policy. The `NM_PORTS_TEST` macro maps logical `sdmc:/`
paths into that sandbox; production builds contain no such redirection.

```powershell
$portTestOutput = Join-Path $env:TEMP 'ninmagic-ports-test.exe'
g++ -std=c++17 -O2 -Wall -Wextra -Werror -DNM_PORTS_TEST -Iinclude tests/ports_test.cpp source/ports.cpp source/sd_browser.cpp -o $portTestOutput
& $portTestOutput
```

Expected result: `ports: 26 filesystem and metadata scenarios passed`. Coverage includes
SHA-256 known vectors, metadata-free NROs, unique exact name/owner associations,
ambiguous names, post-confirmation file changes, preservation of unknown save
layouts, known Dead Space 2 orphan cleanup, protected descendants, manual paths,
and retention of the NRO when an earlier data-file deletion fails. Metadata cases verify declared NSP/NRO versions, missing versions, bounded fields and separate versions when the installed application and its linked NRO differ.

SD browser checks:

```powershell
g++ -std=c++17 -O2 -Wall -Wextra -Werror -Iinclude tests/sd_browser_test.cpp source/sd_browser.cpp -o "$env:TEMP/ninmagic-browser-test.exe"
& "$env:TEMP/ninmagic-browser-test.exe"
```

Expected: `86 SD path/browser checks passed`.

Receipt persistence checks:

```powershell
g++ -std=c++17 -O2 -Wall -Wextra -Werror -DNM_BINDINGS_TEST -Iinclude tests/bindings_test.cpp source/bindings.cpp source/sd_browser.cpp -o "$env:TEMP/ninmagic-bindings-test.exe"
& "$env:TEMP/ninmagic-bindings-test.exe"
```

Expected: `bindings: 19 persistence and safety scenarios passed`. These cover launcher disappearance, remembered remnants, preserved save roots, CRC/truncation checks and recovery of interrupted writes. All test deletion targets are dedicated temporary fixtures on the PC.
