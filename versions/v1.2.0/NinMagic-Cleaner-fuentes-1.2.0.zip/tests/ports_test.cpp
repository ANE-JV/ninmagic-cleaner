#include "ports.hpp"
#include <algorithm>
#include <cassert>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <unistd.h>
#include <zlib.h>
namespace fs=std::filesystem;
namespace nm {void portsSetTestRoot(const std::string&);void portsSetFailureForTest(const std::string&);std::string portsHashForTest(const std::string&);}
namespace {
fs::path sandbox;
void put(const std::string &relative,const std::string &data){auto p=sandbox/relative;fs::create_directories(p.parent_path());std::ofstream f(p,std::ios::binary);f.write(data.data(),data.size());}
void reset(){assert(sandbox.is_absolute()&&sandbox.filename().string().compare(0,20,"ninmagic-ports-test-")==0);fs::remove_all(sandbox);fs::create_directories(sandbox/"switch");nm::portsSetFailureForTest("");}
void nro(const std::string &path,const std::string &name="Demo",uint64_t owner=0,bool metadata=true,const std::string &version={}){
    std::string data(metadata?0x80+0x38+0x4000:0x80,'\0');
    std::memcpy(&data[0x10],"NRO0",4);data[0x18]=char(0x80);
    if(metadata){std::memcpy(&data[0x80],"ASET",4);data[0x98]=char(0x38);data[0xA1]=char(0x40);std::memcpy(&data[0xB8],name.data(),name.size());for(unsigned i=0;i<8;++i)data[0xB8+0x3078+i]=char(owner>>(8*i));std::memcpy(&data[0xB8+0x3060],version.data(),std::min(version.size(),size_t(16)));}
    put(path,data);
}
std::vector<uint8_t> compressedControl(const std::vector<uint8_t> &entries) {
    z_stream stream{};assert(deflateInit2(&stream,Z_BEST_COMPRESSION,Z_DEFLATED,-MAX_WBITS,8,Z_DEFAULT_STRATEGY)==Z_OK);
    std::vector<uint8_t> zipped(0x4000);stream.next_in=const_cast<Bytef*>(entries.data());stream.avail_in=entries.size();stream.next_out=zipped.data();stream.avail_out=zipped.size();assert(deflate(&stream,Z_FINISH)==Z_STREAM_END);const auto length=stream.total_out;deflateEnd(&stream);assert(length<=0x2FFE);
    std::vector<uint8_t> control(0x4000);control[0x3215]=1;control[0]=length&255;control[1]=(length>>8)&255;std::copy_n(zipped.begin(),length,control.begin()+2);std::memcpy(control.data()+0x3060,"1.2.1",5);return control;
}
void nroWithControl(const std::string &path,const std::vector<uint8_t> &control) {
    assert(control.size()==0x4000);std::string data(0x80+0x38+0x4000,'\0');
    std::memcpy(&data[0x10],"NRO0",4);data[0x18]=char(0x80);std::memcpy(&data[0x80],"ASET",4);data[0x98]=char(0x38);data[0xA1]=char(0x40);std::memcpy(&data[0xB8],control.data(),control.size());put(path,data);
}
nm::Plan planFor(nm::Game game){nm::Plan p;p.game=game;uint32_t error=0;std::string detail;assert(nm::inspectPort(game,p,error,detail));return p;}
std::vector<nm::Game> discover(std::vector<nm::Game> games={}){std::string error;assert(nm::discoverPortRemnants(games,error));return games;}
}
int main(){
    sandbox=fs::temp_directory_path()/("ninmagic-ports-test-"+std::to_string(getpid()));
    nm::portsSetTestRoot(sandbox.generic_string());
    assert(nm::portsHashForTest("")=="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
    assert(nm::portsHashForTest("abc")=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    assert(nm::portsHashForTest(std::string(1000000,'a'))=="cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0");
    reset();nro("switch/demo.nro");put("switch/demo/data.bin","asset");put("switch/demo/save.dat","save");
    auto games=discover();assert(games.size()==1&&games[0].externalOnly&&games[0].id==0);
    auto plan=planFor(games[0]);assert(plan.portVerified&&!plan.portSavePolicyKnown&&plan.portPaths.size()==2&&plan.externalSaveFiles==2);
    nm::Outcome result;assert(nm::removePortData(plan,true,false,result));assert(!fs::exists(sandbox/"switch/demo.nro")&&fs::exists(sandbox/"switch/demo/save.dat")&&fs::exists(sandbox/"switch/demo/data.bin"));

    reset();nro("switch/demo/demo.nro");put("switch/demo/file","x");games=discover();plan=planFor(games[0]);result={};
    assert(nm::removePortData(plan,true,false,result)&&fs::exists(sandbox/"switch/demo/demo.nro"));
    result={};assert(nm::removePortData(plan,true,true,result)&&!fs::exists(sandbox/"switch/demo"));

    reset();nro("switch/demo.nro","Exact Name",0x054E4DC8B31AA000ULL);nm::Game native;native.id=0x054E4DC8B31AA000ULL;native.name="Different Name";games=discover({native});assert(games.size()==1&&!games[0].portKey.empty()&&!games[0].externalOnly);

    reset();nro("switch/demo.nro","Exact Name");native.name="Exact Name";games=discover({native});assert(games.size()==1&&!games[0].portKey.empty());
    nm::Game duplicate=native;duplicate.id++;games=discover({native,duplicate});assert(games.size()==3&&games[2].externalOnly);

    reset();nro("switch/plain.nro","",0,false);games=discover();assert(games.size()==1&&games[0].name=="plain (NRO)");

    reset();put("switch/bad.nro","garbage");games=discover();assert(games.empty());

    reset();nro("switch/demo.nro");games=discover();plan=planFor(games[0]);put("switch/demo.nro","changed");result={};assert(!nm::removePortData(plan,true,true,result)&&fs::exists(sandbox/"switch/demo.nro"));

    reset();nro("switch/demo.nro");put("switch/demo/file","x");games=discover();plan=planFor(games[0]);put("switch/demo/new","added after confirmation");result={};assert(!nm::removePortData(plan,true,true,result)&&fs::exists(sandbox/"switch/demo.nro"));

    reset();put("ports/other/data","asset");nm::Game manual;manual.externalOnly=true;manual.portKey="manual";manual.manualPaths={"sdmc:/ports/other"};plan=planFor(manual);assert(plan.portVerified&&plan.externalSaveFiles==1);result={};assert(nm::removePortData(plan,true,false,result)&&fs::exists(sandbox/"ports/other/data"));result={};assert(nm::removePortData(plan,true,true,result)&&!fs::exists(sandbox/"ports/other"));

    reset();manual.manualPaths={"sdmc:/switch"};uint32_t error=0;std::string detail;assert(!nm::inspectPort(manual,plan,error,detail));
    manual.manualPaths={"sdmc:/ports/../switch/demo"};assert(!nm::inspectPort(manual,plan,error,detail));
    manual.manualPaths={"sdmc:/Nintendo/Contents"};assert(!nm::inspectPort(manual,plan,error,detail));

    reset();put("switch/ds2-nx/disc1/default.xex","XEX2");put("switch/ds2-nx/disc1/bigfile0.viv","assets");put("switch/ds2-nx/tu/default.xexp","XEXP");put("switch/ds2-nx/ds2/save","save");
    games=discover();assert(games.size()==1&&games[0].id==0x03DB1EA9E3264000ULL&&games[0].externalOnly);plan=planFor(games[0]);assert(plan.portSavePolicyKnown&&plan.externalSaveFiles==1);result={};assert(nm::removePortData(plan,true,false,result)&&fs::exists(sandbox/"switch/ds2-nx/ds2/save")&&!fs::exists(sandbox/"switch/ds2-nx/disc1/default.xex"));

    reset();put("switch/ds2-nx/disc1/default.xex","XEX2");put("switch/ds2-nx/disc1/bigfile0.viv","assets");put("switch/ds2-nx/tu/default.xexp","XEXP");put("switch/ds2-nx/ds2/save","save");games=discover();plan=planFor(games[0]);result={};assert(nm::removePortData(plan,true,true,result)&&!fs::exists(sandbox/"switch/ds2-nx"));

    reset();nro("switch/shared/a.nro","A");nro("switch/shared/b.nro","B");put("switch/shared/shared.lib","lib");games=discover();assert(games.size()==2);plan=planFor(games[0]);assert(plan.portPaths.size()==1&&plan.portPaths[0].find(".nro")!=std::string::npos);

    reset();nro("switch/demo/demo.nro");put("switch/demo/data","x");games=discover();plan=planFor(games[0]);nm::portsSetFailureForTest("sdmc:/switch/demo/data");result={};assert(!nm::removePortData(plan,true,true,result)&&fs::exists(sandbox/"switch/demo/demo.nro"));

    reset();put("ports/mixed/file","ok");put("ports/mixed/prod.keys","protected");manual.manualPaths={"sdmc:/ports/mixed"};assert(!nm::inspectPort(manual,plan,error,detail));

    reset();put("atmosphere/contents/054E4DC8B31AA000/romfs/mod","mod");manual.manualPaths={"sdmc:/atmosphere/contents/054E4DC8B31AA000"};plan=planFor(manual);result={};assert(nm::removePortData(plan,true,true,result)&&!fs::exists(sandbox/"atmosphere/contents/054E4DC8B31AA000"));

    reset();nro("switch/app.nro","App",0,true,"2.0.0");games=discover();assert(games.size()==1&&games[0].version=="2.0.0"&&games[0].nroVersion=="2.0.0"&&games[0].nroPath=="sdmc:/switch/app.nro");
    reset();nro("switch/app.nro","App",0,true,"2.0.0");native.name="App";native.version="1.0.0";games=discover({native});assert(games.size()==1&&games[0].version=="1.0.0"&&games[0].nroVersion=="2.0.0"&&games[0].nroPath=="sdmc:/switch/app.nro");
    reset();nro("switch/app.nro","App");games=discover();assert(games.size()==1&&games[0].version.empty()&&games[0].nroVersion.empty()&&games[0].nroPath=="sdmc:/switch/app.nro");
    reset();nro("switch/app.nro","App",0,false,"must not appear");games=discover();assert(games.size()==1&&games[0].version.empty()&&games[0].nroVersion.empty());
    reset();nro("switch/app.nro","App",0,true,"12345678901234567890");games=discover();assert(games.size()==1&&games[0].version.empty());

    std::vector<uint8_t> languages(18*0x300);const std::string port=u8"Port™ Demo";std::memcpy(languages.data(),port.data(),port.size());std::memcpy(languages.data()+0x200,"Publisher",9);std::memcpy(languages.data()+6*0x300,"Puerto ES",9);
    reset();nroWithControl("switch/compressed.nro",compressedControl(languages));games=discover();assert(games.size()==1&&games[0].name==port+" (NRO)"&&games[0].author=="Publisher"&&games[0].version=="1.2.1");
    reset();nroWithControl("switch/compressed.nro",compressedControl(languages));native.name="Puerto ES";games=discover({native});assert(games.size()==1&&!games[0].portKey.empty());
    reset();nroWithControl("switch/compressed.nro",compressedControl(languages));native.name="Port(TM) Demo";games=discover({native});assert(games.size()==2&&games[1].externalOnly);
    auto control=compressedControl(languages);std::fill(control.begin()+2,control.begin()+0x100,255);reset();nroWithControl("switch/compressed.nro",control);games=discover();assert(games.size()==1&&games[0].name=="compressed (NRO)"&&games[0].version=="1.2.1");
    control=compressedControl(languages);control[0x3215]=2;reset();nroWithControl("switch/compressed.nro",control);games=discover();assert(games.size()==1&&games[0].name=="compressed (NRO)"&&games[0].version=="1.2.1");
    std::fill(languages.begin(),languages.end(),0);languages[0]=0xC0;languages[1]=0xAF;reset();nroWithControl("switch/invalid.nro",compressedControl(languages));native.name=std::string("\xC0\xAF",2);games=discover({native});assert(games.size()==2&&games[1].name=="invalid (NRO)");
    std::fill(languages.begin(),languages.end(),0);const std::string japanese=u8"日本語";std::memcpy(languages.data()+2*0x300,japanese.data(),japanese.size());reset();nroWithControl("switch/japanese.nro",compressedControl(languages));games=discover();assert(games.size()==1&&games[0].name=="japanese (NRO)");
    std::memcpy(languages.data(),"English title",13);reset();nroWithControl("switch/japanese.nro",compressedControl(languages));games=discover();assert(games.size()==1&&games[0].name=="English title (NRO)");

    fs::remove_all(sandbox);std::cout<<"ports: 34 filesystem and metadata scenarios passed\n";
}
