#include "bindings.hpp"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <unistd.h>

namespace fs=std::filesystem;
namespace {
fs::path sandbox;
unsigned scenarios=0;
void put(const std::string &relative,const std::string &data){auto p=sandbox/relative;fs::create_directories(p.parent_path());std::ofstream f(p,std::ios::binary);f.write(data.data(),data.size());}
std::string bytes(const fs::path &path){std::ifstream f(path,std::ios::binary);return {std::istreambuf_iterator<char>(f),std::istreambuf_iterator<char>()};}
void reset(){fs::remove_all(sandbox);fs::create_directories(sandbox/"switch");}
nm::Plan makePlan(uint64_t id=0,const std::string &key="nro:sdmc:/switch/demo.nro"){
    nm::Plan plan;plan.valid=plan.portVerified=true;plan.game.id=id;plan.game.name="Juego de prueba";plan.game.portKey=key;plan.game.externalOnly=id==0;
    plan.portPaths={"sdmc:/switch/demo.nro","sdmc:/switch/demo"};return plan;
}
void fixture(){put("switch/demo.nro","NRO fixture");put("switch/demo/save.dat","saved progress");}
const std::string db="config/NinMagicCleaner/bindings.bin";
}
int main(){
    sandbox=fs::temp_directory_path()/("ninmagic-bindings-test-"+std::to_string(getpid()));nm::bindingsSetTestRoot(sandbox.generic_string());
    std::string error;std::vector<nm::Game> games;nm::Plan plan;
    reset();assert(nm::addRememberedPaths(games,error)&&games.empty());++scenarios;
    fixture();plan=makePlan();assert(nm::rememberPaths(plan,error));auto original=bytes(sandbox/db);assert(original.size()>20);assert(nm::addRememberedPaths(games,error)&&games.size()==1&&games[0].externalOnly&&games[0].portKey=="manual"&&games[0].manualPaths.size()==2);++scenarios;
    assert(nm::addRememberedPaths(games,error)&&games.size()==1);++scenarios;
    fs::remove(sandbox/"switch/demo.nro");games.clear();assert(nm::addRememberedPaths(games,error)&&games.size()==1&&games[0].manualPaths.size()==1&&games[0].manualPaths[0]=="sdmc:/switch/demo");++scenarios;
    nm::pruneRememberedPaths(plan);games.clear();assert(nm::addRememberedPaths(games,error)&&games.size()==1&&games[0].manualPaths.size()==1);++scenarios;
    fs::remove_all(sandbox/"switch/demo");nm::pruneRememberedPaths(plan);games.clear();assert(nm::addRememberedPaths(games,error)&&games.empty());++scenarios;

    reset();fixture();put("games/custom/save.dat","user-selected");plan=makePlan(0x03DB1EA9E3264000ULL,"ds2-nx");plan.game.manualPaths={"sdmc:/games/custom"};plan.portPaths.push_back("sdmc:/games/custom");assert(nm::rememberPaths(plan,error));
    nm::Game automatic;automatic.id=plan.game.id;automatic.name="Dead Space 2";automatic.portKey="ds2-nx";games={automatic};assert(nm::addRememberedPaths(games,error)&&games.size()==1&&!games[0].externalOnly&&games[0].manualPaths.size()==1&&games[0].manualPaths[0]=="sdmc:/games/custom");++scenarios;
    automatic.portKey.clear();games={automatic};assert(nm::addRememberedPaths(games,error)&&games.size()==1&&!games[0].externalOnly&&games[0].portKey=="manual"&&games[0].manualPaths.size()==3);++scenarios;

    reset();fixture();plan=makePlan();assert(nm::rememberPaths(plan,error));nm::Game generic;generic.name="Demo";generic.portKey=plan.game.portKey;generic.externalOnly=true;games={generic};assert(nm::addRememberedPaths(games,error)&&games.size()==1&&games[0].manualPaths.empty());++scenarios;
    fs::rename(sandbox/db,sandbox/(db+".pending"));games.clear();assert(nm::addRememberedPaths(games,error)&&games.size()==1);assert(nm::rememberPaths(plan,error)&&fs::exists(sandbox/db));++scenarios;
    fs::rename(sandbox/db,sandbox/(db+".backup"));games.clear();assert(nm::addRememberedPaths(games,error)&&games.size()==1);assert(nm::rememberPaths(plan,error)&&fs::exists(sandbox/db));++scenarios;

    original=bytes(sandbox/db);auto damaged=original;damaged.back()^=1;put(db,damaged);games.clear();assert(!nm::addRememberedPaths(games,error)&&games.empty());assert(!nm::rememberPaths(plan,error)&&bytes(sandbox/db)==damaged);++scenarios;
    put(db,"NMBIND01");assert(!nm::addRememberedPaths(games,error));assert(!nm::rememberPaths(plan,error)&&bytes(sandbox/db)=="NMBIND01");++scenarios;
    put(db,std::string(1024*1024+1,'x'));assert(!nm::addRememberedPaths(games,error)&&!nm::rememberPaths(plan,error));++scenarios;

    reset();fixture();plan=makePlan();plan.portPaths={"sdmc:/Nintendo/Contents"};assert(!nm::rememberPaths(plan,error)&&!fs::exists(sandbox/db));++scenarios;
    plan=makePlan();plan.valid=false;assert(!nm::rememberPaths(plan,error));++scenarios;
    plan={};assert(nm::rememberPaths(plan,error)&&!fs::exists(sandbox/db));++scenarios;
    plan=makePlan();plan.game.manualPaths={"sdmc:/config/NinMagicCleaner"};assert(!nm::rememberPaths(plan,error));++scenarios;
    reset();fixture();put("config","not a directory");plan=makePlan();assert(!nm::rememberPaths(plan,error));++scenarios;

    reset();fixture();plan=makePlan();assert(nm::rememberPaths(plan,error));fs::remove_all(sandbox/"switch/demo");std::error_code ec;fs::create_directory_symlink(sandbox/"switch",sandbox/"switch/demo",ec);
    if(!ec){games.clear();assert(nm::addRememberedPaths(games,error)&&games.size()==1&&games[0].manualPaths.size()==1);assert(!nm::rememberPaths(plan,error));++scenarios;}
    fs::remove_all(sandbox);std::cout<<"bindings: "<<scenarios<<" persistence and safety scenarios passed\n";
}
