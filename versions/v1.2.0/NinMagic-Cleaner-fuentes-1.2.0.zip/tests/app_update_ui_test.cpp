#include "app_update_ui.hpp"
#include <iostream>
#include <stdexcept>

namespace {unsigned checks=0;void check(bool b){++checks;if(!b)throw std::runtime_error("update UI action guard");}}
int main(){try{
    nm::AppUpdateInfo u;nm::CompletedUpdateInfo r;
    check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::None);
    u.configured=u.available=true;u.runningVersion="1.2.0";u.version="1.3.0";u.sha256=std::string(64,'a');u.size=2500000;
    check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::Install);
    u.sdVerified=true;u.sdVersion=u.version;u.sdSha256=u.sha256;u.sdSize=u.size;
    check(nm::publishedAppOnSd(u)&&nm::differentAppOnSd(u));check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::None);
    u.sdSha256=std::string(64,'b');check(!nm::publishedAppOnSd(u));check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::None);
    u.sdVersion="1.1.1";check(nm::differentAppOnSd(u));check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::None);
    u.sdVersion="1.2.1";check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::None);
    u.sdVersion=u.runningVersion;check(!nm::differentAppOnSd(u));check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::Install);
    check(nm::appUpdateAction(u,r,"manifest failed")==nm::AppUpdateAction::None);
    r.state=nm::CompletedUpdateState::CanArchive;check(nm::appUpdateAction(u,r,"legacy record retained")==nm::AppUpdateAction::ReviewCompletedRecord);check(!nm::completedReviewReady(r));
    r.token="00000001";r.reviewSha256=std::string(64,'c');check(nm::completedReviewReady(r));
    u.sdVersion=u.version;u.sdSha256=u.sha256;check(nm::publishedAppOnSd(u));check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::ReviewCompletedRecord);
    r.state=nm::CompletedUpdateState::Blocked;check(!nm::completedReviewReady(r));check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::None);
    r={};u.sdVersion=u.runningVersion;u.installed=true;check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::None);
    u.installed=false;u.available=false;check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::None);
    u.available=true;u.configured=false;check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::None);
    u.configured=true;u.sdVersion=u.version;u.sdSha256=u.sha256;u.sdSize=u.size+1;check(!nm::publishedAppOnSd(u));
    u.sdSize=u.size;u.sdVerified=false;check(!nm::publishedAppOnSd(u)&&!nm::differentAppOnSd(u));
    u={};u.configured=u.sdVerified=true;u.runningVersion=u.version=u.sdVersion="1.3.0";u.sha256=u.sdSha256=std::string(64,'a');u.size=u.sdSize=2500000;
    check(nm::currentPublishedApp(u,{}));check(!nm::currentPublishedApp(u,"HTTPS failed"));
    u.configured=false;check(!nm::currentPublishedApp(u,{}));u.configured=true;
    u.available=true;check(!nm::currentPublishedApp(u,{}));u.available=false;
    u.installed=true;check(!nm::currentPublishedApp(u,{}));u.installed=false;
    u.prepared=true;check(!nm::currentPublishedApp(u,{}));u.prepared=false;
    u.sdSha256=std::string(64,'b');check(!nm::currentPublishedApp(u,{}));u.sdSha256=u.sha256;
    u.sdSize++;check(!nm::currentPublishedApp(u,{}));u.sdSize=u.size;
    u.runningVersion="1.2.1";check(!nm::currentPublishedApp(u,{}));u.runningVersion=u.version;
    u.sdVerified=false;check(!nm::currentPublishedApp(u,{}));
    std::cout<<"app update UI: "<<checks<<" action guards PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
