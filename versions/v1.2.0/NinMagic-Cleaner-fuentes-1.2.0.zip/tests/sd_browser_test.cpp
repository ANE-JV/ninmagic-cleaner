#include "sd_browser.hpp"
#include <iostream>
#include <string>
#include <vector>

int main() {
    struct Case {const char *path;bool allowed;};
    const Case cases[]={
        {"sdmc:/switch/ds2-nx",true},
        {"sdmc:/switch/ds2-nx.nro",true},
        {"sdmc:/switch/ds2-nx/disc1/bigfile0.viv",true},
        {"sdmc:/games/Dead Space 2",true},
        {"sdmc:/roms/PSX/game.chd",true},
        {"sdmc:/config/mi-aplicacion/settings.ini",true},
        {"sdmc:/JKSV/Dead Space 2/mi perfil",true},
        {"sdmc:/switch/.overlays/example.ovl",true},
        {"sdmc:/switch/Crónicas/partida.sav",true},
        {"sdmc:/mis juegos/otra aplicación/",true},
        {"sdmc:/atmosphere/contents/0100000000010000",true},
        {"sdmc:/atmosphere/contents/03DB1EA9E3264000/",true},
        {"sdmc:/ATMOSPHERE/CONTENTS/0100abcdef123000",true},
        {"sdmc:/atmosphere/contents/FFFFFFFFFFFFFFFF",true},
        {"",false},{"sdmc:",false},{"/switch/game",false},{"D:/switch/game",false},
        {"SDMC:/switch/game",false},{"sdmc:/",false},
        {"sdmc:/switch",false},{"sdmc:/games",false},{"sdmc:/roms",false},
        {"sdmc:/config",false},{"sdmc:/JKSV",false},{"sdmc:/Checkpoint",false},
        {"sdmc:/switch/.overlays",false},
        {"sdmc:/Nintendo",false},{"sdmc:/NinTendo/Contents/registered/data.nca",false},
        {"sdmc:/emuMMC/RAW1/Nintendo",false},{"sdmc:/EMUMMC/emummc.ini",false},
        {"sdmc:/bootloader/payloads/hekate.bin",false},{"sdmc:/backup/nand.bin",false},
        {"sdmc:/.Trashes/game",false},{"sdmc:/$RECYCLE.BIN",false},
        {"sdmc:/atmosphere",false},{"sdmc:/atmosphere/contents",false},
        {"sdmc:/atmosphere/contents/0100000000000000",false},
        {"sdmc:/atmosphere/contents/0100000000000033",false},
        {"sdmc:/atmosphere/contents/010000000001000",false},
        {"sdmc:/atmosphere/contents/01000000000100000",false},
        {"sdmc:/atmosphere/contents/010000000001000g",false},
        {"sdmc:/atmosphere/contents/0100000000010000/cheats",false},
        {"sdmc:/atmosphere/config/system_settings.ini",false},
        {"sdmc:/switch/../Nintendo",false},{"sdmc:/switch/./game",false},
        {"sdmc:/switch/game/..",false},{"sdmc:/switch//game",false},
        {"sdmc://switch/game",false},{"sdmc:/switch/game//",false},
        {"sdmc:/switch\\game",false},{"sdmc:/switch/sdmc:/game",false},
        {"sdmc:/switch/game\n",false},{"sdmc:/switch/game\t",false},
        {"sdmc:/switch/game.",false},{"sdmc:/switch/game ",false},
        {"sdmc:/switch/*.nro",false},{"sdmc:/switch/game?.nro",false},
        {"sdmc:/prod.keys",false},{"sdmc:/games/game/TITLE.KEYS",false},
        {"sdmc:/switch/game/hbmenu.nro",false},{"sdmc:/fusee.bin",false},
        {"sdmc:/games/game/package3",false},{"sdmc:/exosphere.ini",false},
        {"sdmc:/switch/NinMagicCleaner/cache",false},
        {"sdmc:/switch/NinMagic-Cleaner.nro",false},
        {"sdmc:/switch/ninmagic_cleaner/config",false},
        {"sdmc:/switch/NinMagic-Cleaner/readme.txt",false},
    };
    unsigned checked=0;
    for(const auto &test:cases) {
        std::string error;
        bool actual=nm::isSafeSdSelection(test.path,error);
        if(actual!=test.allowed||(!actual&&error.empty())) {
            std::cerr<<"Unexpected selection policy: "<<test.path<<" -> "<<actual<<" ("<<error<<")\n";return 1;
        }
        ++checked;
    }
    std::string canonical,error;
    if(!nm::normalizeSdPath("sdmc:/",canonical,error)||canonical!="sdmc:/") return 2;
    if(!nm::normalizeSdPath("sdmc:/switch/Mi Juego/",canonical,error)||canonical!="sdmc:/switch/Mi Juego") return 3;
    if(nm::isSafeSdSelection(std::string("sdmc:/switch/game\0/../Nintendo",29),error)) return 4;
    if(nm::isSafeSdSelection("sdmc:/switch/"+std::string(256,'a'),error)) return 5;
    if(nm::isSafeSdSelection("sdmc:/"+std::string(770,'a'),error)) return 6;
    std::vector<nm::BrowserEntry> entries(1);
    if(nm::browseSd("sdmc:/switch/../Nintendo",entries,error)||!entries.empty()||error.empty()) return 7;
    struct TreeCase {const char *path;const char *root;bool allowed;};
    const TreeCase trees[]={
        {"sdmc:/switch/game/data.bin","sdmc:/switch/game",true},
        {"sdmc:/SWITCH/Game/data.bin","sdmc:/switch/game",true},
        {"sdmc:/switch/game","sdmc:/switch/game",true},
        {"sdmc:/switch/game2/data.bin","sdmc:/switch/game",false},
        {"sdmc:/switch/other/data.bin","sdmc:/switch/game",false},
        {"sdmc:/switch/game/prod.keys","sdmc:/switch/game",false},
        {"sdmc:/switch/game/data.bin","sdmc:/switch",false},
        {"sdmc:/atmosphere/contents/0100000000010000/cheats/file.txt","sdmc:/atmosphere/contents/0100000000010000",true},
        {"sdmc:/atmosphere/contents/0100000000010000/romfs/package3","sdmc:/atmosphere/contents/0100000000010000",false},
        {"sdmc:/atmosphere/contents/0100000000000000/file.bin","sdmc:/atmosphere/contents/0100000000000000",false},
        {"sdmc:/atmosphere/contents/0100000000010000/file.bin","sdmc:/atmosphere/contents",false},
        {"sdmc:/atmosphere/contents/0100000000010001/file.bin","sdmc:/atmosphere/contents/0100000000010000",false},
    };
    for(const auto &test:trees) {
        if(nm::isSafeSdDescendant(test.path,test.root,error)!=test.allowed) {
            std::cerr<<"Unexpected subtree policy: "<<test.path<<" below "<<test.root<<"\n";return 8;
        }
        ++checked;
    }
    std::cout<<checked+6<<" SD path/browser checks passed\n";
    return 0;
}
