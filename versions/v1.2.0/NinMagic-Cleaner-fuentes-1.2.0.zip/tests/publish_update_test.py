"""Checks the offline publication packet; no requests or uploads occur."""
from pathlib import Path
import hashlib
import json
import struct
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))
from publish_update import prepare, inspect_nro


def nro(version="1.3.0"):
    code, nacp = 0x1000, 72
    data = bytearray(code + nacp + 0x4000 + 80)
    data[0x10:0x14] = b"NRO0"
    struct.pack_into("<I", data, 0x18, code)
    for index, pair in enumerate(((0, 0x800), (0x800, 0x400), (0xC00, 0x400))):
        struct.pack_into("<II", data, 0x20 + index * 8, *pair)
    struct.pack_into("<II6Q", data, code, 0x54455341, 0, 56, 16, nacp, 0x4000, nacp + 0x4000, 80)
    data[code + nacp:code + nacp + 16] = b"NinMagic Cleaner"
    data[code + nacp + 0x200:code + nacp + 0x208] = b"NinMagic"
    data[code + nacp + 0x3060:code + nacp + 0x3060 + len(version)] = version.encode("ascii")
    return bytes(data)


class PublicationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ninmagic-cleaner-publication-test-")
        self.root = Path(self.temp.name)
        self.nro = self.root / "input.nro"
        self.nro.write_bytes(nro())
        self.base = "https://raw.githubusercontent.com/ANE-JV/ninmagic-cleaner/main"

    def tearDown(self):
        self.temp.cleanup()

    def test_layout_and_manifest(self):
        report = prepare(self.nro, self.base, self.root / "output")
        payload = self.root / "output/versions/v1.3.0/NinMagic-Cleaner.nro"
        self.assertEqual(payload.read_bytes(), self.nro.read_bytes())
        manifest = (self.root / "output/update.txt").read_text("ascii")
        self.assertEqual(manifest, f"NINMAGIC-CLEANER-UPDATE-1\nversion=1.3.0\nurl={self.base}/versions/v1.3.0/NinMagic-Cleaner.nro\nsha256={hashlib.sha256(payload.read_bytes()).hexdigest()}\nsize={payload.stat().st_size}\n")
        self.assertFalse(report["uploaded"])
        config = self.root / "output/device-config/config/NinMagicCleaner/update-url.txt"
        self.assertEqual(config.read_text("ascii"), self.base + "/update.txt\n")

    def test_immutable_same_version(self):
        output = self.root / "output"
        prepare(self.nro, self.base, output)
        original = (output / "update.txt").read_bytes()
        prepare(self.nro, self.base, output)
        changed = bytearray(self.nro.read_bytes())
        changed[0x100] = 1
        self.nro.write_bytes(changed)
        with self.assertRaises(ValueError):
            prepare(self.nro, self.base, output)
        self.assertEqual((output / "update.txt").read_bytes(), original)

    def test_newer_version_and_downgrade_refusal(self):
        output = self.root / "output"
        prepare(self.nro, self.base, output)
        self.nro.write_bytes(nro("1.3.1"))
        report = prepare(self.nro, self.base, output)
        self.assertEqual(report["version"], "1.3.1")
        self.assertTrue((output / "versions/v1.3.0/NinMagic-Cleaner.nro").exists())
        self.nro.write_bytes(nro("1.3.0"))
        with self.assertRaises(ValueError):
            prepare(self.nro, self.base, output)
        self.assertIn("version=1.3.1", (output / "update.txt").read_text("ascii"))

    def test_invalid_nro_and_https(self):
        for version in ("1.03.0", "65536.0.0", "1.3", "1.3.0-beta"):
            with self.assertRaises(ValueError):
                inspect_nro(nro(version))
        for url in ("http://example.com", "https://u:p@example.com", "https://example.com/#x"):
            with self.assertRaises(ValueError):
                prepare(self.nro, url, self.root / "output")
        binary = bytearray(nro())
        struct.pack_into("<I", binary, 0x18, 0xFFFFFFFF)
        with self.assertRaises(ValueError):
            inspect_nro(binary)


if __name__ == "__main__":
    unittest.main()
