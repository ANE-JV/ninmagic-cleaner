#pragma once
// Host-only libnx test double. It is never included by the NRO build.
#include <cstdint>
#include <cstddef>
using u8=uint8_t;using u32=uint32_t;using u64=uint64_t;using s32=int32_t;using s64=int64_t;using Result=uint32_t;
#define R_SUCCEEDED(rc) ((rc)==0)
#define R_FAILED(rc) ((rc)!=0)
#define FS_MAX_PATH 0x301
#define CUR_PROCESS_HANDLE 0xFFFF8001
enum {InfoType_ProgramId=18};
enum AppletType {AppletType_Application=0,AppletType_LibraryApplet=2};
enum SplConfigItem {SplConfigItem_Dummy=0};
enum AccountServiceType {AccountServiceType_Administrator=2};
enum FsSaveDataSpaceId {FsSaveDataSpaceId_User=1,FsSaveDataSpaceId_Temporary=3,FsSaveDataSpaceId_SdUser=4};
enum {FsSaveDataType_System=0,FsSaveDataType_Account=1,FsSaveDataType_Bcat=2,FsSaveDataType_Device=3,FsSaveDataType_Temporary=4,FsSaveDataType_Cache=5,FsSaveDataType_SystemBcat=6};
enum NcmStorageId {NcmStorageId_GameCard=2,NcmStorageId_BuiltInSystem=3,NcmStorageId_BuiltInUser=4,NcmStorageId_SdCard=5};
enum {NcmContentMetaType_Application=0x80,NcmContentMetaType_Patch=0x81,NcmContentMetaType_AddOnContent=0x82};
enum NsApplicationControlSource {NsApplicationControlSource_Storage=0};
enum SetLanguage {SetLanguage_ENUS=1,SetLanguage_ES=5};
struct AccountUid {u64 uid[2]{};};
struct AccountProfile {};
struct AccountProfileBase {char nickname[32]{};};
struct NacpLanguageEntry {char name[512]{};char author[256]{};};
struct NacpStruct {NacpLanguageEntry languages[16]{};uint8_t before_version[0x60]{};char display_version[16]{};uint8_t remainder[0xF90]{};};
static_assert(sizeof(NacpStruct)==0x4000,"NACP mock must preserve the wire layout");
struct NsApplicationControlData {NacpStruct nacp;};
struct NsApplicationRecord {u64 application_id=0;};
struct NsApplicationContentMetaStatus {u8 meta_type=0,storageID=0;u32 version=0;u64 application_id=0;};
struct FsSaveDataInfo {u64 save_data_id=0;u8 save_data_space_id=0,save_data_type=0;AccountUid uid{};u64 application_id=0,size=0;};
struct FsSaveDataInfoReader {int space=0;size_t cursor=0;};
struct SetSysFirmwareVersion {char display_version[24]{};};
AppletType appletGetAppletType();
Result svcGetInfo(u64*,int,u64,u64);
Result setsysInitialize();void setsysExit();Result setsysGetFirmwareVersion(SetSysFirmwareVersion*);
Result setInitialize();void setExit();Result setGetSystemLanguage(u64*);Result setMakeLanguage(u64,SetLanguage*);
bool hosversionIsAtmosphere();bool hosversionBefore(u8,u8,u8);
Result splInitialize();void splExit();Result splGetConfig(SplConfigItem,u64*);
Result nsInitialize();void nsExit();
Result accountInitialize(AccountServiceType);void accountExit();
Result accountGetProfile(AccountProfile*,AccountUid);Result accountProfileGet(AccountProfile*,void*,AccountProfileBase*);void accountProfileClose(AccountProfile*);
Result nsGetStorageSize(NcmStorageId,s64*,s64*);
Result nsListApplicationRecord(NsApplicationRecord*,s32,s32,s32*);
Result nsListApplicationContentMetaStatus(u64,s32,NsApplicationContentMetaStatus*,s32,s32*);
Result nsGetApplicationControlData(NsApplicationControlSource,u64,NsApplicationControlData*,size_t,u64*);
Result nsGetApplicationDesiredLanguage(NacpStruct*,NacpLanguageEntry**);
Result fsOpenSaveDataInfoReader(FsSaveDataInfoReader*,FsSaveDataSpaceId);
Result fsSaveDataInfoReaderRead(FsSaveDataInfoReader*,FsSaveDataInfo*,size_t,s64*);
void fsSaveDataInfoReaderClose(FsSaveDataInfoReader*);
Result nsDeleteApplicationCompletely(u64);
Result nsIsAnyApplicationEntityInstalled(u64,bool*);
Result nsDeleteSaveData(FsSaveDataSpaceId,u64);
