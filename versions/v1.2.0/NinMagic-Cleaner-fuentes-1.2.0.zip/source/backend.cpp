#include "backend.hpp"
#include "ports.hpp"
#include "bindings.hpp"
#include "title_metadata.hpp"
#include <switch.h>
#include <algorithm>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <set>
#include <sys/stat.h>
#include <tuple>
#include <unistd.h>

namespace nm {
namespace {
constexpr uint64_t MinUserTitle=0x0100000000010000ULL;
constexpr size_t MaxRecords=16384, MaxTreeEntries=100000;
constexpr uint32_t InvalidPlan=0xE001, ChangedPlan=0xE002, UnsafePath=0xE003;
bool nsReady=false, accountReady=false, applicationMode=false, identityKnown=false;
uint64_t currentApplication=0;

std::string resultText(uint32_t rc) {
    char text[24]; std::snprintf(text,sizeof(text),"0x%08lX",static_cast<unsigned long>(rc)); return text;
}
uint32_t fsError() {return 0xE100u+static_cast<uint32_t>(errno ? errno : EIO);}
size_t boundedLength(const char *text,size_t capacity) {
    size_t length=0;while(length<capacity&&text[length])++length;return length;
}
int titleLanguage() {
    if(R_FAILED(setInitialize()))return -1;
    u64 code=0;SetLanguage language=SetLanguage_ENUS;
    Result rc=setGetSystemLanguage(&code);
    if(R_SUCCEEDED(rc))rc=setMakeLanguage(code,&language);
    setExit();
    static constexpr int indices[]={2,0,3,4,7,6,14,12,8,10,11,13,1,9,5,14,13,15};
    const int index=static_cast<int>(language);
    return R_SUCCEEDED(rc)&&index>=0&&index<18?indices[index]:-1;
}
// Installed homebrew forwarders can use IDs outside Nintendo's 01 prefix.
// Trust the NS application record and verified application content types,
// while retaining the lower bound that excludes reserved system TitleIDs.
bool isUserTitle(uint64_t id) {return id>=MinUserTitle;}
bool isAllowedSaveType(uint8_t type) {
    return type==FsSaveDataType_Account || type==FsSaveDataType_Device || type==FsSaveDataType_Bcat ||
           type==FsSaveDataType_Cache || type==FsSaveDataType_Temporary;
}
bool isAllowedSaveSpace(uint8_t space) {
    return space==FsSaveDataSpaceId_User || space==FsSaveDataSpaceId_SdUser || space==FsSaveDataSpaceId_Temporary;
}
bool contentBelongs(uint64_t app, const Content &c) {
    if(!isUserTitle(c.id)) return false;
    switch(c.type) {
    case NcmContentMetaType_Application: return c.id==app;
    case NcmContentMetaType_Patch: return c.id==(app^0x800ULL);
    // DLC IDs occupy [application + 0x1000, application + 0x1FFF].
    // Subtract only after ordering to avoid overflow for custom forwarder IDs.
    case NcmContentMetaType_AddOnContent: return c.id>app && c.id-app>=0x1000ULL && c.id-app<=0x1FFFULL;
    default: return false;
    }
}
auto contentKey(const Content &c) {return std::make_tuple(c.id,c.type,c.storage,c.version);}
auto saveKey(const Save &s) {return std::make_tuple(s.space,s.id,s.applicationId,s.type,s.uid0,s.uid1,s.size);}
bool sameContents(const Game &a,const Game &b) {
    if(a.id!=b.id || a.contents.size()!=b.contents.size()) return false;
    for(size_t i=0;i<a.contents.size();++i) if(contentKey(a.contents[i])!=contentKey(b.contents[i])) return false;
    return true;
}
bool sameSaves(const std::vector<Save> &a,const std::vector<Save> &b) {
    if(a.size()!=b.size()) return false;
    for(size_t i=0;i<a.size();++i) if(saveKey(a[i])!=saveKey(b[i])) return false;
    return true;
}

bool readContents(Game &game,uint32_t &error) {
    game.contents.clear(); game.sd=game.nand=game.card=false; game.updates=game.dlc=0;
    game.metadataOk=false;
    s32 offset=0;
    while(true) {
        NsApplicationContentMetaStatus batch[32]{}; s32 count=0;
        Result rc=nsListApplicationContentMetaStatus(game.id,offset,batch,32,&count);
        if(R_FAILED(rc)) {error=rc;return false;}
        if(count<0 || count>32 || static_cast<size_t>(offset+count)>MaxRecords) {error=InvalidPlan;return false;}
        if(count==0) break;
        for(s32 i=0;i<count;++i) {
            Content c{batch[i].application_id,batch[i].version,batch[i].storageID,batch[i].meta_type};
            if(!contentBelongs(game.id,c) || (c.storage!=NcmStorageId_SdCard && c.storage!=NcmStorageId_BuiltInUser && c.storage!=NcmStorageId_GameCard)) {
                error=InvalidPlan;return false;
            }
            game.sd|=c.storage==NcmStorageId_SdCard;
            game.nand|=c.storage==NcmStorageId_BuiltInUser;
            game.card|=c.storage==NcmStorageId_GameCard;
            if(c.type==NcmContentMetaType_Patch) ++game.updates;
            if(c.type==NcmContentMetaType_AddOnContent) ++game.dlc;
            game.contents.push_back(c);
        }
        offset+=count;
    }
    std::sort(game.contents.begin(),game.contents.end(),[](const Content &a,const Content &b){return contentKey(a)<contentKey(b);});
    if(std::adjacent_find(game.contents.begin(),game.contents.end(),[](const Content &a,const Content &b){return contentKey(a)==contentKey(b);})!=game.contents.end()) {
        error=InvalidPlan;return false;
    }
    game.metadataOk=true;
    return true;
}

std::string userName(const FsSaveDataInfo &info) {
    if(info.save_data_type==FsSaveDataType_Device) return "Compartida por todos los perfiles";
    if(info.save_data_type==FsSaveDataType_Bcat) return "Datos BCAT";
    if(info.save_data_type==FsSaveDataType_Cache) return "Cache del juego";
    if(info.save_data_type==FsSaveDataType_Temporary) return "Datos temporales";
    if(accountReady) {
        AccountProfile profile{};
        if(R_SUCCEEDED(accountGetProfile(&profile,info.uid))) {
            AccountProfileBase base{};
            Result rc=accountProfileGet(&profile,nullptr,&base);
            accountProfileClose(&profile);
            if(R_SUCCEEDED(rc)) return std::string(base.nickname,boundedLength(base.nickname,sizeof(base.nickname)));
        }
    }
    return "Perfil sin nombre disponible";
}

bool readSaves(uint64_t application,std::vector<Save> &saves,uint32_t &error) {
    saves.clear();
    const FsSaveDataSpaceId spaces[]={FsSaveDataSpaceId_User,FsSaveDataSpaceId_SdUser,FsSaveDataSpaceId_Temporary};
    for(FsSaveDataSpaceId space:spaces) {
        // These spaces are supported by the firmware required for deletion.
        FsSaveDataInfoReader reader{};
        Result rc=fsOpenSaveDataInfoReader(&reader,space);
        if(R_FAILED(rc)) {error=rc;return false;}
        size_t seen=0;
        while(true) {
            FsSaveDataInfo batch[32]{}; s64 count=0;
            rc=fsSaveDataInfoReaderRead(&reader,batch,32,&count);
            if(R_FAILED(rc) || count<0 || count>32 || seen+static_cast<size_t>(count)>MaxRecords) {
                fsSaveDataInfoReaderClose(&reader);error=R_FAILED(rc)?rc:InvalidPlan;return false;
            }
            if(count==0) break;
            seen+=static_cast<size_t>(count);
            for(s64 i=0;i<count;++i) {
                const auto &info=batch[i];
                if(info.application_id!=application || !isAllowedSaveType(info.save_data_type)) continue;
                if(info.save_data_space_id!=space || !isAllowedSaveSpace(info.save_data_space_id) || info.save_data_id==0) {
                    fsSaveDataInfoReaderClose(&reader);error=InvalidPlan;return false;
                }
                Save save;
                save.id=info.save_data_id;save.applicationId=info.application_id;save.size=info.size;
                save.uid0=info.uid.uid[0];save.uid1=info.uid.uid[1];save.space=info.save_data_space_id;save.type=info.save_data_type;
                save.user=userName(info);saves.push_back(std::move(save));
            }
        }
        fsSaveDataInfoReaderClose(&reader);
    }
    std::sort(saves.begin(),saves.end(),[](const Save &a,const Save &b){return saveKey(a)<saveKey(b);});
    if(std::adjacent_find(saves.begin(),saves.end(),[](const Save &a,const Save &b){return a.space==b.space&&a.id==b.id;})!=saves.end()) {
        error=InvalidPlan;return false;
    }
    return true;
}

// A tree is inventoried before any destructive operation. Only regular files
// and directories below one exact, enumerated Atmosphere TitleID are accepted.
bool walkTree(const std::string &path,std::vector<std::string> &postorder,uint32_t &error,unsigned depth=0) {
    if(depth>32 || postorder.size()>MaxTreeEntries || path.size()>=FS_MAX_PATH) {error=UnsafePath;return false;}
    struct stat st{};
    if(lstat(path.c_str(),&st)!=0) {error=fsError();return false;}
    if(S_ISLNK(st.st_mode) || (!S_ISDIR(st.st_mode)&&!S_ISREG(st.st_mode))) {error=UnsafePath;return false;}
    if(S_ISDIR(st.st_mode)) {
        DIR *dir=opendir(path.c_str());
        if(!dir) {error=fsError();return false;}
        errno=0;
        while(auto *entry=readdir(dir)) {
            const std::string name=entry->d_name;
            if(name=="." || name=="..") continue;
            if(name.find('/')!=std::string::npos || name.find('\\')!=std::string::npos || name.find(':')!=std::string::npos) {
                closedir(dir);error=UnsafePath;return false;
            }
            if(!walkTree(path+"/"+name,postorder,error,depth+1)) {closedir(dir);return false;}
            errno=0;
        }
        const int readError=errno;
        if(closedir(dir)!=0 || readError) {error=0xE100u+static_cast<uint32_t>(readError?readError:errno);return false;}
    }
    postorder.push_back(path);
    return true;
}
bool prefixDirectories(uint32_t &error) {
    const char *prefixes[]={"sdmc:/atmosphere","sdmc:/atmosphere/contents"};
    for(const char *prefix:prefixes) {
        struct stat st{};
        if(lstat(prefix,&st)!=0) {if(errno==ENOENT)return true;error=fsError();return false;}
        if(!S_ISDIR(st.st_mode)||S_ISLNK(st.st_mode)) {error=UnsafePath;return false;}
    }
    return true;
}
bool readExtras(const Game &game,std::vector<std::string> &paths,uint32_t &error) {
    paths.clear();
    if(!isUserTitle(game.id)) return true;
    if(!prefixDirectories(error)) return false;
    std::set<uint64_t> ids{game.id};
    for(const auto &content:game.contents) if(contentBelongs(game.id,content)) ids.insert(content.id);
    for(uint64_t id:ids) {
        std::string path="sdmc:/atmosphere/contents/"+titleId(id);
        struct stat st{};
        if(lstat(path.c_str(),&st)!=0) {if(errno==ENOENT)continue;error=fsError();return false;}
        if(!S_ISDIR(st.st_mode)||S_ISLNK(st.st_mode)) {error=UnsafePath;return false;}
        std::vector<std::string> tree;
        if(!walkTree(path,tree,error)) return false;
        paths.push_back(std::move(path));
    }
    std::sort(paths.begin(),paths.end());
    return true;
}
bool removeExtraTree(const std::string &root,uint32_t &error) {
    if(!prefixDirectories(error)) return false;
    std::vector<std::string> tree;
    if(!walkTree(root,tree,error)) return false;
    for(const auto &path:tree) {
        // Validate every parent afresh, so a replaced parent cannot redirect a
        // file removal outside the approved root. FAT itself has no symlinks.
        if(!prefixDirectories(error)) return false;
        for(size_t slash=root.size();slash<path.size();++slash) {
            if(path[slash]!='/') continue;
            struct stat parent{};
            if(lstat(path.substr(0,slash).c_str(),&parent)!=0) {error=fsError();return false;}
            if(!S_ISDIR(parent.st_mode)||S_ISLNK(parent.st_mode)) {error=UnsafePath;return false;}
        }
        struct stat st{};
        if(lstat(path.c_str(),&st)!=0) {error=fsError();return false;}
        if(S_ISLNK(st.st_mode)||(!S_ISDIR(st.st_mode)&&!S_ISREG(st.st_mode))) {error=UnsafePath;return false;}
        if((S_ISDIR(st.st_mode)?rmdir(path.c_str()):unlink(path.c_str()))!=0) {error=fsError();return false;}
    }
    struct stat after{};
    if(lstat(root.c_str(),&after)==0 || errno!=ENOENT) {error=UnsafePath;return false;}
    return true;
}
}

bool backendInit(Environment &env) {
    env.applet=appletGetAppletType()!=AppletType_Application;
    applicationMode=!env.applet;
    Result rc=svcGetInfo(&currentApplication,InfoType_ProgramId,CUR_PROCESS_HANDLE,0);
    const Result identityError=rc;
    identityKnown=R_SUCCEEDED(rc) && currentApplication!=0;
    if(identityKnown) currentApplication&=~0xFFFULL;

    SetSysFirmwareVersion firmware{};
    rc=setsysInitialize();
    if(R_SUCCEEDED(rc)) {
        rc=setsysGetFirmwareVersion(&firmware);setsysExit();
        if(R_SUCCEEDED(rc)) env.firmware=std::string(firmware.display_version,boundedLength(firmware.display_version,sizeof(firmware.display_version)));
    }
    if(R_FAILED(rc)) env.firmware="No disponible ("+resultText(rc)+")";

    env.atmosphereDetected=hosversionIsAtmosphere();
    env.atmosphere=env.atmosphereDetected?"Atmosphere detectado":"Sin Atmosphere detectado";
    rc=splInitialize();
    if(R_SUCCEEDED(rc)) {
        u64 version=0;
        Result configRc=splGetConfig(static_cast<SplConfigItem>(65000),&version);
        if(R_SUCCEEDED(configRc)) {
            char text[64];std::snprintf(text,sizeof(text),"Atmosphere %u.%u.%u",unsigned((version>>56)&0xFF),unsigned((version>>48)&0xFF),unsigned((version>>40)&0xFF));
            env.atmosphere=text;env.atmosphereDetected=true;
        }
        u64 type=0;
        configRc=splGetConfig(static_cast<SplConfigItem>(65007),&type);
        // The current Atmosphere implementation returns 0/1 (inactive/active),
        // despite this config item's historical name "EmummcType".
        if(R_SUCCEEDED(configRc)) env.nand=type==0?"sysMMC activa":(type==1?"emuMMC activa":"Entorno sin verificar");
        splExit();
    }
    rc=nsInitialize();
    nsReady=R_SUCCEEDED(rc);
    if(!nsReady) {env.initError=rc;return false;}
    accountReady=R_SUCCEEDED(accountInitialize(AccountServiceType_Administrator));
    refreshStorage(env);
    if(!identityKnown) env.initError=R_FAILED(identityError)?identityError:InvalidPlan;
    return true;
}
void backendExit() {
    if(accountReady) accountExit();
    if(nsReady) nsExit();
    nsReady=accountReady=false;
}
void refreshStorage(Environment &env) {
    if(!nsReady) return;
    s64 total=0,free=0;
    if(R_SUCCEEDED(nsGetStorageSize(NcmStorageId_SdCard,&total,&free))&&total>=0&&free>=0) {env.sdTotal=total;env.sdFree=free;}
    if(R_SUCCEEDED(nsGetStorageSize(NcmStorageId_BuiltInUser,&total,&free))&&total>=0&&free>=0) {env.nandTotal=total;env.nandFree=free;}
}
bool loadGames(std::vector<Game> &games,std::string &error) {
    games.clear();error.clear();
    if(!nsReady) {error="No se pudo abrir el servicio de aplicaciones.";return false;}
    s32 offset=0;size_t unreadable=0;const int preferredLanguage=titleLanguage();
    while(true) {
        NsApplicationRecord records[32]{};s32 count=0;
        Result rc=nsListApplicationRecord(records,32,offset,&count);
        if(R_FAILED(rc)) {error="No se pudieron enumerar los juegos: "+resultText(rc);games.clear();return false;}
        if(count<0||count>32||static_cast<size_t>(offset+count)>MaxRecords) {error="El inventario de juegos no es valido.";games.clear();return false;}
        if(count==0) break;
        for(s32 i=0;i<count;++i) {
            Game game;game.id=records[i].application_id;
            if(!isUserTitle(game.id) || (game.id&0xFFF)!=0) continue;
            uint32_t metaError=0;
            if(!readContents(game,metaError)) {++unreadable;continue;}
            if(!game.sd&&!game.nand) continue;
            game.name=titleId(game.id);
            NsApplicationControlData *control=new NsApplicationControlData{};
            u64 actual=0;
            rc=nsGetApplicationControlData(NsApplicationControlSource_Storage,game.id,control,sizeof(*control),&actual);
            if(R_SUCCEEDED(rc)&&actual>=0x4000&&sizeof(control->nacp)>=0x4000) {
                TitleMetadata metadata;std::string metadataError;
                // Read the NACP wire format directly. On FW21+ its language
                // table can be raw-DEFLATE; compressed bytes are never text.
                parseTitleMetadata(&control->nacp,0x4000,metadata,metadataError,preferredLanguage);
                if(metadata.versionValid)game.version=metadata.version;
                std::string name,author;
                if(selectDisplayTitleMetadata(metadata,name,author)){game.name=std::move(name);game.author=std::move(author);}
            }
            delete control;
            games.push_back(std::move(game));
        }
        offset+=count;
    }
    std::string portError;
    discoverPortRemnants(games,portError);
    if(!portError.empty()) error=portError;
    std::string rememberedError;
    addRememberedPaths(games,rememberedError);
    if(!rememberedError.empty()) {if(!error.empty())error+=" ";error+=rememberedError;}
    std::sort(games.begin(),games.end(),[](const Game &a,const Game &b){return a.name==b.name?a.id<b.id:a.name<b.name;});
    if(unreadable) error+=std::to_string(unreadable)+" entradas omitidas: no se pudieron verificar sus contenidos.";
    return true;
}
Plan preparePlan(const Game &game) {
    Plan plan;plan.game=game;
    if(!nsReady||!applicationMode||!identityKnown||(!game.externalOnly&&(!isUserTitle(game.id)||(game.id&0xFFF)!=0))||(game.id&&game.id==currentApplication)||hosversionBefore(6,0,0)) {
        plan.error=InvalidPlan;
        plan.detail=!applicationMode?"Abre hbmenu manteniendo R al iniciar un juego.":(game.id==currentApplication?"Este juego mantiene abierta la aplicacion; usa otro para abrir hbmenu.":"La identidad o los permisos necesarios no se han podido verificar.");
        return plan;
    }
    uint32_t error=0;
    if(game.externalOnly) {
        if(game.portKey.empty()&&game.manualPaths.empty()) {plan.error=InvalidPlan;plan.detail="No hay archivos externos vinculados a esta entrada.";return plan;}
        if(game.id) {
            bool installed=true;Result rc=nsIsAnyApplicationEntityInstalled(game.id,&installed);
            if(R_FAILED(rc)||installed) {plan.error=R_FAILED(rc)?rc:ChangedPlan;plan.detail="La instalacion del menu ha cambiado. Recarga la biblioteca.";return plan;}
        }
        plan.game.contents.clear();plan.game.sd=true;plan.game.nand=false;
    } else {
        if(!readContents(plan.game,error)||(!plan.game.sd&&!plan.game.nand)) {plan.error=error?error:InvalidPlan;plan.detail="No se pudo verificar que el juego siga instalado.";return plan;}
        if(!game.metadataOk||!sameContents(game,plan.game)) {plan.error=ChangedPlan;plan.detail="Los contenidos han cambiado. Actualiza la biblioteca.";return plan;}
    }
    plan.savesOk=game.id?readSaves(game.id,plan.saves,error):true;
    if(!plan.savesOk) {plan.error=error;plan.detail="No se pudieron verificar todas las partidas. Su borrado queda bloqueado.";}
    error=0;
    plan.extrasOk=readExtras(plan.game,plan.extraPaths,error);
    if(!plan.extrasOk) {if(!plan.error)plan.error=error;plan.detail+=" No se pudieron verificar las carpetas extra de Atmosphere.";}
    error=0;std::string portDetail;
    if(!inspectPort(plan.game,plan,error,portDetail)) {
        plan.error=error?error:InvalidPlan;plan.detail=portDetail;return plan;
    }
    if(game.externalOnly&&!plan.portVerified) {plan.error=InvalidPlan;plan.detail="No se pudo verificar el paquete externo. Recarga la biblioteca.";return plan;}
    plan.valid=true;
    return plan;
}
Outcome executePlan(const Plan &plan,bool eraseSaves,bool eraseExtras) {
    Outcome outcome;
    auto fail=[&](uint32_t error,const std::string &message){outcome.error=error;outcome.messages.insert(outcome.messages.begin(),message);};
    if(!plan.valid||(eraseSaves&&!plan.savesOk)||(eraseExtras&&!plan.extrasOk)) {fail(InvalidPlan,"El plan no permite ejecutar las opciones seleccionadas.");return outcome;}
    Plan now=preparePlan(plan.game);
    if(!now.valid||!sameContents(plan.game,now.game)||(eraseSaves&&(!now.savesOk||!sameSaves(plan.saves,now.saves)))||(eraseExtras&&(!now.extrasOk||plan.extraPaths!=now.extraPaths))||((eraseSaves||eraseExtras)&&!samePortPlan(plan,now))) {
        fail(ChangedPlan,"El inventario ha cambiado o no se puede verificar. Revisa el juego de nuevo.");return outcome;
    }
    if(plan.game.externalOnly) {
        bool selected=false;
        for(const auto &entry:plan.portEntries) if(entry.savedata?eraseSaves:eraseExtras) {selected=true;break;}
        if(eraseExtras&&!plan.extraPaths.empty())selected=true;
        if(eraseSaves&&!plan.saves.empty())selected=true;
        if(!selected) {fail(InvalidPlan,"Las opciones elegidas conservan todos los archivos. No se ha borrado nada.");return outcome;}
    }
    if(plan.portVerified) {
        std::string rememberError;
        if(!rememberPaths(plan,rememberError)) {fail(InvalidPlan,"No se pudieron guardar las rutas para recuperar una limpieza incompleta. "+rememberError);return outcome;}
    }
    Result rc=0;
    if(!plan.game.externalOnly) {
    rc=nsDeleteApplicationCompletely(plan.game.id);
    if(R_FAILED(rc)) {fail(rc,"No se pudo desinstalar el juego: "+resultText(rc)+". Las partidas y los extras no se han borrado.");return outcome;}
    bool entityInstalled=true;
    rc=nsIsAnyApplicationEntityInstalled(plan.game.id,&entityInstalled);
    if(R_FAILED(rc)) {fail(rc,"El servicio acepto la desinstalacion, pero no se pudo verificar. Se ha detenido la limpieza.");return outcome;}
    if(entityInstalled) {
        // A cartridge can remain present. Check storage only in that case;
        // querying a completely removed application's metadata may be not-found.
        Game remaining;remaining.id=plan.game.id;uint32_t verifyError=0;
        if(!readContents(remaining,verifyError)) {fail(verifyError,"No se pudo verificar el contenido restante. Se ha detenido la limpieza.");return outcome;}
        if(remaining.sd||remaining.nand) {fail(ChangedPlan,"Quedan contenidos instalados. Se ha detenido la limpieza de partidas y extras.");return outcome;}
    }
    }
    outcome.gameRemoved=true;
    outcome.messages.push_back(plan.game.externalOnly?"Entrada de archivos SD: no quedaba una instalacion del menu que desinstalar.":"Juego, actualizaciones y DLC locales desinstalados del entorno activo.");

    if(eraseSaves && plan.game.id) {
        std::vector<Save> currentSaves;uint32_t saveError=0;
        if(!readSaves(plan.game.id,currentSaves,saveError)||!sameSaves(plan.saves,currentSaves)) {
            fail(saveError?saveError:ChangedPlan,"El inventario de partidas cambio. No se han borrado partidas.");
        } else {
            for(const auto &save:plan.saves) {
                // No save-data API is called on the preserve-saves path.
                if(save.applicationId!=plan.game.id||!isAllowedSaveType(save.type)||!isAllowedSaveSpace(save.space)) {fail(InvalidPlan,"Partida rechazada por la verificacion de seguridad.");break;}
                rc=nsDeleteSaveData(static_cast<FsSaveDataSpaceId>(save.space),save.id);
                if(R_FAILED(rc)) {fail(rc,"No se pudo borrar una partida: "+resultText(rc));continue;}
                ++outcome.savesRemoved;
            }
            std::vector<Save> after;
            if(!readSaves(plan.game.id,after,saveError)) fail(saveError,"No se pudo verificar el resultado del borrado de partidas.");
            else if(!after.empty()) fail(ChangedPlan,"Aun quedan partidas locales del juego.");
        }
    } else if(!eraseSaves) {
        outcome.messages.push_back("Partidas conservadas.");
        if(plan.savesOk && plan.game.id) {
            std::vector<Save> after;uint32_t saveError=0;
            if(!readSaves(plan.game.id,after,saveError)) fail(saveError,"No se pudo verificar el inventario de partidas conservadas.");
            else if(!sameSaves(plan.saves,after)) fail(ChangedPlan,"El inventario de partidas ha cambiado; revisalo desde Ajustes de la consola.");
        }
    }
    if(eraseExtras) {
        std::vector<std::string> extras;uint32_t extraError=0;
        if(!readExtras(plan.game,extras,extraError)||extras!=plan.extraPaths) fail(extraError?extraError:ChangedPlan,"Las carpetas extra han cambiado. Se ha detenido su limpieza.");
        else for(const auto &path:plan.extraPaths) {
            if(removeExtraTree(path,extraError)) ++outcome.extrasRemoved;
            else {fail(extraError,"No se pudo eliminar una carpeta extra de Atmosphere.");break;}
        }
    }
    if(plan.portVerified && (eraseExtras||eraseSaves)) removePortData(plan,eraseExtras,eraseSaves,outcome);
    if(plan.portVerified) pruneRememberedPaths(plan);
    outcome.complete=outcome.gameRemoved&&outcome.error==0;
    outcome.messages.push_back("Solo se han tratado el contenido registrado y las rutas revisadas en la confirmacion.");
    return outcome;
}
}
