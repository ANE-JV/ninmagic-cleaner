#include "ui.hpp"
#include "app_update_ui.hpp"
#include "ui_text.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include <sstream>

namespace nm {
namespace {
constexpr int W=1280, H=720;
using Color=uint32_t;
constexpr Color rgb(unsigned r,unsigned g,unsigned b) { return r|(g<<8)|(b<<16)|0xff000000u; }
constexpr Color ink=rgb(227,239,254), muted=rgb(143,164,192), dim=rgb(85,113,146);
constexpr Color cyan=rgb(71,227,240), violet=rgb(176,131,255), pink=rgb(255,116,158);
constexpr Color green=rgb(177,255,87), orange=rgb(255,174,72), blue=rgb(77,151,255);
constexpr Color panel=rgb(12,24,44), raised=rgb(18,36,61), border=rgb(32,57,82);
struct Glyph {int w=0,h=0,advance=0;std::vector<uint8_t> alpha;};
struct Font {std::array<Glyph,224> glyphs;};
std::map<int,Font> fonts;
std::vector<uint8_t> rawFont, logo;
std::array<uint8_t,224> advances{};
std::vector<Color> background;
Color *fb=nullptr;
int pitch=W;

void pixel(int x,int y,Color c) {if(x>=0&&x<W&&y>=0&&y<H) fb[y*pitch+x]=c;}
void rect(int x,int y,int w,int h,Color c) {
    int x0=std::max(0,x),x1=std::min(W,x+w),y0=std::max(0,y),y1=std::min(H,y+h);
    if(x1<=x0||y1<=y0) return;
    for(int yy=y0;yy<y1;++yy) std::fill(fb+yy*pitch+x0,fb+yy*pitch+x1,c);
}
Color blend(Color dst,Color src,unsigned a) {
    unsigned r=(((dst&255)*(255-a)+(src&255)*a)+127)/255;
    unsigned g=((((dst>>8)&255)*(255-a)+((src>>8)&255)*a)+127)/255;
    unsigned b=((((dst>>16)&255)*(255-a)+((src>>16)&255)*a)+127)/255;
    return rgb(r,g,b);
}
void alphaPixel(int x,int y,Color c,unsigned a) {
    if(x>=0&&x<W&&y>=0&&y<H&&a) {
        Color &p=fb[y*pitch+x];p=a==255?c:blend(p,c,a);
    }
}
void line(int x0,int y0,int x1,int y1,Color c) {
    int dx=std::abs(x1-x0),sx=x0<x1?1:-1,dy=-std::abs(y1-y0),sy=y0<y1?1:-1,err=dx+dy;
    for(;;){pixel(x0,y0,c);if(x0==x1&&y0==y1)break;int e2=2*err;if(e2>=dy){err+=dy;x0+=sx;}if(e2<=dx){err+=dx;y0+=sy;}}
}
void box(int x,int y,int w,int h,Color fill=panel,Color edge=border) {
    rect(x,y,w,h,fill);rect(x,y,w,1,edge);rect(x,y+h-1,w,1,edge);
    rect(x,y,1,h,edge);rect(x+w-1,y,1,h,edge);
    // Cut corners and short highlights give the panels their circuit-board shape.
    line(x,y+7,x+7,y,edge);line(x+w-8,y+h-1,x+w-1,y+h-8,edge);
    rect(x+1,y+1,6,2,fill);rect(x+1,y+3,4,2,fill);rect(x+1,y+5,2,2,fill);
}
std::vector<uint32_t> decode(const std::string&s) { return ui_text::displayCodepoints(s); }
std::string encode(const std::vector<uint32_t>&v) {
    std::string s;for(auto cp:v) {if(cp<128)s+=static_cast<char>(cp);else{s+=static_cast<char>(0xc0|(cp>>6));s+=static_cast<char>(0x80|(cp&63));}}return s;
}
Font& font(int size) {
    auto it=fonts.find(size);if(it!=fonts.end())return it->second;
    Font scaled;
    for(unsigned i=0;i<224;++i) {
        auto &g=scaled.glyphs[i];g.w=size;g.h=(34*size+12)/24;g.advance=(advances[i]*size+12)/24;
        g.alpha.resize(g.w*g.h);
        for(int y=0;y<g.h;++y)for(int x=0;x<g.w;++x)
            g.alpha[y*g.w+x]=rawFont.empty()?0:rawFont[i*24*34+(y*34/g.h)*24+x*24/g.w];
    }
    return fonts.emplace(size,std::move(scaled)).first->second;
}
int width(const std::string&s,int size) {
    auto &f=font(size);int w=0;for(auto cp:decode(s))w+=f.glyphs[cp-32].advance;return w;
}
void text(const std::string&s,int x,int y,int size=18,Color c=ink) {
    auto &f=font(size);int offset=(5*size+12)/24;
    for(auto cp:decode(s)) {
        const auto &g=f.glyphs[cp-32];
        for(int yy=0;yy<g.h;++yy) {
            int py=y+yy-offset;if(py<0||py>=H)continue;
            for(int xx=0;xx<g.w;++xx)if(g.alpha[yy*g.w+xx])alphaPixel(x+xx,py,c,g.alpha[yy*g.w+xx]);
        }
        x+=g.advance;
    }
}
std::string fit(const std::string&s,int maxw,int size) {
    if(width(s,size)<=maxw)return s;
    auto chars=decode(s);while(!chars.empty()&&width(encode(chars)+"...",size)>maxw)chars.pop_back();
    return encode(chars)+"...";
}
void fitted(const std::string&s,int x,int y,int maxw,int size=18,Color c=ink) {text(fit(s,maxw,size),x,y,size,c);}
void wrapped(const std::string&s,int x,int y,int maxw,int size,int maxlines,Color c=ink) {
    std::istringstream words(s);std::string word,current;int n=0;
    while(words>>word) {
        std::string trial=current.empty()?word:current+" "+word;
        if(width(trial,size)>maxw&&!current.empty()) {
            fitted(current,x,y+n*(size+9),maxw,size,c);if(++n>=maxlines)return;current=word;
        } else current=trial;
        if(n==maxlines-1) {
            std::string rest;std::getline(words,rest);fitted(current+rest,x,y+n*(size+9),maxw,size,c);return;
        }
    }
    if(!current.empty())fitted(current,x,y+n*(size+9),maxw,size,c);
}
// File paths must remain exact: wrap at character boundaries, never abbreviate.
std::vector<std::string> pathLines(const std::string&s,int maxw,int size) {
    std::vector<std::string> lines;std::vector<uint32_t> current;
    for(auto cp:decode(s)) {
        auto trial=current;trial.push_back(cp);
        if(!current.empty()&&width(encode(trial),size)>maxw){lines.push_back(encode(current));current.clear();}
        current.push_back(cp);
    }
    if(!current.empty())lines.push_back(encode(current));
    return lines;
}
void exactPath(const std::string&s,int x,int y,int maxw,int size,int maxlines,Color c=muted) {
    const auto lines=pathLines(s,maxw,size);
    for(int i=0;i<std::min(maxlines,static_cast<int>(lines.size()));++i)text(lines[i],x,y+i*(size+7),size,c);
    if(static_cast<int>(lines.size())>maxlines)text("Continúa en el resumen de rutas.",x,y+maxlines*(size+7),12,dim);
}
std::string bytes(uint64_t n) {
    char s[40];double g=static_cast<double>(n)/(1024.0*1024.0*1024.0);
    if(n>=1024ull*1024*1024)std::snprintf(s,sizeof(s),"%.1f GiB",g);
    else if(n>=1024ull*1024)std::snprintf(s,sizeof(s),"%.1f MiB",g*1024);
    else if(n>=1024)std::snprintf(s,sizeof(s),"%.0f KiB",g*1024*1024);
    else std::snprintf(s,sizeof(s),"%llu B",static_cast<unsigned long long>(n));
    return s;
}
std::string number(unsigned n) {return std::to_string(n);}
std::string location(const Game&g) {
    if(g.externalOnly)return "Archivos SD / instalación NSP ausente";
    if(g.sd&&g.nand)return "microSD + memoria interna";
    if(g.sd)return "microSD";
    if(g.nand)return "Memoria interna";
    if(g.card)return "Cartucho";
    return "Ubicación sin verificar";
}
bool localBase(const Game&g) {
    // These are NcmStorageId_BuiltInUser (4) and NcmStorageId_SdCard (5).
    // Keep this renderer independent of libnx for the host preview.
    return std::any_of(g.contents.begin(),g.contents.end(),[](const Content&c){return c.type==0x80&&(c.storage==4||c.storage==5);});
}
std::string errorHex(uint32_t value) {char s[16];std::snprintf(s,sizeof(s),"0x%08X",value);return s;}
uint64_t saveSize(const Plan&p){uint64_t n=0;for(const auto&s:p.saves)n+=s.size;return n;}
bool hasExternal(const Plan&p){return p.game.externalOnly||!p.game.portKey.empty()||!p.portPaths.empty()||!p.game.manualPaths.empty();}
void badge(const std::string&s,int x,int y,Color c=cyan,int maxw=300) {
    int w=std::min(maxw,width(s,14)+24);box(x,y,w,27,rgb(14,37,55),rgb(32,75,95));fitted(s,x+12,y+5,w-24,14,c);
}
void logoAt(int x,int y,int size) {
    if(logo.size()!=256*256*4){box(x,y,size,size,raised,cyan);text("NM",x+size/8,y+size/4,size/3,cyan);return;}
    for(int yy=0;yy<size;++yy)for(int xx=0;xx<size;++xx) {
        size_t p=((yy*256/size)*256+xx*256/size)*4;
        alphaPixel(x+xx,y+yy,rgb(logo[p],logo[p+1],logo[p+2]),logo[p+3]);
    }
}
void key(const std::string&k,const std::string&label,int x,int y,Color c=muted) {
    int kw=std::max(23,width(k,13)+14);box(x,y,kw,25,rgb(19,34,55),rgb(46,71,100));text(k,x+(kw-width(k,13))/2,y+5,13,ink);text(label,x+kw+9,y+5,14,c);
}
void footer(const std::vector<std::pair<std::string,std::string>>&items) {
    rect(32,662,1216,1,border);int x=32;
    for(auto &p:items){key(p.first,p.second,x,681);x+=std::max(23,width(p.first,13)+14)+width(p.second,14)+34;}
    text("NINMAGIC / 1.2.0",1090,686,12,dim);
}
void header(const View&v) {
    logoAt(32,14,64);text("NINMAGIC",110,19,27,ink);text("GESTOR DE JUEGOS",112,53,13,cyan);
    rect(337,24,1,37,border);text("CONTROL DE ALMACENAMIENTO",360,28,16,muted);
    badge(v.env.applet?"MODO APPLET":"MODO APLICACIÓN",1024,28,v.env.applet?pink:cyan,224);
    rect(32,90,1216,1,border);
    text("FW",32,106,12,dim);fitted(v.env.firmware,61,104,185,14,muted);
    text("ATMOSPHÈRE",263,106,12,dim);fitted(v.env.atmosphere,356,104,184,14,muted);
    fitted(v.env.nand,571,104,338,14,v.env.atmosphereDetected?cyan:muted);
    std::string free=v.env.sdTotal?bytes(v.env.sdFree)+" libres en microSD":"microSD: espacio sin verificar";
    fitted(free,934,104,314,14,muted);
}
void title(const std::string&large,const std::string&small="") {
    text(large,32,145,27,ink);if(!small.empty())text(small,34,184,15,muted);
}
void smallLabel(const std::string&s,int x,int y,Color c=muted){text(s,x,y,12,c);}
void neonLine(int x,int y,int w){rect(x,y,w,2,cyan);rect(x+w/3,y,w/3,2,violet);rect(x+2*w/3,y,w-2*w/3,2,pink);}
void identity(const Game&g,int x,int y,int w,bool showVersion=false) {
    text(g.externalOnly?"APLICACIÓN SD SELECCIONADA":"JUEGO SELECCIONADO",x,y,13,cyan);
    wrapped(g.name.empty()?"Título sin nombre":g.name,x,y+34,w,28,2);
    fitted(g.author.empty()?(g.externalOnly?"Port o aplicación homebrew":"Editor no disponible"):g.author,x,y+112,showVersion?260:w,16,muted);
    if(showVersion) {
        std::string version=g.version.empty()?"Versión no declarada":"Versión: "+g.version;
        if(!g.externalOnly&&!g.nroVersion.empty()) version="HOME: "+(g.version.empty()?"no declarada":g.version)+" · NRO: "+g.nroVersion;
        fitted(version,x+290,y+111,w-290,16,g.version.empty()?muted:cyan);
    }
    text(g.id?"TITLE ID  "+titleId(g.id):"PORT NRO · SIN TITLE ID",x,y+149,14,dim);
}
void library(const View&v) {
    text("Biblioteca",32,148,28);text(number(static_cast<unsigned>(v.games.size()))+" títulos",202,160,14,muted);
    static const char* filters[]={"TODOS","microSD","MEMORIA INTERNA"};
    std::string filter=filters[std::clamp(v.filter,0,2)];int fw=width(filter,13)+50;box(464-fw,150,fw,28,raised,border);text("X",478-fw,156,13,cyan);text(filter,499-fw,156,13,muted);
    box(32,196,432,425,panel,border);
    if(v.games.empty()) {
        text("Sin títulos para mostrar",57,242,21);wrapped(v.status,57,285,379,17,6,muted);
    } else {
        int sel=std::clamp(v.selected,0,static_cast<int>(v.games.size())-1),first=std::max(0,sel-3);
        if(first+7>static_cast<int>(v.games.size()))first=std::max(0,static_cast<int>(v.games.size())-7);
        for(int i=first;i<std::min(first+7,static_cast<int>(v.games.size()));++i) {
            const auto &g=v.games[i];int y=205+(i-first)*58;bool active=i==sel;
            if(active){rect(41,y,414,54,rgb(19,49,68));rect(41,y,3,54,cyan);rect(43,y,412,1,rgb(42,94,112));}
            char index[16];std::snprintf(index,sizeof(index),"%02d",i+1);text(index,55,y+10,13,active?cyan:dim);
            fitted(g.name.empty()?(g.id?titleId(g.id):"Aplicación NRO"):g.name,88,y+7,350,18,active?ink:muted);
            std::string loc=g.externalOnly?"PORT NRO · ARCHIVOS SD":g.sd&&g.nand?"SD + INTERNA":g.sd?"microSD":g.nand?"INTERNA":g.card?"CARTUCHO":"DESCONOCIDO";
            if(!g.version.empty())loc+=" · "+g.version;
            fitted(loc,89,y+33,350,11,active?cyan:dim);
        }
        if(v.games.size()>7) {
            int track=393,h=std::max(22,track*7/static_cast<int>(v.games.size())),top=first*(track-h)/std::max(1,static_cast<int>(v.games.size())-7);
            rect(458,211,2,track,border);rect(458,211+top,2,h,cyan);
        }
    }
    box(488,150,760,471,panel,border);rect(488,150,96,2,cyan);
    if(!v.games.empty()) {
        const auto&g=v.games[std::clamp(v.selected,0,static_cast<int>(v.games.size())-1)];identity(g,516,174,700,true);
        if(!g.nroPath.empty())fitted("NRO: "+g.nroPath,516,347,704,13,muted);
        else text(g.externalOnly?"Ruta y versión no disponibles":"Aplicación instalada en HOME",516,347,13,dim);
        badge(location(g),516,381,g.card&&!g.sd&&!g.nand?muted:cyan,600);
        rect(516,421,704,1,border);
        if(g.externalOnly) {
            text("ARCHIVOS DE LA APLICACIÓN EN microSD",516,435,12,cyan);
            wrapped("Revisa el NRO, las carpetas de datos y sus partidas. El tamaño se calcula al seleccionar la aplicación.",516,466,704,17,2,muted);
        } else {
            text("CONTENIDO INSTALADO",516,435,12,dim);
            text(localBase(g)?"01":g.card?"--":"00",517,467,27,localBase(g)?ink:dim);
            text(!localBase(g)&&g.card?"BASE EN CARTUCHO":"BASE LOCAL",562,480,12,muted);
            text(number(g.updates),755,467,27,ink);text("ACTUALIZACIONES",794,480,12,muted);
            text(number(g.dlc),1042,467,27,ink);text("DLC",1082,480,12,muted);
        }
        box(516,529,704,61,rgb(16,47,63),rgb(37,115,130));key("A","REVISAR ELIMINACIÓN",537,546,cyan);
        text("En el siguiente paso podrás decidir sobre partidas y vincular más archivos SD.",516,601,12,muted);
    } else {text("Tu biblioteca, bajo control.",516,197,28);wrapped("Recarga para consultar los juegos instalados y su ubicación en la consola.",516,256,655,20,3,muted);logoAt(973,394,173);}
    fitted(v.status,34,635,1210,13,muted);
    footer({{"D-PAD","Mover"},{"A","Elegir"},{"X","Filtro"},{"Y","Recargar"},{"L","Archivos SD"},{"R","Actualizar"},{"-","Ayuda"},{"+","Salir"}});
}
void saveChoice(const View&v) {
    title("¿Qué hacemos con las partidas?","La decisión se aplica a las partidas nativas y a los guardados SD identificados.");
    box(32,224,366,406,panel,border);identity(v.plan.game,56,247,318);rect(56,444,318,1,border);
    std::string native=v.plan.savesOk?"Nativas: "+number(static_cast<unsigned>(v.plan.saves.size()))+" · "+bytes(saveSize(v.plan)):"Nativas: lectura no verificada";
    fitted(native,56,464,318,16,v.plan.savesOk?cyan:pink);
    std::string external=hasExternal(v.plan)?"SD: "+number(v.plan.externalSaveFiles)+" archivos · "+bytes(v.plan.externalSaveBytes):"SD: sin partidas vinculadas";
    if(hasExternal(v.plan)&&!v.plan.portSavePolicyKnown)external="SD: partidas sin identificar";
    fitted(external,56,497,318,15,hasExternal(v.plan)&&!v.plan.portSavePolicyKnown?pink:muted);
    if(hasExternal(v.plan)&&!v.plan.portSavePolicyKnown)
        wrapped("Si no se reconocen sus partidas, se conserva la carpeta completa. Los datos SD separables se muestran en el resumen.",56,538,318,14,4,muted);
    else wrapped("Incluye todos los usuarios nativos y las rutas SD de partidas indicadas en el resumen.",56,538,318,14,4,muted);
    const char*labels[]={"Conservar las partidas","Borrar las partidas identificadas","Cancelar"};
    const char*desc[]={"Mantener progresos nativos y guardados SD.","Eliminar las partidas que se indiquen en el resumen.","Volver a la biblioteca sin eliminar nada."};
    for(int i=0;i<3;++i) {
        int y=224+i*126;bool active=v.choice==i,locked=i==1&&!v.plan.savesOk;
        Color ac=locked?dim:i==1?pink:cyan;
        box(422,y,826,106,active?rgb(19,43,65):panel,active?ac:border);
        if(active)rect(422,y+1,4,104,ac);
        box(447,y+26,36,36,active?rgb(27,62,81):raised,active?ac:border);
        if(active){rect(458,y+37,14,14,ac);}
        bool unknown=i==1&&hasExternal(v.plan)&&!v.plan.portSavePolicyKnown;
        text(unknown?"Borrar partidas y rutas SD completas":labels[i],506,y+18,23,active&&!locked?ink:muted);
        text(locked?"No se pudieron verificar todas las partidas.":unknown?"Los guardados SD no se pueden separar: revisa las rutas.":desc[i],507,y+58,16,locked?pink:muted);
        if(locked)text("BLOQUEADA",1127,y+23,12,pink);
        if(i==0)text("OPCIÓN PREDETERMINADA",1005,y+80,11,cyan);
    }
    if(v.plan.savesOk)text("X vincula otros archivos o carpetas de la SD. Después revisa las rutas exactas.",424,616,14,muted);
    else fitted(v.plan.detail.empty()?v.status:v.plan.detail,424,616,824,14,pink);
    footer({{"ARRIBA / ABAJO","Elegir"},{"A","Continuar"},{"X","Vincular archivos SD"},{"B","Volver"}});
}
bool underPath(const std::string&path,const std::string&root) {
    return path==root||(path.size()>root.size()&&path.compare(0,root.size(),root)==0&&path[root.size()]=='/');
}
uint64_t pathBytes(const Plan&p,const std::string&root,bool savedata) {
    uint64_t n=0;for(const auto&e:p.portEntries)if(!e.directory&&e.savedata==savedata&&underPath(e.path,root))n+=e.size;return n;
}
struct RouteLine {std::string value;Color color=muted;};
void appendRoute(std::vector<RouteLine>&lines,const std::string&action,const std::string&path,uint64_t size,Color c) {
    lines.push_back({action+" · "+bytes(size),c});
    for(const auto&s:pathLines(path,755,14))lines.push_back({s,muted});
}
std::vector<RouteLine> confirmationRoutes(const View&v) {
    std::vector<RouteLine> lines;
    for(const auto&path:v.plan.portPaths) {
        bool allSave=false,containsSave=false;
        for(const auto&save:v.plan.externalSavePaths){allSave|=underPath(path,save);containsSave|=underPath(save,path);}
        bool directory=std::any_of(v.plan.portEntries.begin(),v.plan.portEntries.end(),[&](const Plan::PortEntry&e){return e.path==path&&e.directory;});
        bool erase=allSave?v.eraseSaves:v.eraseExtras;
        std::string action=erase?(allSave?(v.plan.portSavePolicyKnown?"BORRAR PARTIDAS SD":directory?"BORRAR CARPETA COMPLETA":"BORRAR ARCHIVO COMPLETO"):containsSave&&!v.eraseSaves?"LIMPIAR DATOS · CONSERVAR PARTIDAS":"BORRAR DATOS SD"):allSave?"CONSERVAR RUTA COMPLETA":"CONSERVAR DATOS SD";
        appendRoute(lines,action,path,pathBytes(v.plan,path,allSave),erase?allSave?pink:violet:cyan);
    }
    for(const auto&path:v.plan.externalSavePaths) {
        if(std::find(v.plan.portPaths.begin(),v.plan.portPaths.end(),path)!=v.plan.portPaths.end())continue;
        appendRoute(lines,v.eraseSaves?"BORRAR PARTIDAS SD":"CONSERVAR PARTIDAS SD",path,pathBytes(v.plan,path,true),v.eraseSaves?pink:cyan);
    }
    for(const auto&path:v.plan.extraPaths) {
        lines.push_back({v.eraseExtras?"BORRAR MODS VINCULADOS":"CONSERVAR MODS VINCULADOS",v.eraseExtras?violet:cyan});
        for(const auto&s:pathLines(path,755,14))lines.push_back({s,muted});
    }
    if(lines.empty())lines.push_back({"No se han vinculado archivos externos.",muted});
    return lines;
}
void confirmation(const View&v) {
    title("Revisa antes de borrar","Revisa todas las rutas con ARRIBA / ABAJO. La operación no se puede deshacer.");
    box(32,224,366,406,panel,border);identity(v.plan.game,56,247,318);
    badge(location(v.plan.game),56,446,cyan,318);
    text("PARTIDAS",56,493,12,dim);
    text(v.eraseSaves?"BORRAR LAS INDICADAS":"CONSERVAR",56,518,18,v.eraseSaves?pink:cyan);
    if(hasExternal(v.plan)&&!v.plan.portSavePolicyKnown)
        wrapped(v.eraseSaves?"Las rutas marcadas como partidas se borran completas, incluidos los datos que no puedan separarse.":"Las rutas con posibles partidas se conservan completas. Los demás datos SD siguen la opción Y.",56,557,318,14,3,v.eraseSaves?pink:muted);
    else wrapped("Las partidas nativas incluyen todos los usuarios. Las externas se indican por ruta.",56,557,318,14,3,muted);
    box(422,224,826,145,panel,border);text("RESUMEN",447,240,12,cyan);
    std::string content=v.plan.game.externalOnly?"Sin instalación NSP · aplicación SD":std::string(localBase(v.plan.game)?"Base local + ":"Contenido local + ")+number(v.plan.game.updates)+" actualizaciones + "+number(v.plan.game.dlc)+" DLC";
    text("Juego",447,268,16);fitted(content,677,269,544,15,muted);
    std::string saveSD=hasExternal(v.plan)&&!v.plan.portSavePolicyKnown?"SD sin identificar":number(v.plan.externalSaveFiles)+" archivos SD";
    std::string saves=(v.eraseSaves?"BORRAR · ":"CONSERVAR · ")+number(static_cast<unsigned>(v.plan.saves.size()))+" nativas + "+saveSD;
    text("Partidas",447,299,16);fitted(saves,677,300,544,15,v.eraseSaves?pink:cyan);
    std::string extras=(v.eraseExtras?"BORRAR · ":"CONSERVAR · ")+bytes(v.plan.portBytes)+" datos SD + "+number(static_cast<unsigned>(v.plan.extraPaths.size()))+" rutas de mods";
    text("Y  Datos SD y mods",447,330,15);fitted(extras,677,331,544,15,v.eraseExtras?violet:muted);
    uint64_t eraseBytes=(v.eraseExtras?v.plan.portBytes:0)+(v.eraseSaves?v.plan.externalSaveBytes:0);
    box(422,381,826,162,panel,border);text("RUTAS EXACTAS · "+bytes(eraseBytes)+" SD A BORRAR",447,394,12,cyan);
    const auto lines=confirmationRoutes(v);int first=std::clamp(v.browserSelected,0,std::max(0,static_cast<int>(lines.size())-6));
    std::string range=number(static_cast<unsigned>(first+1))+"-"+number(static_cast<unsigned>(std::min(first+6,static_cast<int>(lines.size()))))+" / "+number(static_cast<unsigned>(lines.size()));
    text(range,1219-width(range,12),394,12,dim);
    for(int i=first;i<std::min(first+6,static_cast<int>(lines.size()));++i)text(lines[i].value,447,416+(i-first)*20,14,lines[i].color);
    box(422,555,826,75,rgb(34,23,43),rgb(113,54,83));
    text(v.hold>0?"Mantén pulsados...":"Mantén L + R + X durante 2 segundos",447,565,19,pink);
    text("Suelta los botones para cancelar la confirmación.",448,594,12,muted);
    rect(447,616,775,5,rgb(56,39,60));float fraction=std::clamp(v.hold,0.0f,1.0f);
    if(fraction>0)rect(447,616,static_cast<int>(775*fraction),5,pink);
    footer({{"ARRIBA / ABAJO","Revisar rutas"},{"L + R + X","Mantener para borrar"},{"Y","Datos SD y mods"},{"B","Volver"}});
}
void files(const View&v) {
    title("Vincular archivos de la microSD","Marca solo las rutas de esta aplicación. Revisa la selección antes de eliminar.");
    box(32,224,760,406,panel,border);text("EXPLORADOR SD",56,239,12,cyan);
    fitted(v.browserPath,223,239,544,13,muted);rect(56,266,712,1,border);
    int count=static_cast<int>(v.browserEntries.size()),sel=count?std::clamp(v.browserSelected,0,count-1):0;
    int first=std::max(0,sel-3);if(first+7>count)first=std::max(0,count-7);
    for(int i=first;i<std::min(first+7,count);++i) {
        const auto&e=v.browserEntries[i];int y=275+(i-first)*49;bool active=i==sel;
        bool marked=std::find(v.selectedPaths.begin(),v.selectedPaths.end(),e.path)!=v.selectedPaths.end();
        if(active){rect(41,y,742,45,rgb(19,49,68));rect(41,y,3,45,cyan);}
        box(56,y+11,20,20,raised,e.selectable?marked?cyan:border:dim);if(marked)rect(61,y+16,10,10,cyan);
        fitted(e.name,91,y+3,595,17,e.selectable?active?ink:muted:dim);
        std::string kind=e.directory?"CARPETA":"ARCHIVO · "+bytes(e.bytes);
        if(!e.selectable)kind+=" · NO SE PUEDE VINCULAR";
        text(kind,92,y+28,11,e.selectable?marked?cyan:dim:dim);
        if(e.directory)text("/",742,y+9,18,active?cyan:dim);
    }
    if(!count)text("No hay archivos en esta carpeta.",56,295,18,muted);
    if(count>7){int h=std::max(24,335*7/count),top=first*(335-h)/std::max(1,count-7);rect(785,278,2,335,border);rect(785,278+top,2,h,cyan);}
    box(816,224,432,406,panel,border);text("SELECCIÓN MANUAL",840,241,12,cyan);
    text(number(static_cast<unsigned>(v.selectedPaths.size()))+" rutas marcadas",840,272,24,ink);
    text("RUTA ACTUAL COMPLETA",840,321,12,dim);
    if(count) {
        const auto&e=v.browserEntries[sel];exactPath(e.path,840,348,384,14,5,muted);
        bool marked=std::find(v.selectedPaths.begin(),v.selectedPaths.end(),e.path)!=v.selectedPaths.end();
        badge(!e.selectable?"VINCULACIÓN BLOQUEADA":marked?"RUTA MARCADA":"SIN MARCAR",840,495,!e.selectable?pink:marked?cyan:muted,384);
    } else exactPath(v.browserPath,840,348,384,14,5,muted);
    wrapped("A abre carpetas o marca archivos. X marca una carpeta completa o un archivo.",840,539,384,14,2,muted);
    wrapped(v.selectedPaths.empty()?"Selecciona al menos una ruta para aplicar con Y.":"Y aplica las rutas y recalcula su tamaño. La confirmación mostrará todas las rutas exactas.",840,592,384,12,2,v.selectedPaths.empty()?pink:muted);
    fitted(v.browserError.empty()?"Vincular no elimina nada. La decisión sobre las partidas se solicita después.":v.browserError,34,639,1210,13,v.browserError.empty()?muted:pink);
    footer({{"ARRIBA / ABAJO","Mover"},{"A","Abrir / marcar"},{"X","Marcar ruta"},{"Y","Aplicar"},{"B","Subir / volver"}});
}
void loading(const View&v,bool busy) {
    box(196,193,888,398,panel,border);rect(196,193,170,2,busy?pink:cyan);
    logoAt(232,232,128);text(busy?"Eliminando el juego":"Preparando tu biblioteca",392,248,29);
    wrapped(v.status,393,305,640,19,3,muted);
    text(busy?"No apagues la consola ni retires la microSD.":"Consultando entorno, almacenamiento y títulos instalados.",234,437,17,busy?pink:muted);
    rect(234,495,812,5,border);int pos=static_cast<int>((v.frame*7)%650);rect(234+pos,495,162,5,busy?pink:cyan);
    text(busy?"PROCESO EN CURSO":"LECTURA EN CURSO",234,525,13,cyan);
    footer({});
}
void result(const View&v) {
    bool ok=v.outcome.complete;title(ok?"Operación completada":"Resultado de la operación",ok?"El resumen muestra lo que se ha eliminado.":"Revisa el resumen antes de volver a la biblioteca.");
    box(32,224,366,406,panel,border);identity(v.plan.game,56,247,318);badge(ok?"COMPLETADO":"REQUIERE ATENCIÓN",56,453,ok?cyan:pink,318);
    if(v.outcome.error)text("Código: "+errorHex(v.outcome.error),56,503,17,pink);
    wrapped(ok?"Puedes volver a la biblioteca para revisar el almacenamiento.":"Si hay datos pendientes, revisa los mensajes. No se indica éxito cuando una operación falla.",56,548,318,15,4,muted);
    box(422,224,826,406,panel,border);text("INFORME",447,243,13,cyan);
    std::string heading=v.plan.game.externalOnly?"Archivos externos procesados":v.outcome.gameRemoved?"Juego desinstalado":"Juego: consulta el detalle";
    text(heading,447,279,22,v.outcome.gameRemoved||v.plan.game.externalOnly?ink:pink);
    text("Partidas nativas borradas: "+number(v.outcome.savesRemoved),447,321,17,v.eraseSaves?pink:muted);
    fitted("Datos SD: "+number(v.outcome.portFilesRemoved)+" archivos · Total borrado en SD: "+bytes(v.outcome.portBytesRemoved),447,354,775,17,ink);
    std::string externalSaves=v.plan.portSavePolicyKnown?"Archivos de partidas SD borrados: ":"Archivos SD de posibles partidas borrados: ";
    text(externalSaves+number(v.outcome.externalSavesRemoved),447,385,15,v.eraseSaves?pink:muted);
    text("Rutas de mods borradas: "+number(v.outcome.extrasRemoved),447,414,14,muted);rect(447,444,775,1,border);
    int y=463;int remaining=5;
    for(const auto&m:v.outcome.messages) {
        if(!remaining)break;
        std::istringstream in(m);std::string word,current;
        while(in>>word) {
            std::string test=current.empty()?word:current+" "+word;
            if(width(test,15)>756&&!current.empty()){fitted(current,447,y,756,15,muted);y+=29;--remaining;if(!remaining)break;current=word;}else current=test;
        }
        if(remaining&&!current.empty()){fitted(current,447,y,756,15,muted);y+=29;--remaining;}
    }
    footer({{"A","Volver a la biblioteca"},{"B","Volver"},{"+","Salir"}});
}
void appUpdate(const View&v) {
    const auto&u=v.appUpdate;const auto&r=v.completedUpdate;const auto action=appUpdateAction(u,r,v.appUpdateDetail);const bool canInstall=action==AppUpdateAction::Install;
    const bool canReview=action==AppUpdateAction::ReviewCompletedRecord,blocked=r.state==CompletedUpdateState::Blocked,sdDiff=differentAppOnSd(u),onSd=publishedAppOnSd(u);
    const bool unconfirmed=!v.appUpdateDetail.empty()&&!u.installed,current=currentPublishedApp(u,v.appUpdateDetail);
    const std::string detail=v.appUpdateDetail.empty()?u.detail:v.appUpdateDetail;
    title("Actualizar NinMagic Cleaner","Distingue el programa abierto del NRO que hay en la microSD.");
    box(32,229,367,397,panel,border);neonLine(32,229,367);logoAt(139,251,154);
    smallLabel("PROGRAMA EN EJECUCIÓN",56,430,blue);fitted(u.runningVersion.empty()?"1.2.0":u.runningVersion,56,451,319,31);
    smallLabel("ARCHIVO NRO EN LA SD",56,501,pink);fitted(u.sdVerified?u.sdVersion:"SIN COMPROBAR",56,523,319,24,u.sdVerified?cyan:violet);
    badge(canReview?"REGISTRO ANTIGUO TERMINADO":u.installed||sdDiff?"CIERRA Y VUELVE A ABRIR":blocked||unconfirmed?"REQUIERE REVISIÓN":u.available?"HAY UNA NUEVA VERSIÓN":"NINMAGIC CLEANER",56,580,canReview||u.installed||sdDiff||blocked||unconfirmed?orange:u.available?green:cyan,319);
    box(423,229,825,397,panel,border);rect(423,229,110,2,u.configured&&!unconfirmed?cyan:orange);
    if(canReview){smallLabel("REGISTRO ANTIGUO TERMINADO",449,249,orange);text("Revisa el registro antes de archivarlo",449,286,27);
        wrapped(r.detail.empty()?"Se encontró un registro terminado que puede archivarse tras revisar el archivo actual y las copias conservadas.":r.detail,449,343,770,19,4,muted);
        smallLabel("REVISIÓN PREVIA A CUALQUIER CAMBIO",449,470,blue);wrapped("A muestra las versiones y la huella del NRO. Después podrás confirmar el archivado del registro. Se conservan el ejecutable y las copias anteriores.",449,493,770,15,3,muted);
        box(449,553,772,57,rgb(15,43,55),rgb(35,122,136));key("A","REVISAR REGISTRO TERMINADO",469,569,cyan);
    }else if(blocked){smallLabel("REGISTRO NO ARCHIVABLE",449,249,orange);text("No se puede archivar este registro",449,286,27);
        wrapped(r.detail.empty()?detail:r.detail,449,343,770,19,6,muted);wrapped(sdDiff?"El archivo de la SD difiere del programa abierto. Cierra NinMagic y vuelve a abrirlo desde hbmenu.":"Se conserva el registro para revisar su estado; no se preparará otra instalación desde esta pantalla.",449,514,770,16,3,orange);badge("REVISA EL INFORME",449,580,orange,770);
    }else if(sdDiff||u.installed||onSd){smallLabel(current?"APLICACIÓN ACTUALIZADA":onSd?"PUBLICACIÓN YA PRESENTE EN LA SD":"ARCHIVO DE LA SD DISTINTO AL PROGRAMA ABIERTO",449,249,current?green:orange);text(current?"No hay actualizaciones pendientes":sdDiff||u.installed?"Cierra NinMagic y vuelve a abrirlo":"El archivo publicado ya está en la SD",449,286,27);
        wrapped(sdDiff?"La versión del NRO de la SD y la que sigue ejecutándose son distintas. Sal completamente y abre NinMagic desde hbmenu para cargar el archivo de la SD.":u.installed?"La instalación terminó. Esta sesión sigue usando el programa anterior hasta que cierres NinMagic y lo abras de nuevo.":"El tamaño, la huella SHA-256 y la versión del NRO de la SD coinciden con la publicación consultada. No hace falta descargarlo otra vez.",449,343,770,19,4,muted);
        smallLabel(onSd?"SHA-256 COINCIDENTE CON LA PUBLICACIÓN":"SHA-256 DEL ARCHIVO DE LA SD",449,460,blue);exactPath(u.sdVerified?u.sdSha256:"Sin comprobar",449,483,770,12,1,muted);
        if(!v.appUpdateDetail.empty())wrapped(v.appUpdateDetail,449,521,770,14,2,orange);
        badge(current?"ÚLTIMA VERSIÓN COMPROBADA":sdDiff||u.installed?"ABRE EL ARCHIVO DE LA SD DESDE HBMENU":"SIN DESCARGA PENDIENTE",449,580,current?green:orange,770);
    }else if(unconfirmed){smallLabel("ACTUALIZACIÓN SIN COMPROBAR",449,249,orange);text("No se pudo comprobar la versión",449,286,27);
        wrapped(detail,449,343,770,19,5,muted);
        wrapped("El informe de error no permite saber si hay una versión más reciente. Revisa la conexión o el canal configurado y vuelve a comprobar.",449,502,770,16,3,muted);
        badge("CONSULTA PENDIENTE",449,580,orange,770);
    }else if(!u.configured){smallLabel("CONSULTA PENDIENTE",449,249,blue);text("Comprueba las actualizaciones",449,286,27);
        wrapped("El canal oficial de GitHub viene integrado. Pulsa X para consultar si existe una versión nueva de NinMagic Cleaner.",449,343,770,19,4,muted);
        badge("SIN CONSULTAR",449,580,blue,770);
    }else{smallLabel(u.installed?"ARCHIVO INSTALADO Y COMPROBADO":u.prepared?"DESCARGA VERIFICADA":u.available?"NUEVA VERSIÓN PUBLICADA":"SIN ACTUALIZACIÓN PENDIENTE",449,249,u.installed||u.available?green:blue);
        fitted(u.version.empty()?"Versión no indicada":u.version,449,280,500,31);fitted(u.size?bytes(u.size):"Tamaño no indicado",982,295,239,17,muted);
        smallLabel("ARCHIVO NRO · HTTPS",449,334,blue);exactPath(u.url.empty()?"Dirección no disponible":u.url,449,357,770,13,2,muted);
        smallLabel(u.prepared||u.installed?"SHA-256 COMPROBADO":"SHA-256 PUBLICADO",449,415,violet);exactPath(u.sha256.empty()?"Sin huella disponible":u.sha256,449,437,770,12,1,muted);
        wrapped(detail.empty()?(u.available?"A confirma la descarga e instalación. Se comprobarán el archivo NRO y su huella antes de sustituir la aplicación.":"No hay una versión más reciente disponible en el canal configurado."):detail,449,474,770,16,2,u.installed?green:muted);
        if(canInstall){box(449,553,772,57,rgb(15,43,55),rgb(35,122,136));key("A",u.prepared?"INSTALAR DESCARGA VERIFICADA":"DESCARGAR E INSTALAR",469,569,cyan);}
        else badge(u.installed?"CIERRA NINMAGIC Y ÁBRELO DE NUEVO":"SIN DESCARGAS PENDIENTES",449,576,u.installed?orange:blue,770);
    }
    fitted(canReview?"A abre una revisión de sólo lectura; archivar requiere una segunda confirmación.":sdDiff||u.installed?"Cierra NinMagic y vuelve a abrirlo desde hbmenu. No se preparará otra descarga en esta sesión.":blocked?"El registro y el archivo actual se conservan. X vuelve a comprobar su estado.":unconfirmed?"X vuelve a comprobar la actualización. El estado actual de la publicación sigue sin verificar.":!u.configured?"X consulta el canal oficial de actualizaciones de NinMagic Cleaner.":!u.available?"X vuelve a consultar el canal de versiones configurado.":"La consulta comprueba versiones. La instalación comienza únicamente al confirmarla con A.",34,641,1214,13,canReview||sdDiff||u.installed||blocked||unconfirmed?orange:muted);
    if(canReview)footer({{"A","Revisar registro"},{"X","Comprobar"},{"B","Volver"},{"+","Cerrar"}});
    else if(u.installed||sdDiff)footer({{"+","Cerrar NinMagic"},{"B","Volver"}});
    else if(canInstall)footer({{"A","Descargar e instalar"},{"X","Volver a comprobar"},{"B","Volver"}});
    else footer({{"X","Volver a comprobar"},{"B","Volver"}});
}
void appUpdateRecord(const View&v){
    const auto&r=v.completedUpdate;const bool ready=completedReviewReady(r);title("Revisa el registro terminado","Comprueba estos datos antes de confirmar el archivado del registro.");
    box(32,229,367,397,panel,border);neonLine(32,229,367);smallLabel("NRO ACTUAL EN LA SD",56,249,cyan);fitted(r.currentVersion.empty()?"SIN COMPROBAR":r.currentVersion,56,282,319,31);fitted(r.currentSize?bytes(r.currentSize):"Tamaño sin comprobar",56,330,319,17,muted);
    smallLabel("SHA-256 LEÍDO DEL ARCHIVO",56,383,blue);exactPath(r.currentSha256.empty()?"Sin comprobar":r.currentSha256,56,410,319,12,3,muted);smallLabel("RUTA DEL EJECUTABLE",56,512,pink);exactPath("sdmc:/switch/NinMagicCleaner/NinMagic-Cleaner.nro",56,540,319,13,3,muted);
    box(423,229,825,397,panel,border);rect(423,229,110,2,ready?cyan:orange);smallLabel(ready?"REGISTRO ANTIGUO TERMINADO":r.state==CompletedUpdateState::Blocked?"REGISTRO NO ARCHIVABLE":"NO HAY UN REGISTRO PARA ARCHIVAR",449,249,ready?cyan:orange);
    smallLabel("VERSIÓN ANTERIOR REGISTRADA",449,294,blue);fitted(r.oldVersion.empty()?"Sin datos":r.oldVersion,449,320,350,24);smallLabel("VERSIÓN OBJETIVO REGISTRADA",836,294,violet);fitted(r.newVersion.empty()?"Sin datos":r.newVersion,836,320,380,24);
    fitted("Registro "+(r.token.empty()?std::string("sin identificar"):r.token)+" · "+(r.journalState=="committed"?"instalación terminada":r.journalState=="restored"?"recuperación terminada":"estado sin confirmar"),449,373,770,15,orange);
    wrapped(r.detail.empty()?v.appUpdateDetail:r.detail,449,413,770,17,ready?3:6,muted);
    if(ready){wrapped("Se archivará únicamente el registro terminado. El NRO de la SD y sus copias anteriores se conservan.",449,508,770,15,2,muted);box(449,553,772,57,rgb(15,43,55),rgb(35,122,136));key("A","CONFIRMAR ARCHIVADO DEL REGISTRO",469,569,cyan);footer({{"A","Archivar registro"},{"B","Cancelar"}});}
    else footer({{"X","Volver a comprobar"},{"B","Volver"}});
}
void appUpdateResult(const View&v){
    const bool ok=v.appUpdateResultOk,archived=v.appUpdateArchiveResult,installed=ok&&v.appUpdate.installed;
    title(archived?(ok?"Registro terminado archivado":"No se pudo archivar el registro"):installed?"Cleaner actualizado":"Resultado de la actualización",installed?"Cierra Cleaner y vuelve a abrirlo para utilizar la nueva versión.":"Revisa el informe antes de continuar.");
    box(32,229,367,397,panel,border);neonLine(32,229,367);logoAt(127,258,177);fitted(ok?"COMPLETADO":"REQUIERE ATENCIÓN",56,476,319,22,ok?green:orange);
    fitted(archived?"Registro de actualización":v.appUpdate.version.empty()?"Consulta el informe":v.appUpdate.version,56,522,319,22,muted);badge(installed?"CIERRA Y VUELVE A ABRIR":"INFORME DE ACTUALIZACIÓN",56,581,ok?cyan:orange,319);
    box(423,229,825,397,panel,border);smallLabel("INFORME",449,249,pink);wrapped(v.appUpdateResultMessage.empty()?"No hay un informe disponible.":v.appUpdateResultMessage,449,286,770,19,8,muted);
    if(installed)footer({{"+","Cerrar Cleaner"}});else footer({{"A","Volver"},{"B","Volver"},{"+","Salir"}});
}
void help(const View&v) {
    title("Control, con límites claros","Qué elimina la aplicación y qué requiere tu decisión.");
    box(32,224,366,406,panel,border);logoAt(117,245,196);text("NINMAGIC",215-width("NINMAGIC",27)/2,463,27);text("GESTOR DE JUEGOS",215-width("GESTOR DE JUEGOS",14)/2,504,14,cyan);
    text("FW: "+fit(v.env.firmware,256,15),56,554,15,muted);fitted("Atmosphère: "+v.env.atmosphere,56,581,318,15,muted);
    box(422,224,826,406,panel,border);
    struct Tip{const char*label;const char*body;};
    const Tip tips[]={
        {"01  CONTENIDO INSTALADO","Desinstala la base, las actualizaciones y los DLC asociados al juego seleccionado, de microSD y memoria interna."},
        {"02  PARTIDAS: SIEMPRE CON PREGUNTA","Conservar es la opción inicial. Incluye todos los usuarios y los guardados SD; si no se pueden separar, conserva la carpeta del port."},
        {"03  NRO Y DATOS DE PORTS","Detecta paquetes NRO y ports reconocidos. Vincula otras rutas desde cualquier carpeta SD con L o X; revisa su tamaño y rutas exactas."},
        {"04  DATOS EXTERNOS Y MODS","Y cambia el borrado de datos externos y mods en atmosphere/contents. Las partidas siguen la decisión anterior."},
        {"05  ALCANCE REAL","No borra historial, capturas ni datos compartidos automáticamente. La selección manual solo afecta a las rutas indicadas; no elimina todo rastro."},
        {"06  ACTUALIZAR CLEANER","R en la biblioteca consulta el canal propio de Cleaner. Revisa y confirma la actualización; después cierra la aplicación y vuelve a abrirla."}
    };
    for(int i=0;i<6;++i){int y=240+i*65;text(tips[i].label,447,y,12,i==1?pink:cyan);wrapped(tips[i].body,447,y+23,774,13,2,muted);if(i<5)rect(447,y+63,775,1,border);}
    footer({{"A","Volver"},{"B","Volver"},{"-","Cerrar ayuda"}});
}
uint32_t le32(const uint8_t*p){return p[0]|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
std::vector<uint8_t> readFile(const std::string&path) {
    std::ifstream in(path,std::ios::binary);if(!in)return{};
    in.seekg(0,std::ios::end);auto n=in.tellg();if(n<0||n>4000000)return{};in.seekg(0);std::vector<uint8_t>data(static_cast<size_t>(n));in.read(reinterpret_cast<char*>(data.data()),n);return in?data:std::vector<uint8_t>{};
}
} // namespace

bool uiInit(const std::string&assetRoot) {
    uiExit();auto data=readFile(assetRoot+"/font.bin");logo=readFile(assetRoot+"/logo.rgba");
    if(data.size()!=32+224+224*24*34||le32(data.data())!=0x54464D4E||le32(data.data()+4)!=32||le32(data.data()+8)!=224||le32(data.data()+12)!=24||le32(data.data()+16)!=34)return false;
    std::copy(data.begin()+32,data.begin()+256,advances.begin());rawFont.assign(data.begin()+256,data.end());
    for(int size:{11,12,13,14,15,16,17,18,19,20,21,22,23,24,27,28,29})font(size);
    background.resize(W*H);Color *oldfb=fb;int oldpitch=pitch;fb=background.data();pitch=W;
    for(int y=0;y<H;++y)for(int x=0;x<W;++x){unsigned glow=static_cast<unsigned>(std::max(0,250-(std::abs(x-1110)+std::abs(y-170))/2));pixel(x,y,rgb(5+glow/30,11+glow/17,24+glow/12));}
    // Static circuit traces are rendered once and copied with the background.
    Color trace=rgb(15,35,53),node=rgb(24,62,78);
    for(int i=0;i<5;++i){int x=718+i*108;line(x,0,x,32+i*12,trace);line(x,32+i*12,x+22,54+i*12,trace);line(x+22,54+i*12,1279,54+i*12,trace);rect(x-2,30+i*12,5,5,node);}
    for(int i=0;i<4;++i){int x=757+i*126;line(x,719,x,652-i*9,trace);line(x,652-i*9,x+19,633-i*9,trace);line(x+19,633-i*9,1279,633-i*9,trace);}
    fb=oldfb;pitch=oldpitch;return logo.size()==256*256*4;
}
void uiDraw(uint32_t*pixels,int stride,const View&view) {
    if(!pixels||stride<W)return;
    fb=pixels;pitch=stride;
    if(background.size()==W*H)for(int y=0;y<H;++y)std::memcpy(fb+y*pitch,background.data()+y*W,W*sizeof(Color));
    else rect(0,0,W,H,rgb(5,11,24));
    header(view);
    switch(view.screen){
        case Screen::Loading:loading(view,false);break;
        case Screen::Library:library(view);break;
        case Screen::SaveChoice:saveChoice(view);break;
        case Screen::Confirm:confirmation(view);break;
        case Screen::Busy:loading(view,true);break;
        case Screen::Result:result(view);break;
        case Screen::Help:help(view);break;
        case Screen::Files:files(view);break;
        case Screen::AppUpdate:appUpdate(view);break;
        case Screen::AppUpdateRecord:appUpdateRecord(view);break;
        case Screen::AppUpdateResult:appUpdateResult(view);break;
    }
}
void uiExit(){fonts.clear();rawFont.clear();logo.clear();background.clear();fb=nullptr;pitch=W;}
} // namespace nm
