#include <switch.h>
#include <atomic>
#include <cstdio>
#include <algorithm>
#include "backend.hpp"
#include "ui.hpp"
#include "confirmation.hpp"
#include "sd_browser.hpp"
#include "app_update_ui.hpp"
#include "update_network.hpp"

namespace {
enum class JobKind { Init, Scan, Plan, Delete, Browse, CheckAppUpdate, PrepareAppUpdate, InstallAppUpdate, ReviewAppUpdateRecord, ArchiveAppUpdateRecord };
struct Job {
    JobKind kind=JobKind::Init;
    nm::Environment env;
    std::vector<nm::Game> games;
    nm::Game game;
    nm::Plan plan;
    nm::Outcome outcome;
    std::string error;
    std::string browserPath;
    std::vector<nm::BrowserEntry> browserEntries;
    nm::AppUpdateInfo appUpdate;
    nm::CompletedUpdateInfo completedUpdate;
    std::string appUpdateDetail,recoveryError,appUpdateResultMessage;
    bool eraseSaves=false,eraseExtras=false,ok=false;
    std::atomic<bool> done{false};
    Thread thread{};
    bool active=false;
} job;
constexpr const char *AppPath="sdmc:/switch/NinMagicCleaner/NinMagic-Cleaner.nro";
bool updateJob(JobKind kind){return kind==JobKind::CheckAppUpdate||kind==JobKind::PrepareAppUpdate||kind==JobKind::InstallAppUpdate||kind==JobKind::ReviewAppUpdateRecord||kind==JobKind::ArchiveAppUpdateRecord;}
void reviewUpdateRecord(){
    std::string error;nm::canArchiveCompletedUpdate(AppPath,job.completedUpdate,error);
    if(!job.completedUpdate.currentVersion.empty()&&!job.completedUpdate.currentSha256.empty()){
        job.appUpdate.sdVerified=true;job.appUpdate.sdVersion=job.completedUpdate.currentVersion;job.appUpdate.sdSha256=job.completedUpdate.currentSha256;job.appUpdate.sdSize=job.completedUpdate.currentSize;
    }else {job.appUpdate.sdVerified=false;job.appUpdate.sdVersion.clear();job.appUpdate.sdSha256.clear();job.appUpdate.sdSize=0;}
    if(job.completedUpdate.state==nm::CompletedUpdateState::Blocked&&job.appUpdateDetail.empty())job.appUpdateDetail=error.empty()?job.completedUpdate.detail:error;
}
bool checkUpdate(){
    std::string error;const bool ok=nm::checkAppUpdate(job.appUpdate,error);job.appUpdateDetail=ok?std::string{}:error;
    reviewUpdateRecord();if(!job.recoveryError.empty()&&job.appUpdateDetail.empty())job.appUpdateDetail=job.recoveryError;
    return ok;
}

void work(void *) {
    switch(job.kind) {
    case JobKind::Init:
        job.ok=nm::backendInit(job.env);
        if(job.ok) job.ok=nm::loadGames(job.games,job.error);
        else job.error="No se pudo abrir el servicio de juegos. Reinicia con Atmosphère.";
        checkUpdate();
        break;
    case JobKind::Scan:
        job.ok=nm::loadGames(job.games,job.error);
        nm::refreshStorage(job.env);
        break;
    case JobKind::Plan: job.plan=nm::preparePlan(job.game);job.ok=job.plan.valid;break;
    case JobKind::Delete:
        job.outcome=nm::executePlan(job.plan,job.eraseSaves,job.eraseExtras);
        nm::refreshStorage(job.env);
        job.ok=job.outcome.complete;
        break;
    case JobKind::Browse:
        job.ok=nm::browseSd(job.browserPath,job.browserEntries,job.error);
        break;
    case JobKind::CheckAppUpdate:job.ok=checkUpdate();break;
    case JobKind::PrepareAppUpdate:
        job.ok=nm::prepareAppUpdate(job.appUpdate,AppPath,job.error);
        if(!job.ok)job.appUpdateDetail=job.error;
        break;
    case JobKind::InstallAppUpdate:
        job.ok=nm::installPreparedAppUpdate(job.appUpdate,AppPath,job.error);
        if(!job.ok)job.appUpdateDetail=job.error;
        reviewUpdateRecord();job.appUpdateResultMessage=job.ok?"Cleaner actualizado y verificado. Cierra la aplicación y vuelve a abrirla. Se conserva una copia de la versión anterior.":job.error;
        break;
    case JobKind::ReviewAppUpdateRecord:
        reviewUpdateRecord();job.ok=nm::completedReviewReady(job.completedUpdate);break;
    case JobKind::ArchiveAppUpdateRecord:
        job.ok=nm::archiveCompletedUpdate(AppPath,job.completedUpdate,job.error);
        if(job.ok){job.recoveryError.clear();nm::recoverAppUpdate(AppPath,job.recoveryError);checkUpdate();job.appUpdateResultMessage="Registro terminado archivado. Se conservan Cleaner y sus copias anteriores.";if(!job.appUpdateDetail.empty())job.appUpdateResultMessage+=" "+job.appUpdateDetail;}
        else {job.appUpdateResultMessage=job.error;job.appUpdateDetail=job.error;reviewUpdateRecord();}
        break;
    }
    job.done.store(true,std::memory_order_release);
}
bool startJob(JobKind kind,nm::View &view) {
    job.kind=kind;job.done.store(false);job.ok=false;job.error.clear();
    job.appUpdate=view.appUpdate;job.completedUpdate=view.completedUpdate;job.appUpdateDetail=view.appUpdateDetail;job.appUpdateResultMessage.clear();
    Result rc=threadCreate(&job.thread,work,nullptr,nullptr,512*1024,0x2C,-2);
    if(R_SUCCEEDED(rc)) {
        rc=threadStart(&job.thread);
        if(R_FAILED(rc)) threadClose(&job.thread);
    }
    if(R_FAILED(rc)) {
        if(updateJob(kind)){view.appUpdateResultOk=false;view.appUpdateResultMessage="No se pudo iniciar la actualización. Se conserva el NRO actual.";view.screen=nm::Screen::AppUpdateResult;return false;}
        view.outcome={};view.outcome.error=rc;
        view.outcome.messages.push_back("No se pudo iniciar la operación. No se ha borrado nada.");
        view.screen=nm::Screen::Result;
        return false;
    }
    job.active=true;if(updateJob(kind))appletSetAutoSleepDisabled(true);return true;
}
void applyFilter(nm::View &view,const std::vector<nm::Game> &all) {
    view.games.clear();
    for(const auto &g:all)
        if(view.filter==0 || (view.filter==1 && g.sd) || (view.filter==2 && g.nand)) view.games.push_back(g);
    view.selected=std::clamp(view.selected,0,std::max(0,int(view.games.size())-1));
}
}

int main(int,char**) {
    nm::recoverAppUpdate(AppPath,job.recoveryError);
    Result rr=romfsInit();
    bool romMounted=R_SUCCEEDED(rr);
    if(R_FAILED(rr)) {consoleInit(nullptr);std::printf("NinMagic Cleaner: error RomFS %08X\nPulsa + para salir.",rr);}
    if(R_FAILED(rr) || !nm::uiInit("romfs:")) {
        if(R_SUCCEEDED(rr)) {consoleInit(nullptr);std::printf("NinMagic Cleaner: faltan recursos. Copia de nuevo el NRO completo.\nPulsa + para salir.");}
        PadState pad;padConfigureInput(1,HidNpadStyleSet_NpadStandard);padInitializeDefault(&pad);
        while(appletMainLoop()) {padUpdate(&pad);if(padGetButtonsDown(&pad)&HidNpadButton_Plus)break;consoleUpdate(nullptr);}
        consoleExit(nullptr);if(R_SUCCEEDED(rr))romfsExit();return 1;
    }
    NWindow *window=nwindowGetDefault();
    Framebuffer fb{};
    Result rc=framebufferCreate(&fb,window,1280,720,PIXEL_FORMAT_RGBA_8888,2);
    if(R_FAILED(rc)) {nm::uiExit();romfsExit();return 1;}
    rc=framebufferMakeLinear(&fb);
    if(R_FAILED(rc)) {framebufferClose(&fb);nm::uiExit();romfsExit();return 1;}
    PadState pad;padConfigureInput(1,HidNpadStyleSet_NpadStandard);padInitializeDefault(&pad);
    nm::View view;
    std::vector<nm::Game> allGames;
    nm::DeleteConfirmation confirmation;
    startJob(JobKind::Init,view);
    bool quit=false;
    uint64_t repeatStart=0,lastRepeat=0,lastDirection=0;
    while(appletMainLoop() && !quit) {
        padUpdate(&pad);
        uint64_t down=padGetButtonsDown(&pad),held=padGetButtons(&pad);
        uint64_t now=armTicksToNs(armGetSystemTick());
        double seconds=double(now)/1e9;
        if(job.active && job.done.load(std::memory_order_acquire)) {
            threadWaitForExit(&job.thread);threadClose(&job.thread);job.active=false;
            appletSetAutoSleepDisabled(false);
            view.appUpdate=job.appUpdate;view.completedUpdate=job.completedUpdate;view.appUpdateDetail=job.appUpdateDetail;
            if(updateJob(job.kind)){
                if(job.kind==JobKind::CheckAppUpdate)view.screen=nm::Screen::AppUpdate;
                else if(job.kind==JobKind::ReviewAppUpdateRecord)view.screen=nm::Screen::AppUpdateRecord;
                else if(job.kind==JobKind::PrepareAppUpdate){
                    if(!job.ok)view.screen=nm::Screen::AppUpdate;
                    else {if(romMounted){romfsExit();romMounted=false;}view.screen=nm::Screen::Busy;view.status="Instalando Cleaner y conservando el NRO anterior...";startJob(JobKind::InstallAppUpdate,view);}
                }else {view.appUpdateResultOk=job.ok;view.appUpdateResultMessage=job.appUpdateResultMessage;view.appUpdateArchiveResult=job.kind==JobKind::ArchiveAppUpdateRecord;view.screen=nm::Screen::AppUpdateResult;}
            }else if(job.kind==JobKind::Init || job.kind==JobKind::Scan) {
                view.env=job.env;
                if(job.ok) {allGames=std::move(job.games);applyFilter(view,allGames);view.screen=nm::Screen::Library;
                    view.status=!job.error.empty()?job.error:(view.games.empty()?"No hay juegos instalados en este filtro.":"Selecciona un juego para preparar su limpieza.");}
                else {view.outcome={};view.outcome.error=view.env.initError;
                    view.outcome.messages.push_back(job.error);view.screen=nm::Screen::Result;}
            } else if(job.kind==JobKind::Plan) {
                view.plan=std::move(job.plan);view.choice=0;view.eraseSaves=false;
                view.eraseExtras=view.plan.extrasOk;
                if(view.plan.valid) view.screen=nm::Screen::SaveChoice;
                else {view.outcome={};view.outcome.error=view.plan.error;view.outcome.messages.push_back(view.plan.detail);
                    view.screen=nm::Screen::Result;}
            } else if(job.kind==JobKind::Browse) {
                view.browserPath=job.browserPath;view.browserEntries=std::move(job.browserEntries);
                view.browserError=job.error;view.browserSelected=0;view.screen=nm::Screen::Files;
            } else {
                view.outcome=std::move(job.outcome);view.env=job.env;
                view.screen=nm::Screen::Result;
            }
            // Require a new input after any asynchronous screen change.
            down=0;confirmation.reset();
        }
        if(!job.active) {
            using nm::Screen;
            uint64_t direction=held&(HidNpadButton_AnyUp|HidNpadButton_AnyDown);
            bool move=(down&(HidNpadButton_AnyUp|HidNpadButton_AnyDown));
            if(direction!=lastDirection) {repeatStart=now;lastRepeat=now;lastDirection=direction;}
            else if(direction && now-repeatStart>380000000 && now-lastRepeat>115000000) {move=true;lastRepeat=now;}
            int delta=(direction&HidNpadButton_AnyDown)?1:-1;
            if(view.screen==Screen::Library) {
                if(move && !view.games.empty()) view.selected=(view.selected+delta+int(view.games.size()))%int(view.games.size());
                if(down&HidNpadButton_X) {view.filter=(view.filter+1)%3;view.selected=0;applyFilter(view,allGames);}
                if(down&HidNpadButton_Y) {view.screen=Screen::Loading;view.status="Actualizando biblioteca...";job.env=view.env;startJob(JobKind::Scan,view);}
                else if(down&HidNpadButton_L) {
                    view.plan={};view.plan.game.name="Otras rutas de la microSD";
                    view.plan.game.externalOnly=true;view.plan.game.sd=true;view.plan.game.portKey="manual";
                    view.selectedPaths.clear();job.browserPath="sdmc:/";
                    view.screen=Screen::Loading;view.status="Abriendo explorador de la microSD...";startJob(JobKind::Browse,view);
                }
                else if(down&HidNpadButton_R){view.screen=Screen::Busy;view.status="Comprobando las actualizaciones de Cleaner...";startJob(JobKind::CheckAppUpdate,view);}
                else if(down&HidNpadButton_Minus) view.screen=Screen::Help;
                else if(down&(HidNpadButton_Plus|HidNpadButton_B)) quit=true;
                else if((down&HidNpadButton_A) && !view.games.empty()) {
                    job.game=view.games[view.selected];view.screen=Screen::Loading;
                    view.status="Revisando contenido, partidas y archivos externos...";startJob(JobKind::Plan,view);
                }
            } else if(view.screen==Screen::AppUpdate){
                if(down&HidNpadButton_Plus)quit=true;
                else if(down&HidNpadButton_B)view.screen=Screen::Library;
                else if(down&HidNpadButton_X){if(view.appUpdate.installed)view.appUpdateDetail="Cierra Cleaner y vuelve a abrirlo para ejecutar la versión nueva.";else {view.screen=Screen::Busy;view.status="Comprobando las actualizaciones de Cleaner...";startJob(JobKind::CheckAppUpdate,view);}}
                else if(down&HidNpadButton_A){
                    const auto action=nm::appUpdateAction(view.appUpdate,view.completedUpdate,view.appUpdateDetail);view.appUpdateArchiveResult=false;
                    if(action==nm::AppUpdateAction::ReviewCompletedRecord){view.screen=Screen::Busy;view.status="Revisando el registro terminado y sus copias...";startJob(JobKind::ReviewAppUpdateRecord,view);}
                    else if(action==nm::AppUpdateAction::Install){view.screen=Screen::Busy;view.status="Descargando y verificando la actualización de Cleaner...";startJob(JobKind::PrepareAppUpdate,view);}
                }
            }else if(view.screen==Screen::AppUpdateRecord){
                if(down&HidNpadButton_B)view.screen=Screen::AppUpdate;
                else if(down&HidNpadButton_X){view.screen=Screen::Busy;view.status="Comprobando el registro y el NRO de Cleaner...";startJob(JobKind::ReviewAppUpdateRecord,view);}
                else if((down&HidNpadButton_A)&&nm::completedReviewReady(view.completedUpdate)){view.screen=Screen::Busy;view.status="Revalidando y archivando el registro terminado...";startJob(JobKind::ArchiveAppUpdateRecord,view);}
            }else if(view.screen==Screen::AppUpdateResult){
                if(down&HidNpadButton_Plus)quit=true;
                else if(down&(HidNpadButton_A|HidNpadButton_B))view.screen=Screen::AppUpdate;
            } else if(view.screen==Screen::SaveChoice) {
                if(move) view.choice=(view.choice+delta+3)%3;
                if(down&HidNpadButton_B) view.screen=Screen::Library;
                else if(down&HidNpadButton_X) {
                    view.selectedPaths=view.plan.game.manualPaths;job.browserPath="sdmc:/";
                    view.screen=Screen::Loading;view.status="Abriendo explorador de la microSD...";startJob(JobKind::Browse,view);
                }
                else if(down&HidNpadButton_A) {
                    auto decision=nm::decideSaves(view.choice,view.plan.savesOk);
                    if(decision==nm::SaveDecision::Cancel) view.screen=Screen::Library;
                    else if(decision==nm::SaveDecision::Unavailable) view.status="No se pudieron leer todas las partidas. Solo puedes conservarlas.";
                    else {view.eraseSaves=decision==nm::SaveDecision::Erase;view.screen=Screen::Confirm;view.browserSelected=0;confirmation.reset();view.hold=0;}
                }
            } else if(view.screen==Screen::Files) {
                if(move&&!view.browserEntries.empty()) view.browserSelected=(view.browserSelected+delta+int(view.browserEntries.size()))%int(view.browserEntries.size());
                if(down&HidNpadButton_Y) {
                    job.game=view.plan.game;job.game.manualPaths=view.selectedPaths;
                    view.screen=Screen::Loading;view.status="Verificando todas las rutas vinculadas...";startJob(JobKind::Plan,view);
                } else if(down&HidNpadButton_B) {
                    if(view.browserPath=="sdmc:/") view.screen=view.plan.valid?Screen::SaveChoice:Screen::Library;
                    else {
                        auto path=view.browserPath;
                        if(path.size()>6&&path.back()=='/')path.pop_back();
                        auto slash=path.find_last_of('/');
                        job.browserPath=slash<=5?"sdmc:/":path.substr(0,slash);
                        view.screen=Screen::Loading;view.status="Leyendo carpeta de la microSD...";startJob(JobKind::Browse,view);
                    }
                } else if(!view.browserEntries.empty()) {
                    const auto &entry=view.browserEntries[view.browserSelected];
                    if((down&HidNpadButton_A)&&entry.directory) {
                        job.browserPath=entry.path;view.screen=Screen::Loading;view.status="Leyendo carpeta de la microSD...";startJob(JobKind::Browse,view);
                    } else if((down&HidNpadButton_X)||((down&HidNpadButton_A)&&!entry.directory)) {
                        std::string why;
                        if(!entry.selectable||!nm::isSafeSdSelection(entry.path,why)) view.browserError=why.empty()?"Esta ruta esta protegida o es un contenedor compartido.":why;
                        else {
                            auto found=std::find(view.selectedPaths.begin(),view.selectedPaths.end(),entry.path);
                            if(found==view.selectedPaths.end()) {
                                if(view.selectedPaths.size()>=128) view.browserError="Maximo 128 rutas por operacion.";
                                else {view.selectedPaths.push_back(entry.path);view.browserError.clear();}
                            } else {view.selectedPaths.erase(found);view.browserError.clear();}
                        }
                    }
                }
            } else if(view.screen==Screen::Confirm) {
                if(move) {view.browserSelected=std::clamp(view.browserSelected+delta,0,4096);confirmation.reset();view.hold=0;}
                if(down&HidNpadButton_B) {view.screen=Screen::SaveChoice;view.choice=0;view.eraseSaves=false;confirmation.reset();}
                else if(down&HidNpadButton_Y) {view.eraseExtras=view.plan.extrasOk && !view.eraseExtras;confirmation.reset();view.hold=0;}
                else {
                    const uint64_t combo=HidNpadButton_L|HidNpadButton_R|HidNpadButton_X;
                    if(confirmation.update((held&combo)==combo,seconds,(held&combo)!=0)) {
                        job.plan=view.plan;job.eraseSaves=view.eraseSaves;job.eraseExtras=view.eraseExtras;
                        job.env=view.env;view.screen=Screen::Busy;view.status="Aplicando la limpieza. Espera a que termine...";
                        // Keep Horizon awake while a destructive request is in flight.
                        appletSetAutoSleepDisabled(true);startJob(JobKind::Delete,view);
                    }
                    view.hold=confirmation.progress();
                }
            } else if(view.screen==Screen::Result) {
                appletSetAutoSleepDisabled(false);
                if(down&HidNpadButton_Plus) quit=true;
                else if(down&(HidNpadButton_A|HidNpadButton_B|HidNpadButton_Y)) {
                    view.screen=Screen::Loading;view.status="Actualizando biblioteca...";job.env=view.env;startJob(JobKind::Scan,view);
                }
            } else if(view.screen==Screen::Help) {
                if(down&(HidNpadButton_B|HidNpadButton_Minus|HidNpadButton_A)) view.screen=Screen::Library;
                if(down&HidNpadButton_Plus) quit=true;
            }
        }
        u32 stride=0;
        auto *pixels=static_cast<uint32_t*>(framebufferBegin(&fb,&stride));
        nm::uiDraw(pixels,int(stride/sizeof(uint32_t)),view);
        framebufferEnd(&fb);++view.frame;
    }
    // Horizon exit requests do not tear down services while a worker uses them.
    if(job.active) {threadWaitForExit(&job.thread);threadClose(&job.thread);}
    appletSetAutoSleepDisabled(false);
    nm::updateNetworkExit();nm::backendExit();nm::uiExit();framebufferClose(&fb);if(romMounted)romfsExit();
    return 0;
}
