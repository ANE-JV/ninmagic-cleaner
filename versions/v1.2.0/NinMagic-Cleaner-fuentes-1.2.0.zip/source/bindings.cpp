#include "bindings.hpp"
#include "sd_browser.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <set>
#include <sys/stat.h>
#include <unistd.h>

namespace nm {
namespace {
constexpr size_t MaxBytes=1024*1024,MaxRecords=512,MaxManualPaths=128,MaxAutoPaths=256,MaxString=0x300;
constexpr uint64_t MinUserTitle=0x0100000000010000ULL;
constexpr char Magic[8]={'N','M','B','I','N','D','0','1'};
const std::string Config="sdmc:/config/NinMagicCleaner";
const std::string Database=Config+"/bindings.bin",Pending=Database+".pending",Backup=Database+".backup";
struct Record {uint64_t id=0;std::string key,name;std::vector<std::string> manual,automatic;};
enum class State {Missing,Present,Unsafe};
#ifdef NM_BINDINGS_TEST
std::string testRoot;
#endif
std::string disk(const std::string &path) {
#ifdef NM_BINDINGS_TEST
    return testRoot+path.substr(5);
#else
    return path;
#endif
}
std::string lower(std::string s){for(char &c:s)if(c>='A'&&c<='Z')c=static_cast<char>(c+32);return s;}
bool samePath(const std::string &a,const std::string &b){return lower(a)==lower(b);}
void appendUnique(std::vector<std::string> &into,const std::vector<std::string> &from){for(const auto &p:from)if(std::none_of(into.begin(),into.end(),[&](const auto &q){return samePath(p,q);}))into.push_back(p);}
bool canonicalRoot(const std::string &path,std::string &error){std::string n;return normalizeSdPath(path,n,error)&&n==path&&isSafeSdSelection(path,error);}
bool validKey(const std::string &key){
    if(key.empty()||key=="manual"||key=="ds2-nx")return true;
    if(key.compare(0,4,"nro:")==0){std::string error;return canonicalRoot(key.substr(4),error);}
    return false;
}
bool plainText(const std::string &s){for(unsigned char c:s)if(c<32||c==127)return false;return true;}
std::string cleanName(std::string name){for(char &c:name)if(static_cast<unsigned char>(c)<32||c==127)c=' ';if(name.size()>MaxString)name.resize(MaxString);return name.empty()?"Archivos SD":name;}

// Every component is checked with lstat, including the SD device root. A missing
// data path is harmless; links, non-directory ancestors and special files never
// become an approved remembered selection.
State dataState(const std::string &path,std::string &error){
    if(!canonicalRoot(path,error))return State::Unsafe;
    size_t end=5;
    for(;;){
        std::string current=end==5?"sdmc:/":path.substr(0,end);struct stat info{};
        if(lstat(disk(current).c_str(),&info)!=0){if(errno==ENOENT)return State::Missing;error="No se puede comprobar una ruta del recibo: "+current;return State::Unsafe;}
        bool last=end==path.size();
        if(S_ISLNK(info.st_mode)||(!S_ISDIR(info.st_mode)&&!(last&&S_ISREG(info.st_mode)))){error="Una ruta del recibo contiene un enlace o un tipo de archivo no permitido: "+current;return State::Unsafe;}
        if(last)break;
        end=path.find('/',end+1);if(end==std::string::npos)end=path.size();
    }
    return State::Present;
}
bool directory(const std::string &path,bool create,bool &present,std::string &error){
    struct stat info{};
    if(lstat(disk(path).c_str(),&info)==0){present=true;if(!S_ISDIR(info.st_mode)||S_ISLNK(info.st_mode)){error="La carpeta de recibos contiene un enlace o no es una carpeta.";return false;}return true;}
    if(errno!=ENOENT){error="No se puede comprobar la carpeta de recibos.";return false;}
    present=false;if(!create)return true;
    if(mkdir(disk(path).c_str(),0700)!=0){error="No se pudo crear la carpeta de recibos.";return false;}
    return directory(path,false,present,error)&&present;
}
bool configParents(bool create,bool &present,std::string &error){
    present=false;bool exists=false;
    if(!directory("sdmc:/",false,exists,error)||!exists){if(error.empty())error="No se puede acceder a la microSD.";return false;}
    if(!directory("sdmc:/config",create,exists,error)||!exists)return error.empty();
    if(!directory(Config,create,exists,error)||!exists)return error.empty();
    present=true;return true;
}
State configFile(const std::string &path,struct stat &info,std::string &error){
    if(lstat(disk(path).c_str(),&info)!=0){if(errno==ENOENT)return State::Missing;error="No se puede comprobar el archivo de recibos.";return State::Unsafe;}
    if(!S_ISREG(info.st_mode)||S_ISLNK(info.st_mode)||info.st_size<0||uint64_t(info.st_size)>MaxBytes){error="El archivo de recibos no es un archivo regular seguro o supera el límite.";return State::Unsafe;}
    return State::Present;
}
uint32_t crc32(const uint8_t *p,size_t size){uint32_t value=0xffffffffu;for(size_t i=0;i<size;++i){value^=p[i];for(unsigned b=0;b<8;++b)value=(value>>1)^(0xedb88320u&uint32_t(0-int(value&1)));}return ~value;}
void put32(std::vector<uint8_t> &b,uint32_t v){for(unsigned i=0;i<4;++i)b.push_back(uint8_t(v>>(8*i)));}
void put64(std::vector<uint8_t> &b,uint64_t v){for(unsigned i=0;i<8;++i)b.push_back(uint8_t(v>>(8*i)));}
void putText(std::vector<uint8_t> &b,const std::string &s){put32(b,uint32_t(s.size()));b.insert(b.end(),s.begin(),s.end());}
struct Reader{
    const std::vector<uint8_t>&bytes;size_t cursor=0;bool ok=true;
    uint32_t u32(){if(cursor>bytes.size()||bytes.size()-cursor<4){ok=false;return 0;}uint32_t v=0;for(unsigned i=0;i<4;++i)v|=uint32_t(bytes[cursor++])<<(i*8);return v;}
    uint64_t u64(){uint64_t a=u32(),b=u32();return a|(b<<32);}
    std::string text(){uint32_t n=u32();if(!ok||n>MaxString||cursor>bytes.size()||n>bytes.size()-cursor){ok=false;return {};}std::string s(reinterpret_cast<const char*>(bytes.data()+cursor),n);cursor+=n;return s;}
};
bool validateRecord(const Record &r,std::string &error){
    if((r.id&&r.id<MinUserTitle)||(!r.id&&r.key.empty())||r.key.size()>MaxString||!validKey(r.key)||r.name.empty()||r.name.size()>MaxString||!plainText(r.name)||r.manual.size()>MaxManualPaths||r.automatic.size()>MaxAutoPaths){error="Un registro de limpieza no es válido o supera el límite de rutas.";return false;}
    for(const auto *list:{&r.manual,&r.automatic})for(const auto &p:*list)if(!canonicalRoot(p,error)){if(error.empty())error="Un recibo contiene una ruta no canónica.";return false;}
    return true;
}
bool decode(const std::vector<uint8_t> &bytes,std::vector<Record> &records,std::string &error){
    if(bytes.size()<20||std::memcmp(bytes.data(),Magic,8)!=0){error="El archivo de recibos tiene una cabecera dañada. Se conserva sin modificar.";return false;}
    Reader read{bytes,8,true};uint32_t version=read.u32(),count=read.u32(),checksum=read.u32();
    if(version!=1||count>MaxRecords||checksum!=crc32(bytes.data()+20,bytes.size()-20)){error="El archivo de recibos está dañado o tiene una versión no compatible. Se conserva sin modificar.";return false;}
    std::vector<Record> result;std::set<std::pair<uint64_t,std::string>> identities;
    for(uint32_t i=0;i<count;++i){
        Record r;r.id=read.u64();r.key=read.text();r.name=read.text();
        for(auto *list:{&r.manual,&r.automatic}){uint32_t n=read.u32();if(n>(list==&r.manual?MaxManualPaths:MaxAutoPaths)){read.ok=false;break;}for(uint32_t j=0;j<n&&read.ok;++j)list->push_back(read.text());}
        if(!read.ok||!validateRecord(r,error)||!identities.emplace(r.id,lower(r.key)).second){if(error.empty())error="El archivo de recibos contiene registros dañados o repetidos.";return false;}
        result.push_back(std::move(r));
    }
    if(!read.ok||read.cursor!=bytes.size()){error="El archivo de recibos está incompleto o contiene datos inesperados.";return false;}
    records.swap(result);return true;
}
bool readFile(const std::string &path,std::vector<Record> &records,std::string &error){
    struct stat before{};if(configFile(path,before,error)!=State::Present)return false;
    int flags=O_RDONLY;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    int fd=open(disk(path).c_str(),flags);if(fd<0){error="No se puede abrir el archivo de recibos.";return false;}
    struct stat opened{};bool ok=fstat(fd,&opened)==0&&S_ISREG(opened.st_mode)&&opened.st_size==before.st_size&&opened.st_dev==before.st_dev&&opened.st_ino==before.st_ino;
    std::vector<uint8_t> bytes(ok?size_t(before.st_size):0);size_t total=0;
    while(ok&&total<bytes.size()){ssize_t n=read(fd,bytes.data()+total,bytes.size()-total);if(n<=0){ok=false;break;}total+=size_t(n);}
    if(close(fd)!=0)ok=false;
    struct stat after{};
    ok=ok&&configFile(path,after,error)==State::Present&&after.st_size==before.st_size&&after.st_mtime==before.st_mtime&&after.st_dev==before.st_dev&&after.st_ino==before.st_ino;
    if(!ok){if(error.empty())error="El archivo de recibos cambió mientras se leía.";return false;}
    return decode(bytes,records,error);
}
bool load(std::vector<Record> &records,std::string &error){
    records.clear();bool parents=false;if(!configParents(false,parents,error))return false;if(!parents)return true;
    // Main is authoritative. Pending/backup are read only when main is absent,
    // allowing recovery after a power loss between the two FAT-safe renames.
    for(const auto &path:{Database,Pending,Backup}){struct stat info{};auto state=configFile(path,info,error);if(state==State::Unsafe)return false;if(state==State::Present)return readFile(path,records,error);}
    return true;
}
bool removeInternalFile(const std::string &path,std::string &error){
    struct stat info{};auto state=configFile(path,info,error);if(state==State::Missing)return true;if(state!=State::Present)return false;
    std::vector<Record> ignored;if(!readFile(path,ignored,error))return false;
    if(unlink(disk(path).c_str())!=0){error="No se pudo retirar un recibo temporal de NinMagic Cleaner.";return false;}return true;
}
bool store(const std::vector<Record> &records,std::string &error){
    if(records.size()>MaxRecords){error="Se alcanzó el límite de recibos de limpieza.";return false;}
    std::vector<uint8_t> payload;
    for(const auto &r:records){if(!validateRecord(r,error))return false;put64(payload,r.id);putText(payload,r.key);putText(payload,r.name);for(const auto *list:{&r.manual,&r.automatic}){put32(payload,uint32_t(list->size()));for(const auto &p:*list)putText(payload,p);}if(payload.size()>MaxBytes-20){error="El archivo de recibos supera el límite de 1 MiB.";return false;}}
    std::vector<uint8_t> bytes(Magic,Magic+8);put32(bytes,1);put32(bytes,uint32_t(records.size()));put32(bytes,crc32(payload.data(),payload.size()));bytes.insert(bytes.end(),payload.begin(),payload.end());
    bool parents=false;if(!configParents(true,parents,error)||!parents)return false;
    struct stat info{};State mainState=configFile(Database,info,error);if(mainState==State::Unsafe)return false;
    if(mainState==State::Missing){
        for(const auto &candidate:{Pending,Backup}){auto state=configFile(candidate,info,error);if(state==State::Unsafe)return false;if(state==State::Present){std::vector<Record> verified;if(!readFile(candidate,verified,error))return false;if(rename(disk(candidate).c_str(),disk(Database).c_str())!=0){error="No se pudo recuperar un recibo de limpieza pendiente.";return false;}mainState=State::Present;break;}}
    }
    if(!removeInternalFile(Pending,error)||!removeInternalFile(Backup,error))return false;
    if(mainState==State::Present){std::vector<Record> verified;if(!readFile(Database,verified,error))return false;}
    int flags=O_WRONLY|O_CREAT|O_EXCL;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    int fd=open(disk(Pending).c_str(),flags,0600);if(fd<0){error="No se pudo crear el recibo de limpieza. No se ha iniciado el borrado.";return false;}
    bool ok=true;size_t total=0;
    while(total<bytes.size()){ssize_t n=write(fd,bytes.data()+total,bytes.size()-total);if(n<=0){ok=false;break;}total+=size_t(n);}
    if(ok&&fsync(fd)!=0)ok=false;
    if(close(fd)!=0)ok=false;
    if(!ok){error="No se pudo guardar el recibo completo. No se ha iniciado el borrado.";return false;}
    std::vector<Record> verified;if(!readFile(Pending,verified,error))return false;
    if(!configParents(false,parents,error)||!parents)return false;
    if(mainState==State::Present&&rename(disk(Database).c_str(),disk(Backup).c_str())!=0){error="No se pudo conservar el recibo anterior. No se ha iniciado el borrado.";return false;}
    if(rename(disk(Pending).c_str(),disk(Database).c_str())!=0){
        struct stat check{};std::string ignored;if(configFile(Database,check,ignored)==State::Missing&&mainState==State::Present)rename(disk(Backup).c_str(),disk(Database).c_str());
        error="No se pudo confirmar el recibo de limpieza. No se ha iniciado el borrado.";return false;
    }
    // A redundant backup may remain after an I/O error; the main receipt is
    // already complete and verified, and a later write can clean that backup.
    std::string ignored;removeInternalFile(Backup,ignored);return true;
}
std::vector<std::string> present(const std::vector<std::string> &paths,unsigned &omitted){std::vector<std::string> result;for(const auto &p:paths){std::string error;auto state=dataState(p,error);if(state==State::Present)appendUnique(result,{p});else if(state==State::Unsafe)++omitted;}return result;}
bool overlaps(const std::vector<std::string> &a,const std::vector<std::string> &b){for(const auto &p:a)for(const auto &q:b)if(samePath(p,q))return true;return false;}
std::string remnantName(const std::string &name){const std::string suffix=" - restos SD";return name.size()>=suffix.size()&&name.compare(name.size()-suffix.size(),suffix.size(),suffix)==0?name:name+suffix;}
} // namespace

#ifdef NM_BINDINGS_TEST
void bindingsSetTestRoot(const std::string &root){testRoot=root;while(!testRoot.empty()&&testRoot.back()=='/')testRoot.pop_back();}
#endif

bool addRememberedPaths(std::vector<Game> &games,std::string &error){
    error.clear();std::vector<Record> records;if(!load(records,error))return false;
    auto result=games;unsigned omitted=0;
    for(const auto &record:records){
        auto manual=present(record.manual,omitted),automatic=present(record.automatic,omitted),all=automatic;appendUnique(all,manual);if(all.empty())continue;
        auto found=result.end();
        if(record.id)found=std::find_if(result.begin(),result.end(),[&](const Game &g){return g.id==record.id;});
        if(found==result.end()&&!record.key.empty())found=std::find_if(result.begin(),result.end(),[&](const Game &g){return lower(g.portKey)==lower(record.key);});
        if(found==result.end())found=std::find_if(result.begin(),result.end(),[&](const Game &g){return g.externalOnly&&g.portKey=="manual"&&g.id==record.id&&overlaps(g.manualPaths,all);});
        if(found!=result.end()){
            if(!found->portKey.empty()&&found->portKey!="manual")appendUnique(found->manualPaths,manual);
            else{appendUnique(found->manualPaths,all);found->portKey="manual";if(found->externalOnly)found->name=remnantName(found->name);}
        }else{
            Game game;game.id=record.id;game.name=remnantName(record.name);game.author="Recibo local de limpieza";game.portKey="manual";game.externalOnly=true;game.sd=game.metadataOk=true;game.manualPaths=std::move(all);result.push_back(std::move(game));
        }
    }
    games.swap(result);if(omitted)error=std::to_string(omitted)+" rutas de recibos omitidas por seguridad.";return true;
}
bool rememberPaths(const Plan &plan,std::string &error){
    error.clear();if(plan.portPaths.empty()&&plan.game.manualPaths.empty())return true;
    if(!plan.valid||!plan.portVerified){error="No se puede guardar un recibo de un plan sin verificar.";return false;}
    Record record;record.id=plan.game.id;record.key=plan.game.portKey;record.name=cleanName(plan.game.name);record.manual=plan.game.manualPaths;record.automatic=plan.portPaths;
    if(!validateRecord(record,error))return false;
    for(const auto *list:{&record.manual,&record.automatic})for(const auto &path:*list)if(dataState(path,error)!=State::Present){if(error.empty())error="Una ruta elegida ha cambiado antes de guardar el recibo.";return false;}
    std::vector<Record> records;if(!load(records,error))return false;
    auto found=std::find_if(records.begin(),records.end(),[&](const Record &r){return r.id==record.id&&lower(r.key)==lower(record.key);});
    if(found==records.end())records.push_back(std::move(record));
    else{appendUnique(found->manual,record.manual);appendUnique(found->automatic,record.automatic);found->name=record.name;}
    return store(records,error);
}
void pruneRememberedPaths(const Plan &plan){
    (void)plan;std::string error;std::vector<Record> records;if(!load(records,error))return;bool changed=false;
    for(auto &record:records)for(auto *list:{&record.manual,&record.automatic}){
        auto end=std::remove_if(list->begin(),list->end(),[&](const std::string &path){std::string why;return dataState(path,why)==State::Missing;});
        if(end!=list->end()){changed=true;list->erase(end,list->end());}
    }
    auto end=std::remove_if(records.begin(),records.end(),[](const Record &r){return r.manual.empty()&&r.automatic.empty();});
    if(end!=records.end()){changed=true;records.erase(end,records.end());}
    if(changed)store(records,error);
}
} // namespace nm
