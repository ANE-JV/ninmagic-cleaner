#include "ports.hpp"
#include "sd_browser.hpp"
#include "title_metadata.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <set>
#include <sys/stat.h>
#include <tuple>
#include <unistd.h>

namespace nm {
namespace {
constexpr uint32_t Unsafe=0xE201,Changed=0xE202,Unverified=0xE203;
constexpr uint64_t Ds2Id=0x03DB1EA9E3264000ULL;
constexpr size_t MaxEntries=200000,MaxPath=0x300;
const std::string Ds2Root="sdmc:/switch/ds2-nx";
const std::string Ds2Launcher="sdmc:/switch/ds2-nx.nro";
const char *Ds2Hash="e8186b72e8749cf7b51f30183e6dd517a771ebcc1b0875ca456f2aee0b9a4566";
const char *Ds2SourceHash="8f0a59f40f80ace0860cf2fdf68ffa51b11939edb395e39be6ce081c619f0ffc";
#ifdef NM_PORTS_TEST
std::string testRoot;
std::string testFailurePath;
#endif
std::string disk(const std::string &p) {
#ifdef NM_PORTS_TEST
    return testRoot+p.substr(5);
#else
    return p;
#endif
}
std::string lower(std::string s){for(char &c:s)if(c>='A'&&c<='Z')c+=32;return s;}
bool within(const std::string &p,const std::string &root){const auto a=lower(p),b=lower(root);return a==b||(a.size()>b.size()&&a.compare(0,b.size(),b)==0&&a[b.size()]=='/');}
bool nroPath(const std::string &p){return p.size()>4&&lower(p.substr(p.size()-4))==".nro";}
std::string parentOf(const std::string &p){return p.substr(0,p.find_last_of('/'));}
std::string filename(const std::string &p){return p.substr(p.find_last_of('/')+1);}
uint32_t ioError(){return 0xE300u+static_cast<uint32_t>(errno?errno:EIO);}

// Portable streaming SHA-256 keeps the host safety tests independent of libnx.
// Only executable identity is hashed; multi-gigabyte assets use tree snapshots.
class Sha256 {
    uint32_t h[8]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    uint8_t block[64]{};size_t used=0;uint64_t bytes=0;
    static uint32_t rotate(uint32_t x,unsigned n){return (x>>n)|(x<<(32-n));}
    void transform(){
        static const uint32_t k[64]={0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
        uint32_t w[64];for(unsigned i=0;i<16;++i)w[i]=(uint32_t(block[i*4])<<24)|(uint32_t(block[i*4+1])<<16)|(uint32_t(block[i*4+2])<<8)|block[i*4+3];
        for(unsigned i=16;i<64;++i){uint32_t a=w[i-15],b=w[i-2];w[i]=w[i-16]+(rotate(a,7)^rotate(a,18)^(a>>3))+w[i-7]+(rotate(b,17)^rotate(b,19)^(b>>10));}
        uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],x=h[7];
        for(unsigned i=0;i<64;++i){uint32_t t=x+(rotate(e,6)^rotate(e,11)^rotate(e,25))+((e&f)^(~e&g))+k[i]+w[i];uint32_t z=(rotate(a,2)^rotate(a,13)^rotate(a,22))+((a&b)^(a&c)^(b&c));x=g;g=f;f=e;e=d+t;d=c;c=b;b=a;a=t+z;}
        h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;h[5]+=f;h[6]+=g;h[7]+=x;
    }
public:
    void update(const void *data,size_t count){const auto *p=static_cast<const uint8_t*>(data);bytes+=count;while(count){size_t n=std::min(count,64-used);std::memcpy(block+used,p,n);used+=n;p+=n;count-=n;if(used==64){transform();used=0;}}}
    std::string finish(){uint64_t bits=bytes*8;uint8_t one=0x80,zero=0;update(&one,1);while(used!=56)update(&zero,1);uint8_t len[8];for(unsigned i=0;i<8;++i)len[7-i]=uint8_t(bits>>(8*i));update(len,8);char out[65];for(unsigned i=0;i<8;++i)std::snprintf(out+i*8,9,"%08lx",static_cast<unsigned long>(h[i]));return out;}
};
bool statPath(const std::string &path,struct stat &st,uint32_t &error,bool missingOk=false){
    if(lstat(disk(path).c_str(),&st)==0){if(S_ISLNK(st.st_mode)||(!S_ISDIR(st.st_mode)&&!S_ISREG(st.st_mode))){error=Unsafe;return false;}return true;}
    if(!missingOk||errno!=ENOENT)error=ioError();
    return false;
}
bool safeParents(const std::string &path,uint32_t &error,const std::string &approvedRoot={}){
    std::string why;if(approvedRoot.empty()?!isSafeSdSelection(path,why):!isSafeSdDescendant(path,approvedRoot,why)){error=Unsafe;return false;}
    for(size_t i=6;i<path.size();++i)if(path[i]=='/'){
        struct stat st{};if(!statPath(path.substr(0,i),st,error)||!S_ISDIR(st.st_mode)){if(!error)error=Unsafe;return false;}
    }
    return true;
}
bool listDir(const std::string &path,std::vector<std::string> &names,uint32_t &error){
    names.clear();DIR *dir=opendir(disk(path).c_str());if(!dir){error=ioError();return false;}
    errno=0;while(auto *e=readdir(dir)){std::string name=e->d_name;if(name!="."&&name!=".."){if(name.empty()||name.find_first_of("/\\:")!=std::string::npos){closedir(dir);error=Unsafe;return false;}names.push_back(std::move(name));}errno=0;}
    int saved=errno;if(closedir(dir)!=0||saved){error=0xE300u+static_cast<uint32_t>(saved?saved:errno);return false;}std::sort(names.begin(),names.end());return true;
}
bool fileHash(const std::string &path,std::string &out,uint32_t &error,const std::string &approvedRoot={}){
    if(!safeParents(path,error,approvedRoot))return false;
    struct stat before{};if(!statPath(path,before,error)||!S_ISREG(before.st_mode))return false;
    FILE *f=std::fopen(disk(path).c_str(),"rb");if(!f){error=ioError();return false;}Sha256 hash;std::array<uint8_t,32768> buffer{};uint64_t total=0;
    while(size_t n=std::fread(buffer.data(),1,buffer.size(),f)){hash.update(buffer.data(),n);total+=n;}
    bool ok=!std::ferror(f);if(std::fclose(f)!=0)ok=false;struct stat after{};
    if(!ok||!statPath(path,after,error)||total!=uint64_t(before.st_size)||before.st_size!=after.st_size||before.st_mtime!=after.st_mtime){if(!error)error=Changed;return false;}out=hash.finish();return true;
}
uint32_t read32(const uint8_t *p){return uint32_t(p[0])|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24);}
uint64_t read64(const uint8_t *p){return uint64_t(read32(p))|(uint64_t(read32(p+4))<<32);}
struct Nro {std::string path,name,author,hash,version;uint64_t owner=0;std::vector<std::string> names;};
bool readNro(const std::string &path,Nro &out,uint32_t &error){
    if(!safeParents(path,error))return false;
    struct stat st{};if(!statPath(path,st,error)||!S_ISREG(st.st_mode)||st.st_size<0x80)return false;
    FILE *f=std::fopen(disk(path).c_str(),"rb");if(!f){error=ioError();return false;}
    uint8_t header[0x80]{};bool ok=std::fread(header,1,sizeof(header),f)==sizeof(header)&&read32(header+0x10)==0x304F524E;
    uint64_t codeSize=read32(header+0x18);uint8_t aset[0x38]{};
    ok=ok&&codeSize>=0x80&&codeSize<=uint64_t(st.st_size);
    if(!ok){std::fclose(f);return false;}
    bool metadata=uint64_t(st.st_size)-codeSize>=sizeof(aset)&&std::fseek(f,long(codeSize),SEEK_SET)==0&&std::fread(aset,1,sizeof(aset),f)==sizeof(aset)&&read32(aset)==0x54455341&&read32(aset+4)==0;
    uint64_t offset=read64(aset+0x18),size=read64(aset+0x20);std::array<uint8_t,0x4000> nacp{};
    if(metadata)metadata=size>=nacp.size()&&offset>=sizeof(aset)&&offset<=uint64_t(st.st_size)-codeSize&&nacp.size()<=uint64_t(st.st_size)-codeSize-offset&&codeSize+offset<=0x7FFFFFFFULL&&std::fseek(f,long(codeSize+offset),SEEK_SET)==0&&std::fread(nacp.data(),1,nacp.size(),f)==nacp.size();
    if(std::fclose(f)!=0)ok=false;
    if(!ok)return false;
    out.path=path;out.owner=metadata?read64(nacp.data()+0x3078):0;
    if(metadata){TitleMetadata title;std::string metadataError;parseTitleMetadata(nacp.data(),nacp.size(),title,metadataError);
        if(title.versionValid)out.version=title.version;
        selectDisplayTitleMetadata(title,out.name,out.author);
        // Association uses every validated original localized name. Display
        // punctuation never changes which installed application owns an NRO.
        for(unsigned i=0;i<title.languageCount;++i){const auto &entry=title.languages[i];if(entry.nameValid&&std::find(out.names.begin(),out.names.end(),entry.name)==out.names.end())out.names.push_back(entry.name);}
    }
    if(out.name.empty())out.name=filename(path).substr(0,filename(path).size()-4);
    return true;
}
bool exists(const std::string &path){struct stat st{};uint32_t error=0;return statPath(path,st,error);}
bool knownDs2(std::string &fingerprint,uint32_t &error){
    struct stat st{};bool launcherFound=false;
    for(const auto &launcher:{Ds2Launcher,Ds2Root+"/ds2-nx.nro"}){
        if(statPath(launcher,st,error,true)){
            std::string hash;if(!fileHash(launcher,hash,error))return false;
            if(hash!=Ds2Hash&&hash!=Ds2SourceHash){error=Unverified;return false;}
            fingerprint+="|"+launcher+":"+hash;launcherFound=true;
        }else if(error)return false;
    }
    if(launcherFound)return true;
    // Source/install profile: two discs plus the matching title-update tree.
    const char *markers[]={"/disc1/default.xex","/disc1/bigfile0.viv","/tu/default.xexp"};
    for(const char *marker:markers){const std::string path=Ds2Root+marker;if(!safeParents(path,error)||!statPath(path,st,error,true)||!S_ISREG(st.st_mode)||st.st_size<=0)return false;}
    fingerprint="ds2-source-layout-v1";return true;
}
bool sharedFolder(const std::string &path){
    std::string name=lower(filename(path));static const std::set<std::string> shared={"retroarch","jksv","checkpoint",".overlays",".config","saves","config","lib","libs","ninmagic-cleaner","ninmagiccleaner","hbmenu"};
    return shared.count(name)!=0;
}
bool genericRoots(const std::string &path,std::vector<std::string> &roots,uint32_t &error){
    Nro info;if(!readNro(path,info,error)){if(!error)error=Unverified;return false;}
    std::string parent=parentOf(path);
    if(parent!="sdmc:/switch"&&!sharedFolder(parent)){
        std::vector<std::string> children;if(!listDir(parent,children,error))return false;unsigned nros=0;for(const auto &child:children)if(nroPath(child))++nros;
        if(nros==1){roots.push_back(parent);return true;}
    }
    roots.push_back(path);
    if(parent=="sdmc:/switch"){
        std::string data=path.substr(0,path.size()-4);struct stat st{};
        if(statPath(data,st,error,true)&&S_ISDIR(st.st_mode)&&!sharedFolder(data))roots.push_back(data);else if(error)return false;
    }
    return true;
}
bool appendTree(const std::string &path,bool unknownSavePolicy,const std::string &saveRoot,const std::string &approvedRoot,Plan &plan,uint32_t &error,unsigned depth=0){
    if(depth>32||plan.portEntries.size()>=MaxEntries||path.size()>MaxPath||!safeParents(path,error,approvedRoot)){if(!error)error=Unsafe;return false;}
    struct stat st{};if(!statPath(path,st,error))return false;
    bool saved=unknownSavePolicy||(!saveRoot.empty()&&within(path,saveRoot));
    if(S_ISDIR(st.st_mode)){std::vector<std::string> children;if(!listDir(path,children,error))return false;for(const auto &child:children)if(!appendTree(path+"/"+child,unknownSavePolicy,saveRoot,approvedRoot,plan,error,depth+1))return false;}
    Plan::PortEntry entry;entry.path=path;entry.directory=S_ISDIR(st.st_mode);entry.size=entry.directory?0:uint64_t(st.st_size);entry.modified=st.st_mtime;entry.savedata=saved;plan.portEntries.push_back(entry);
    if(!entry.directory){if(saved){plan.externalSaveBytes+=entry.size;++plan.externalSaveFiles;}else plan.portBytes+=entry.size;}
    return true;
}
std::vector<std::string> minimalRoots(std::vector<std::string> roots){
    std::sort(roots.begin(),roots.end(),[](const auto &a,const auto &b){return lower(a)<lower(b);});std::vector<std::string> out;
    for(const auto &p:roots){bool covered=false;for(const auto &r:out)if(within(p,r)){covered=true;break;}if(!covered)out.push_back(p);}return out;
}
auto entryKey(const Plan::PortEntry &e){return std::make_tuple(e.path,e.size,e.modified,e.directory,e.savedata);}
std::string coveringRoot(const Plan &plan,const std::string &path){for(const auto &root:plan.portPaths)if(within(path,root))return root;return {};}
}
#ifdef NM_PORTS_TEST
void portsSetTestRoot(const std::string &root){testRoot=root;}
void portsSetFailureForTest(const std::string &path){testFailurePath=path;}
std::string portsHashForTest(const std::string &text){Sha256 h;h.update(text.data(),text.size());return h.finish();}
#endif

bool discoverPortRemnants(std::vector<Game> &games,std::string &error){
    error.clear();uint32_t code=0;std::string dsFingerprint;bool dsVerified=knownDs2(dsFingerprint,code);
    if(dsVerified){
        auto found=std::find_if(games.begin(),games.end(),[](const Game &g){return g.id==Ds2Id&&!g.externalOnly;});
        if(found==games.end()){Game g;g.id=Ds2Id;g.name="Dead Space 2 - archivos del port";g.portKey="ds2-nx";g.externalOnly=true;g.sd=g.metadataOk=true;games.push_back(std::move(g));found=games.end()-1;}
        else found->portKey="ds2-nx";
        for(const auto &launcher:{Ds2Launcher,Ds2Root+"/ds2-nx.nro"}){Nro info;uint32_t metadataError=0;if(readNro(launcher,info,metadataError)){found->nroVersion=info.version;found->nroPath=info.path;if(found->externalOnly){found->version=info.version;found->author=info.author;}break;}}
    }
    struct stat rootStat{};code=0;if(!statPath("sdmc:/switch",rootStat,code,true)){if(code)error="No se pudo leer /switch.";return code==0;}
    std::vector<std::string> top;if(!listDir("sdmc:/switch",top,code)){error="No se pudo enumerar /switch.";return false;}std::vector<std::string> candidates;
    for(const auto &name:top){std::string path="sdmc:/switch/"+name;struct stat st{};code=0;if(!statPath(path,st,code))continue;if(S_ISREG(st.st_mode)&&nroPath(path))candidates.push_back(path);else if(S_ISDIR(st.st_mode)&&!sharedFolder(path)){std::vector<std::string> children;if(!listDir(path,children,code))continue;for(const auto &child:children)if(nroPath(child))candidates.push_back(path+"/"+child);}}
    unsigned omitted=0;
    for(const auto &path:candidates){if(dsVerified&&(path==Ds2Launcher||within(path,Ds2Root)))continue;std::string why;if(!isSafeSdSelection(path,why))continue;Nro info;code=0;if(!readNro(path,info,code)){++omitted;continue;}
        std::vector<size_t> matches;for(size_t i=0;i<games.size();++i){const auto &g=games[i];if(g.externalOnly)continue;if(info.owner>=0x0100000000010000ULL&&info.owner==g.id)matches.push_back(i);}
        if(matches.empty()){for(size_t i=0;i<games.size();++i){const auto &g=games[i];if(!g.externalOnly&&std::find(info.names.begin(),info.names.end(),g.name)!=info.names.end())matches.push_back(i);}}
        if(matches.size()==1&&games[matches.front()].portKey.empty()){auto &g=games[matches.front()];g.portKey="nro:"+path;g.nroVersion=info.version;g.nroPath=info.path;continue;}
        Game g;g.id=0;g.name=info.name+" (NRO)";g.author=info.author;g.version=g.nroVersion=info.version;g.nroPath=info.path;g.portKey="nro:"+path;g.externalOnly=true;g.sd=g.metadataOk=true;games.push_back(std::move(g));
    }
    if(omitted)error=std::to_string(omitted)+" NRO sin metadatos verificables omitidos.";
    return true;
}
bool inspectPort(const Game &game,Plan &plan,uint32_t &error,std::string &detail){
    plan.portPaths.clear();plan.externalSavePaths.clear();plan.portEntries.clear();plan.portFingerprint.clear();plan.portBytes=plan.externalSaveBytes=0;plan.externalSaveFiles=0;plan.portVerified=false;plan.portSavePolicyKnown=false;error=0;
    std::vector<std::string> roots;std::string fingerprint,saveRoot;bool known=false;
    if(game.portKey=="ds2-nx"){
        if(game.id!=Ds2Id||!knownDs2(fingerprint,error)){if(!error)error=Unverified;detail="No se pudo comprobar la identidad de ds2-nx.";return false;}
        known=true;saveRoot=Ds2Root+"/ds2";if(exists(Ds2Root))roots.push_back(Ds2Root);if(exists(Ds2Launcher))roots.push_back(Ds2Launcher);
    }else if(game.portKey.compare(0,4,"nro:")==0){
        std::string launcher=game.portKey.substr(4);if(!within(launcher,"sdmc:/switch")||!nroPath(launcher)||!genericRoots(launcher,roots,error)){if(!error)error=Unverified;detail="No se pudo verificar el NRO y sus rutas.";return false;}Nro info;if(!readNro(launcher,info,error))return false;fingerprint=info.hash;
    }else if(!game.portKey.empty()&&game.portKey!="manual"){error=Unverified;detail="Perfil de port desconocido.";return false;}
    for(const auto &manual:game.manualPaths){std::string normalized,why;if(!normalizeSdPath(manual,normalized,why)||normalized!=manual||!isSafeSdSelection(manual,why)||!safeParents(manual,error)){if(!error)error=Unsafe;detail="Ruta SD rechazada: "+manual;return false;}roots.push_back(manual);}
    if(roots.empty())return true;
    roots=minimalRoots(std::move(roots));plan.portPaths=roots;
    for(const auto &root:roots){bool manual=false;for(const auto &m:game.manualPaths)if(within(root,m)||within(m,root)){manual=true;break;}struct stat st{};if(!statPath(root,st,error)||!safeParents(root,error))return false;bool unknown=manual||(!known&&S_ISDIR(st.st_mode));
        if(unknown)plan.externalSavePaths.push_back(root);else if(known&&within(saveRoot,root)&&exists(saveRoot))plan.externalSavePaths.push_back(saveRoot);
        if(!appendTree(root,unknown,known?saveRoot:std::string(),root,plan,error))return false;
    }
    plan.externalSavePaths=minimalRoots(std::move(plan.externalSavePaths));plan.portSavePolicyKnown=known&&game.manualPaths.empty();
    // Include every executable fingerprint, including nested launchers in a root.
    for(const auto &entry:plan.portEntries)if(!entry.directory&&nroPath(entry.path)){
        if(known&&(entry.path==Ds2Launcher||entry.path==Ds2Root+"/ds2-nx.nro"))continue; // already hashed by knownDs2
        std::string hash;if(!fileHash(entry.path,hash,error,coveringRoot(plan,entry.path)))return false;fingerprint+="|"+entry.path+":"+hash;
    }
    plan.portFingerprint=fingerprint;plan.portVerified=true;
    if(!plan.portSavePolicyKnown&&plan.externalSaveFiles)detail="Carpetas sin politica de partidas: conservar partidas mantiene su contenido completo.";
    return true;
}
bool samePortPlan(const Plan &a,const Plan &b){
    if(a.portVerified!=b.portVerified||a.portSavePolicyKnown!=b.portSavePolicyKnown||a.portFingerprint!=b.portFingerprint||a.portPaths!=b.portPaths||a.externalSavePaths!=b.externalSavePaths||a.portEntries.size()!=b.portEntries.size())return false;
    for(size_t i=0;i<a.portEntries.size();++i)if(entryKey(a.portEntries[i])!=entryKey(b.portEntries[i]))return false;
    return true;
}
bool removePortData(const Plan &plan,bool eraseFiles,bool eraseSaves,Outcome &outcome){
    if(!eraseFiles&&!eraseSaves)return true;
    if(plan.portPaths.empty())return true;
    uint32_t error=0;std::string detail;Plan now;now.game=plan.game;
    if(!inspectPort(plan.game,now,error,detail)||!samePortPlan(plan,now)){outcome.error=error?error:Changed;outcome.messages.push_back("Los archivos externos han cambiado. No se ha iniciado su borrado.");return false;}
    auto selected=[&](const Plan::PortEntry &e){return e.savedata?eraseSaves:eraseFiles;};
    std::vector<const Plan::PortEntry*> files,nros,dirs;
    for(const auto &entry:plan.portEntries)if(selected(entry)){if(entry.directory)dirs.push_back(&entry);else if(nroPath(entry.path))nros.push_back(&entry);else files.push_back(&entry);}
    auto removeFile=[&](const Plan::PortEntry &entry){struct stat st{};if(!safeParents(entry.path,error,coveringRoot(plan,entry.path))||!statPath(entry.path,st,error)||S_ISDIR(st.st_mode)||uint64_t(st.st_size)!=entry.size||int64_t(st.st_mtime)!=entry.modified){if(!error)error=Changed;return false;}
#ifdef NM_PORTS_TEST
        if(entry.path==testFailurePath){error=0xE300u+EACCES;return false;}
#endif
        if(unlink(disk(entry.path).c_str())!=0){error=ioError();return false;}if(entry.savedata)++outcome.externalSavesRemoved;else ++outcome.portFilesRemoved;outcome.portBytesRemoved+=entry.size;return true;};
    // Retain every NRO identity marker until its non-executable data was removed.
    for(auto *entry:files)if(!removeFile(*entry))goto failed;
    for(auto *entry:nros)if(!removeFile(*entry))goto failed;
    for(auto *entry:dirs){struct stat st{};if(!safeParents(entry->path,error,coveringRoot(plan,entry->path))||!statPath(entry->path,st,error)||!S_ISDIR(st.st_mode))goto failed;
        bool retained=false;for(const auto &child:plan.portEntries)if(within(child.path,entry->path)&&!selected(child)){retained=true;break;}
        if(retained)continue;
        if(rmdir(disk(entry->path).c_str())!=0){error=ioError();goto failed;}
    }
    if(!eraseSaves&&!plan.externalSavePaths.empty())outcome.messages.push_back("Partidas externas conservadas; sus carpetas y padres permanecen.");
    return true;
failed:
    outcome.error=error?error:Changed;outcome.messages.push_back("Limpieza externa incompleta. Se conservan los archivos que no se pudieron eliminar.");return false;
}
}
