#include "sd_browser.hpp"
#include <algorithm>
#include <cerrno>
#include <cstring>
#include <initializer_list>
#include <utility>

#if defined(_WIN32) && !defined(__SWITCH__)
#include <filesystem>
#include <system_error>
#else
#include <dirent.h>
#include <sys/stat.h>
#endif

namespace nm {
namespace {
constexpr size_t MaxPathBytes=0x300;
constexpr size_t MaxDirectoryEntries=10000;
constexpr uint64_t MinUserTitle=0x0100000000010000ULL;

std::string lowerAscii(std::string value) {
    for(char &c:value) if(c>='A'&&c<='Z') c=static_cast<char>(c-'A'+'a');
    return value;
}
std::vector<std::string> components(const std::string &path) {
    std::vector<std::string> result;
    size_t start=6;
    while(start<path.size()) {
        size_t end=path.find('/',start);
        if(end==std::string::npos) end=path.size();
        result.push_back(lowerAscii(path.substr(start,end-start)));
        start=end+1;
    }
    return result;
}
bool oneOf(const std::string &name,std::initializer_list<const char*> values) {
    for(const char *value:values) if(name==value) return true;
    return false;
}
bool userTitleDirectory(const std::string &name) {
    if(name.size()!=16) return false;
    uint64_t value=0;
    for(char c:name) {
        unsigned digit;
        if(c>='0'&&c<='9') digit=static_cast<unsigned>(c-'0');
        else if(c>='a'&&c<='f') digit=static_cast<unsigned>(c-'a'+10);
        else return false;
        value=(value<<4)|digit;
    }
    return value>=MinUserTitle;
}
bool protectedBasename(const std::string &name) {
    return oneOf(name,{"prod.keys","title.keys","hbmenu.nro","fusee.bin","package3",
                       "ninmagic-cleaner.nro","ninmagiccleaner.nro"});
}
bool selectionPolicy(const std::string &canonical,std::string &error) {
    auto parts=components(canonical);
    if(parts.empty()) {error="La raíz de la microSD no se puede seleccionar.";return false;}
    for(const auto &part:parts) if(protectedBasename(part)) {
        error="Este archivo de arranque, claves o de NinMagic Cleaner está protegido.";return false;
    }
    const auto &top=parts.front();
    if(oneOf(top,{"nintendo","emummc","bootloader","sept","sxos","backup","$recycle.bin","system volume information"})||top.front()=='.') {
        error="Esta ruta de sistema está protegida. Puedes examinarla, pero no seleccionarla.";return false;
    }
    if(top=="atmosphere") {
        if(parts.size()==3&&parts[1]=="contents"&&userTitleDirectory(parts[2])) return true;
        error="En Atmosphère solo se puede seleccionar la carpeta exacta de un Title ID de usuario.";return false;
    }
    if(parts.size()==1&&oneOf(top,{"switch","games","roms","config","jksv","checkpoint",
                                 "retroarch","emulators","ports","apps","homebrew","save","saves","savegames","mods"})) {
        error="Esta carpeta contiene datos de varias aplicaciones. Abre una subcarpeta o elige un archivo.";return false;
    }
    if(parts.size()==1&&oneOf(top,{"boot.dat","boot.ini","bootlogo.bmp","exosphere.ini",
                                 "stratosphere.ini","hekate_ipl.ini","reboot_payload.bin","payload.bin","keys.txt"})) {
        error="Este archivo de configuración o arranque de la microSD está protegido.";return false;
    }
    if(top=="switch"&&parts.size()>=2&&oneOf(parts[1],{"ninmagiccleaner","ninmagic-cleaner","ninmagic cleaner","ninmagic_cleaner"})) {
        error="La carpeta de NinMagic Cleaner está protegida mientras usas la aplicación.";return false;
    }
    if(top=="config"&&parts.size()>=2&&oneOf(parts[1],{"ninmagiccleaner","ninmagic-cleaner"})) {
        error="Los recibos y la configuración de NinMagic Cleaner están protegidos.";return false;
    }
    if(top=="switch"&&parts.size()==2&&parts[1]==".overlays") {
        error="Abre la carpeta de overlays y elige un archivo concreto.";return false;
    }
    return true;
}

bool checkDirectoryAncestors(const std::string &path,std::string &error) {
    size_t end=5;
    for(;;) {
        std::string current=end==5?"sdmc:/":path.substr(0,end);
#if defined(_WIN32) && !defined(__SWITCH__)
        std::error_code code;
        auto status=std::filesystem::symlink_status(std::filesystem::u8path(current),code);
        if(code||std::filesystem::is_symlink(status)||!std::filesystem::is_directory(status)) {
            error="No se puede abrir la carpeta o contiene un enlace: "+current;return false;
        }
#else
        struct stat info{};
        if(lstat(current.c_str(),&info)!=0||S_ISLNK(info.st_mode)||!S_ISDIR(info.st_mode)) {
            error="No se puede abrir la carpeta o contiene un enlace: "+current;return false;
        }
#endif
        if(path.size()==6||end==path.size()) break;
        end=path.find('/',end+1);
        if(end==std::string::npos) end=path.size();
    }
    return true;
}

void sortEntries(std::vector<BrowserEntry> &entries) {
    std::sort(entries.begin(),entries.end(),[](const BrowserEntry &a,const BrowserEntry &b) {
        if(a.directory!=b.directory) return a.directory>b.directory;
        const auto foldedA=lowerAscii(a.name),foldedB=lowerAscii(b.name);
        return foldedA==foldedB?a.name<b.name:foldedA<foldedB;
    });
}
} // namespace

bool normalizeSdPath(const std::string &path,std::string &normalized,std::string &error) {
    if(&path==&normalized||&path==&error) {
        const std::string input=path;
        return normalizeSdPath(input,normalized,error);
    }
    normalized.clear();error.clear();
    if(path.size()<6||path.compare(0,6,"sdmc:/")!=0||path.size()>=MaxPathBytes) {
        error="La ruta debe empezar por sdmc:/ y respetar el límite de longitud.";return false;
    }
    for(size_t i=0;i<path.size();++i) {
        unsigned char c=static_cast<unsigned char>(path[i]);
        if(c<32||c==127||c=='\\'||(c==':'&&i!=4)||c=='*'||c=='?'||c=='"'||c=='<'||c=='>'||c=='|') {
            error="La ruta contiene caracteres no permitidos.";return false;
        }
    }
    if(path.find("//")!=std::string::npos) {error="La ruta contiene separadores repetidos.";return false;}
    normalized=path;
    if(normalized.size()>6&&normalized.back()=='/') normalized.pop_back();
    size_t start=6;
    while(start<normalized.size()) {
        size_t end=normalized.find('/',start);
        if(end==std::string::npos) end=normalized.size();
        auto part=normalized.substr(start,end-start);
        if(part.empty()||part=="."||part==".."||part.size()>255||part.back()=='.'||part.back()==' ') {
            normalized.clear();error="La ruta contiene un nombre ambiguo o un componente no permitido.";return false;
        }
        start=end+1;
    }
    return true;
}

bool isSafeSdSelection(const std::string &path,std::string &error) {
    std::string canonical;
    if(!normalizeSdPath(path,canonical,error)) return false;
    return selectionPolicy(canonical,error);
}

bool isSafeSdDescendant(const std::string &path,const std::string &approvedRoot,std::string &error) {
    std::string canonical,root;
    if(!normalizeSdPath(path,canonical,error)||!normalizeSdPath(approvedRoot,root,error)||!selectionPolicy(root,error)) return false;
    const auto foldedPath=lowerAscii(canonical),foldedRoot=lowerAscii(root);
    if(foldedPath!=foldedRoot&&foldedPath.compare(0,foldedRoot.size()+1,foldedRoot+"/")!=0) {
        error="El archivo queda fuera de la carpeta seleccionada.";return false;
    }
    for(const auto &part:components(canonical)) if(protectedBasename(part)) {
        error="La carpeta contiene un archivo de arranque, claves o de NinMagic Cleaner protegido.";return false;
    }
    const auto rootParts=components(root);
    if(rootParts.size()==3&&rootParts[0]=="atmosphere"&&rootParts[1]=="contents"&&userTitleDirectory(rootParts[2])) return true;
    return selectionPolicy(canonical,error);
}

bool browseSd(const std::string &path,std::vector<BrowserEntry> &entries,std::string &error) {
    entries.clear();error.clear();
    std::string canonical;
    if(!normalizeSdPath(path,canonical,error)||!checkDirectoryAncestors(canonical,error)) return false;
    const std::string prefix=canonical=="sdmc:/"?canonical:canonical+"/";
    std::vector<BrowserEntry> found;
#if defined(_WIN32) && !defined(__SWITCH__)
    std::error_code code;
    std::filesystem::directory_iterator iterator(std::filesystem::u8path(canonical),code),end;
    if(code) {error="No se puede leer esta carpeta: "+code.message();return false;}
    while(iterator!=end) {
        BrowserEntry entry;
        entry.name=iterator->path().filename().u8string();entry.path=prefix+entry.name;
        auto status=iterator->symlink_status(code);
        if(code) {error="No se pueden comprobar los archivos de esta carpeta.";return false;}
        entry.directory=std::filesystem::is_directory(status);
        bool regular=std::filesystem::is_regular_file(status);
        if(regular) {entry.bytes=iterator->file_size(code);if(code){error="No se puede leer el tamaño del archivo.";return false;}}
        std::string reason;
        entry.selectable=(entry.directory||regular)&&!std::filesystem::is_symlink(status)&&isSafeSdSelection(entry.path,reason);
        found.push_back(std::move(entry));
        if(found.size()>MaxDirectoryEntries) {error="Hay demasiados archivos para mostrar esta carpeta.";return false;}
        iterator.increment(code);
        if(code) {error="La lectura de la carpeta se ha interrumpido.";return false;}
    }
#else
    DIR *directory=opendir(canonical.c_str());
    if(!directory) {error="No se puede leer esta carpeta: "+std::string(std::strerror(errno));return false;}
    for(;;) {
        errno=0;
        dirent *item=readdir(directory);
        if(!item) {
            int readError=errno;closedir(directory);
            if(readError) {error="La lectura de la carpeta se ha interrumpido: "+std::string(std::strerror(readError));return false;}
            break;
        }
        const std::string name=item->d_name;
        if(name=="."||name=="..") continue;
        BrowserEntry entry;entry.name=name;entry.path=prefix+name;
        struct stat info{};
        if(lstat(entry.path.c_str(),&info)!=0) {
            if(errno==ENOENT) continue;
            int statError=errno;closedir(directory);
            error="No se pueden comprobar los archivos de esta carpeta: "+std::string(std::strerror(statError));return false;
        }
        entry.directory=S_ISDIR(info.st_mode);
        bool regular=S_ISREG(info.st_mode);
        entry.bytes=regular&&info.st_size>0?static_cast<uint64_t>(info.st_size):0;
        std::string reason;
        entry.selectable=(entry.directory||regular)&&!S_ISLNK(info.st_mode)&&isSafeSdSelection(entry.path,reason);
        found.push_back(std::move(entry));
        if(found.size()>MaxDirectoryEntries) {closedir(directory);error="Hay demasiados archivos para mostrar esta carpeta.";return false;}
    }
#endif
    sortEntries(found);entries.swap(found);return true;
}
} // namespace nm
