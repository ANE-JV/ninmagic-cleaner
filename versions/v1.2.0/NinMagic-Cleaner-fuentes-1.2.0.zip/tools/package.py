"""Build the checked Cleaner ZIP for installation at the microSD root."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
import zipfile
from verify_nro import verify

ROOT = Path(__file__).resolve().parent.parent
VERSION = "1.2.0"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def archive_checked(path, payload, refresh):
    if not path.exists() and not refresh:
        with zipfile.ZipFile(path, "x", compression=zipfile.ZIP_DEFLATED) as z:
            for name, data in sorted(payload.items()):
                z.writestr(name, data)
    with zipfile.ZipFile(path) as z:
        if z.testzip() is not None or len(z.namelist()) != len(payload) or set(z.namelist()) != set(payload):
            raise ValueError("ZIP CRC or inventory differs")
        for name, data in payload.items():
            if z.read(name) != data:
                raise ValueError("Existing versioned ZIP differs: " + name)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refresh-report", action="store_true")
    args = parser.parse_args()
    dist = ROOT / "dist"
    nro = dist / "NinMagic-Cleaner.nro"
    report = verify(nro, expected_version=VERSION)
    sources = {}
    for folder in ("source", "include", "assets", "romfs", "tests", "third_party"):
        for path in (ROOT / folder).rglob("*"):
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            if path.is_symlink():
                raise ValueError("Source archive cannot include links")
            if path.suffix.lower() in {".exe", ".o", ".nro", ".elf", ".nacp", ".ppm", ".pyc"}:
                continue
            sources[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    for name in ("README.md", "Makefile", "tools/build.ps1", "tools/verify_nro.py", "tools/publish_update.py", "tools/package.py", "tools/preview.cpp"):
        sources[name] = (ROOT / name).read_bytes()
    source_zip = dist / f"NinMagic-Cleaner-fuentes-{VERSION}.zip"
    archive_checked(source_zip, sources, args.refresh_report)
    match = re.search(r'OfficialUpdateManifest\[\]\s*=\s*"([^"]+)"', (ROOT / "include/app_update.hpp").read_text(encoding="utf-8"))
    if not match or match.group(1) != "https://raw.githubusercontent.com/ANE-JV/ninmagic-cleaner/main/update.txt":
        raise ValueError("Unexpected embedded update channel")
    payload = {
        "switch/NinMagicCleaner/NinMagic-Cleaner.nro": nro.read_bytes(),
        "switch/NinMagicCleaner/LEEME.txt": (ROOT / "README.md").read_bytes(),
        "config/NinMagicCleaner/update-url.txt": (match.group(1) + "\n").encode("ascii"),
        "fuentes/" + source_zip.name: source_zip.read_bytes(),
    }
    for path in (ROOT / "third_party").glob("*-LICENSE.txt"):
        payload["switch/NinMagicCleaner/licencias/" + path.name] = path.read_bytes()
    package = dist / f"NinMagic-Cleaner-{VERSION}.zip"
    archive_checked(package, payload, args.refresh_report)
    report.update({
        "package": {"file": package.name, "bytes": package.stat().st_size, "sha256": digest(package), "entries": len(payload)},
        "sources": {"file": source_zip.name, "sha256": digest(source_zip), "files": len(sources)},
        "official_update_manifest": match.group(1),
        "console_runtime_tested": False,
        "public_channel_published": False,
        "console_installation": "not_transferred",
        "updater": json.loads((dist / "cleaner-app-update-verification-1.2.0.json").read_text(encoding="utf-8-sig")),
        "metadata": json.loads((dist / "cleaner-title-metadata-verification.json").read_text(encoding="utf-8-sig")),
        "ui": json.loads((dist / "cleaner-ui-1.2.0-verification.json").read_text(encoding="utf-8-sig")),
        "integration": json.loads((dist / "cleaner-main-update-integration-review-1.2.0.json").read_text(encoding="utf-8-sig")),
    })
    public = dist / f"public-channel-check-{VERSION}.json"
    if public.is_file():
        evidence = json.loads(public.read_text(encoding="utf-8"))
        report["public_channel_published"] = bool(evidence.get("passed") and evidence.get("nro", {}).get("sha256") == report["sha256"])
    validation = dist / "VERIFICACION.json"
    validation.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    desktop = Path.home() / "Desktop" / f"NinMagic-Cleaner-{VERSION}"
    desktop.mkdir(exist_ok=True)
    for path in (nro, package, source_zip, validation):
        target = desktop / path.name
        shutil.copy2(path, target)
        if digest(path) != digest(target):
            raise ValueError("Desktop copy differs")
    shutil.copy2(ROOT / "README.md", desktop / "LEEME.txt")
    print(json.dumps({"desktop": str(desktop), "nro_sha256": report["sha256"], "zip_sha256": digest(package), "entries": len(payload), "public_channel_published": report["public_channel_published"]}))

if __name__ == "__main__":
    main()
