#include "ui.hpp"
#include "app_update_ui.hpp"
#include "ui_text.hpp"
#include <filesystem>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace {
unsigned checks=0;
void check(bool ok,const char*message){++checks;if(!ok){std::cerr<<"UI guard failed: "<<message<<"\n";std::exit(4);}}
std::vector<uint32_t> frame(const nm::View&v){std::vector<uint32_t>p(1280*720);nm::uiDraw(p.data(),1280,v);return p;}
bool differs(const std::vector<uint32_t>&a,const std::vector<uint32_t>&b,int x,int y,int w,int h){for(int yy=y;yy<y+h;++yy)for(int xx=x;xx<x+w;++xx)if(a[size_t(yy)*1280+xx]!=b[size_t(yy)*1280+xx])return true;return false;}
}

// Render-only fixture. This tool never links backend.cpp and cannot access Switch
// services. Every value below is fictional and exists for visual layout checks.
static nm::View demo() {
    nm::View view;
    view.screen=nm::Screen::Library;
    view.env.firmware="21.0.0 (ejemplo)";
    view.env.atmosphere="1.10.0 (ejemplo)";
    view.env.nand="VISTA PREVIA / DATOS DE EJEMPLO";
    view.env.atmosphereDetected=true;
    view.env.sdTotal=256ULL*1024*1024*1024;
    view.env.sdFree=81ULL*1024*1024*1024;
    view.env.nandTotal=32ULL*1024*1024*1024;
    view.env.nandFree=17ULL*1024*1024*1024;
    const char* names[]={"Órbita: aventura de ejemplo", "Neón Racing (ejemplo)", "Atlas Adventure (ejemplo)", "Biblioteca de prueba", "Crónicas del espacio (ejemplo)", "Prueba con nombre muy largo para revisar el ajuste de texto"};
    for (unsigned i=0;i<6;++i) {
        nm::Game game;
        game.id=0x0100000000010000ULL+i*0x10000;
        game.name=names[i];
        game.author="Estudio de ejemplo";
        game.version="1.2.3";
        game.sd=i!=3;
        game.nand=i==3;
        game.metadataOk=true;
        game.updates=(i%3==0)?1:0;
        game.dlc=(i==0)?2:0;
        game.contents.push_back({game.id,0,static_cast<uint8_t>(game.sd?5:4),0x80});
        if(game.updates) game.contents.push_back({game.id+0x800,65536,5,0x81});
        if(game.dlc) {game.contents.push_back({game.id+0x1001,0,5,0x82});game.contents.push_back({game.id+0x1002,0,5,0x82});}
        view.games.push_back(game);
    }
    view.plan.game=view.games.front();
    view.plan.valid=view.plan.savesOk=view.plan.extrasOk=true;
    nm::Save save;
    save.id=0x8000000000000001ULL;
    save.applicationId=view.plan.game.id;
    save.size=128ULL*1024*1024;
    save.uid0=1;
    save.user="Perfil de ejemplo";
    view.plan.saves.push_back(save);
    save.id++;
    save.uid0=2;
    save.user="Segundo perfil (ejemplo)";
    view.plan.saves.push_back(save);
    view.plan.extraPaths={"sdmc:/atmosphere/contents/0100000000010000", "sdmc:/atmosphere/contents/0100000000010800"};
    view.status="Vista previa visual: todos los datos son de ejemplo.";
    view.frame=120;
    return view;
}

static bool render(const std::string& filename, const nm::View& view) {
    constexpr int width=1280,height=720;
    std::vector<uint32_t> pixels(width*height);
    nm::uiDraw(pixels.data(),width,view);
    std::ofstream stream(filename,std::ios::binary);
    if(!stream) return false;
    stream << "P6\n" << width << " " << height << "\n255\n";
    for(uint32_t pixel:pixels) {
        const unsigned char rgb[]={static_cast<unsigned char>(pixel),static_cast<unsigned char>(pixel>>8),static_cast<unsigned char>(pixel>>16)};
        stream.write(reinterpret_cast<const char*>(rgb),3);
    }
    return stream.good();
}

static nm::View portDemo() {
    nm::View view=demo();
    nm::Game port;
    port.name="Dead Space 2 (ejemplo)";
    port.author="Port NRO · datos ficticios para revisar la interfaz";
    port.version=port.nroVersion="1.1.0 (TU2)";
    port.nroPath="sdmc:/switch/ds2-nx.nro";
    port.externalOnly=port.sd=port.metadataOk=true;
    port.portKey="ds2-nx";
    view.games.push_back(port);
    view.selected=static_cast<int>(view.games.size())-1;
    view.plan={};
    view.plan.game=port;
    view.plan.valid=view.plan.savesOk=view.plan.extrasOk=view.plan.portVerified=view.plan.portSavePolicyKnown=true;
    view.plan.portPaths={"sdmc:/switch/ds2-nx.nro","sdmc:/switch/ds2-nx"};
    view.plan.externalSavePaths={"sdmc:/switch/ds2-nx/ds2"};
    view.plan.portBytes=13ULL*1024*1024*1024+12ULL*1024*1024;
    view.plan.externalSaveBytes=2ULL*1024*1024;
    view.plan.externalSaveFiles=1;
    view.plan.portEntries={
        {"sdmc:/switch/ds2-nx.nro",12ULL*1024*1024,0,false,false},
        {"sdmc:/switch/ds2-nx",0,0,true,false},
        {"sdmc:/switch/ds2-nx/DS2.DAT",13ULL*1024*1024*1024,0,false,false},
        {"sdmc:/switch/ds2-nx/ds2",0,0,true,true},
        {"sdmc:/switch/ds2-nx/ds2/profile.sav",2ULL*1024*1024,0,false,true}
    };
    return view;
}

int main(int argc,char** argv) {
    if(argc!=3) {std::cerr << "Usage: preview ASSET_ROOT OUTPUT_FOLDER\n";return 1;}
    if(!nm::uiInit(argv[1])) {std::cerr << "Cannot initialize UI assets.\n";return 2;}
    std::filesystem::create_directories(argv[2]);
    nm::View view=demo();
    const struct {nm::Screen screen;const char* name;} screens[]={
        {nm::Screen::Library,"01-library"},{nm::Screen::SaveChoice,"02-save-choice"},
        {nm::Screen::Confirm,"03-confirm-preserve"},{nm::Screen::Confirm,"04-confirm-erase-saves"},
        {nm::Screen::Result,"05-result"},{nm::Screen::Help,"06-help"},
        {nm::Screen::Busy,"07-busy"},{nm::Screen::Loading,"08-loading"},
    };
    for (const auto& item:screens) {
        view.screen=item.screen;
        view.eraseSaves=std::string(item.name)=="04-confirm-erase-saves";
        view.hold=view.eraseSaves?0.63f:0;
        if(item.screen==nm::Screen::Result) {
            view.outcome.gameRemoved=view.outcome.complete=true;
            view.outcome.extrasRemoved=2;
            view.outcome.messages={"Ejemplo visual: el juego ha sido eliminado.","Las partidas guardadas se han conservado."};
        }
        const auto destination=(std::filesystem::path(argv[2])/(std::string(item.name)+".ppm")).string();
        if(!render(destination,view)) {std::cerr << "Cannot write " << destination << "\n";nm::uiExit();return 3;}
        std::cout << destination << "\n";
    }
    auto emit=[&](const char* name,const nm::View& item) {
        const auto path=(std::filesystem::path(argv[2])/(std::string(name)+".ppm")).string();
        if(!render(path,item)){std::cerr << "Cannot write " << path << "\n";return false;}
        std::cout << path << "\n";return true;
    };
    nm::View port=portDemo();
    port.screen=nm::Screen::Library;if(!emit("09-port-library",port))return 3;
    port.screen=nm::Screen::SaveChoice;if(!emit("10-port-save-choice",port))return 3;
    port.screen=nm::Screen::Confirm;if(!emit("11-port-confirm-preserve",port))return 3;
    port.eraseSaves=true;port.hold=0.63f;if(!emit("12-port-confirm-erase-saves",port))return 3;
    port.screen=nm::Screen::Files;port.browserPath="sdmc:/switch";
    port.browserEntries={
        {"ds2-nx","sdmc:/switch/ds2-nx",true,true,0},
        {"ds2-nx.nro","sdmc:/switch/ds2-nx.nro",false,true,12ULL*1024*1024},
        {"Carpeta con nombre largo para comprobar el ajuste","sdmc:/switch/Carpeta con nombre largo para comprobar el ajuste",true,true,0},
        {"Aplicación de ejemplo.nro","sdmc:/switch/Aplicación de ejemplo.nro",false,true,4ULL*1024*1024},
        {"Configuración de ejemplo","sdmc:/switch/Configuración de ejemplo",true,true,0},
        {"NinMagic-Cleaner.nro","sdmc:/switch/NinMagic-Cleaner.nro",false,false,3ULL*1024*1024},
        {"Otro port de ejemplo","sdmc:/switch/Otro port de ejemplo",true,true,0},
        {"Última carpeta","sdmc:/switch/Última carpeta",true,true,0}
    };
    port.selectedPaths=port.plan.portPaths;port.browserSelected=0;
    if(!emit("13-files-browser",port))return 3;
    port.screen=nm::Screen::Result;port.outcome={};port.outcome.complete=true;
    port.outcome.portFilesRemoved=2;port.outcome.externalSavesRemoved=1;port.outcome.portBytesRemoved=port.plan.portBytes+port.plan.externalSaveBytes;
    port.outcome.messages={"Ejemplo visual: NRO, datos y partidas SD eliminados.","Este informe solo contiene datos ficticios."};
    if(!emit("14-port-result",port))return 3;
    port.screen=nm::Screen::Confirm;port.hold=0;port.eraseSaves=false;
    port.plan.portSavePolicyKnown=false;port.plan.externalSavePaths={"sdmc:/switch/ds2-nx"};
    port.plan.externalSaveBytes=13ULL*1024*1024*1024+2ULL*1024*1024;port.plan.externalSaveFiles=2;
    port.plan.portBytes=12ULL*1024*1024;
    for(auto&e:port.plan.portEntries)if(e.path!="sdmc:/switch/ds2-nx.nro")e.savedata=true;
    if(!emit("15-unknown-port-preserve",port))return 3;
    port.eraseSaves=true;if(!emit("16-unknown-port-erase",port))return 3;
    port.plan.portPaths.push_back("sdmc:/datos de aplicaciones/Carpeta de ejemplo con un nombre suficientemente largo para revisar el corte exacto de rutas/siguiente nivel/archivos del juego");
    port.plan.extraPaths={"sdmc:/atmosphere/contents/0100000000010000","sdmc:/atmosphere/contents/0100000000010800"};
    port.browserSelected=4;if(!emit("17-confirm-long-routes",port))return 3;
    port.screen=nm::Screen::SaveChoice;port.plan.savesOk=false;port.choice=1;
    port.plan.detail="Ejemplo: no se pudo completar la lectura de partidas. Solo puedes conservarlas o cancelar.";
    if(!emit("18-save-choice-blocked",port))return 3;
    port.screen=nm::Screen::Confirm;port.plan.savesOk=true;port.browserSelected=0;
    port.plan.game.name="Archivo SD seleccionado (ejemplo)";port.plan.game.portKey.clear();
    port.plan.portPaths={"sdmc:/datos de ejemplo/archivo seleccionado.bin"};
    port.plan.externalSavePaths=port.plan.portPaths;port.plan.extraPaths.clear();
    port.plan.portEntries={{port.plan.portPaths.front(),512ULL*1024,0,false,true}};
    port.plan.portBytes=0;port.plan.externalSaveBytes=512ULL*1024;port.plan.externalSaveFiles=1;
    if(!emit("19-manual-file-confirm",port))return 3;
    nm::View versions=demo();versions.games.clear();
    nm::Game installed;installed.id=0x054E4DC8B31AA000ULL;installed.name="Nin-Magic App (ejemplo)";
    installed.author="Nin-Magic";installed.sd=installed.metadataOk=true;installed.version="2.3.8";
    installed.nroVersion="2.3.9";installed.nroPath="sdmc:/switch/Nin-Magic.nro";
    installed.contents={{installed.id,0,5,0x80}};
    nm::Game standalone=installed;standalone.id=0;standalone.externalOnly=true;
    standalone.name="Nin-Magic App (NRO, ejemplo)";standalone.version="2.3.9";standalone.contents.clear();
    versions.games={installed,standalone};versions.selected=0;
    if(!emit("20-installed-version",versions))return 3;
    versions.selected=1;if(!emit("21-nro-version",versions))return 3;
    versions.games[1].version.clear();versions.games[1].nroVersion.clear();
    versions.games[1].name="Aplicación sin versión declarada (ejemplo)";
    if(!emit("22-version-not-declared",versions))return 3;
    nm::View unicode=demo();unicode.games[0].name=u8"Super Mario Bros.™ Wonder";unicode.games[0].version="1.2.1";
    const auto trademark=frame(unicode);unicode.games[0].name="Super Mario Bros.(TM) Wonder";
    check(frame(unicode)==trademark,"TM normalization is display-only and renders readable");
    unicode.games[0].name=u8"Super Mario Bros.™ Wonder";if(!emit("23-title-trademark",unicode))return 3;
    check(nm::ui_text::canDisplayUtf8(u8"Pokémon®: edición ñ"),"Latin-1 registered and accented characters display");
    nm::View update=demo();update.screen=nm::Screen::AppUpdate;auto&u=update.appUpdate;
    u.configured=u.sdVerified=true;u.runningVersion=u.version=u.sdVersion="1.2.0";u.sha256=u.sdSha256=std::string(64,'a');u.size=u.sdSize=2000000;
    u.url="https://raw.githubusercontent.com/ANE-JV/ninmagic-cleaner/main/versions/v1.2.0/NinMagic-Cleaner.nro";
    check(nm::currentPublishedApp(u,{}),"current published version is exact");check(nm::appUpdateAction(u,{}, {})==nm::AppUpdateAction::None,"current publication has no install action");
    const auto current=frame(update);if(!emit("24-update-current",update))return 3;
    update.appUpdateDetail="No se pudo consultar el servidor HTTPS. Revisa Internet y pulsa X para repetir la consulta.";u.version.clear();u.sha256.clear();u.url.clear();u.size=0;
    check(!nm::currentPublishedApp(u,update.appUpdateDetail),"network error never means up to date");check(nm::appUpdateAction(u,{},update.appUpdateDetail)==nm::AppUpdateAction::None,"network error blocks install");
    check(differs(current,frame(update),449,249,770,361),"network error and current states have distinct contents");if(!emit("25-update-network-error",update))return 3;
    update.appUpdateDetail.clear();u.version="1.2.1";u.sha256=std::string(64,'b');u.size=2100000;u.available=true;u.url="https://raw.githubusercontent.com/ANE-JV/ninmagic-cleaner/main/versions/v1.2.1/NinMagic-Cleaner.nro";
    check(nm::appUpdateAction(u,{}, {})==nm::AppUpdateAction::Install,"new version allows explicit install action");
    const auto available=frame(update);check(differs(current,available,449,249,770,361),"available and current states differ");if(!emit("26-update-available",update))return 3;
    u.prepared=true;check(differs(available,frame(update),449,553,772,57),"verified download exposes explicit install confirmation");if(!emit("27-update-prepared",update))return 3;
    u.prepared=false;u.installed=true;u.sdVersion=u.version;u.sdSha256=u.sha256;u.sdSize=u.size;
    check(nm::differentAppOnSd(u)&&!nm::currentPublishedApp(u,{}),"installed session retains executing-version distinction");check(nm::appUpdateAction(u,{}, {})==nm::AppUpdateAction::None,"installed session cannot reinstall");if(!emit("28-update-reopen",update))return 3;
    u.installed=false;u.available=false;u.runningVersion=u.sdVersion=u.version="1.2.0";u.sdSha256=u.sha256;u.sdSize=u.size;
    auto&r=update.completedUpdate;r.state=nm::CompletedUpdateState::CanArchive;r.token="00000001";r.journalState="committed";r.oldVersion="1.1.0";r.newVersion="1.1.1";r.currentVersion="1.2.0";r.currentSha256=u.sha256;r.currentSize=u.size;r.reviewSha256=std::string(64,'c');r.detail="Registro terminado comprobado. Se conservan el ejecutable y sus copias anteriores al archivar estos registros.";
    check(nm::appUpdateAction(u,r,{})==nm::AppUpdateAction::ReviewCompletedRecord,"completed record requires read-only review first");if(!emit("29-update-record-review-action",update))return 3;
    update.screen=nm::Screen::AppUpdateRecord;check(nm::completedReviewReady(r),"review is complete before archive confirmation");const auto ready=frame(update);if(!emit("30-update-record-confirm",update))return 3;
    r.state=nm::CompletedUpdateState::Blocked;r.detail="El registro cambió después de revisarlo. Se conserva el archivo y no se puede archivar.";
    check(!nm::completedReviewReady(r),"changed record cannot be confirmed");check(differs(ready,frame(update),449,553,772,57),"changed record hides confirmation action");if(!emit("31-update-record-blocked",update))return 3;
    update.screen=nm::Screen::AppUpdateResult;update.appUpdateResultOk=u.installed=true;update.appUpdateResultMessage="Cleaner actualizado y verificado. Cierra la aplicación y vuelve a abrirla para ejecutar la nueva versión. Se conserva una copia numerada del NRO anterior.";
    if(!emit("32-update-installed-result",update))return 3;
    const auto installedResult=frame(update);
    update.appUpdateArchiveResult=true;u.installed=false;update.appUpdateResultMessage="Registro terminado archivado. Se conservan el NRO actual y las copias anteriores.";
    check(differs(installedResult,frame(update),32,145,1216,481),"archival result does not claim application updated");if(!emit("33-update-archive-result",update))return 3;
    update.appUpdateResultOk=false;update.appUpdateResultMessage="No se pudo archivar el registro revisado. El NRO actual se conserva.";
    if(!emit("34-update-failed-result",update))return 3;
    std::cout<<"PASS Cleaner UI: "<<checks<<" render and action guards; 34 previews generated\n";
    nm::uiExit();
    return 0;
}
